import java.io.*;
import java.util.HashMap;

public class Lexer {

    // 内部编码
    private static final int KEYWORD = 1;
    private static final int IDENTIFIER = 2;
    private static final int CONSTANT = 3;
    private static final int OPERATOR = 4;
    private static final int DELIMITER = 5;

    // 关键字表
    private static final String[] keywords = {"auto", "break", "case", "char", "const",
            "continue", "default", "do", "double", "else", "enum", "extern", "float",
            "for", "goto", "if", "int", "long", "register", "return", "short", "signed",
            "sizeof", "static", "struct", "switch", "typedef", "union", "unsigned",
            "void", "volatile", "while"};

    // 单词符号到内部编码的映射表
    private static final HashMap<String, Integer> tokenTable = new HashMap<>();

    // 当前单词符号的内部编码和值
    private int tokenCode;
    private String tokenText;

    // 当前读入字符的位置和值
    private int pos = -1;
    private char currentChar;

    // 输入源程序的字符数组
    private char[] input;

    public static void main(String[] args) {
        try {
            Lexer lexer = new Lexer("test.c");
            File file = new File("result.txt");
            BufferedWriter writer = new BufferedWriter(new FileWriter(file));
            while (true) {
                lexer.nextToken();
                // 到头了
                if (lexer.currentChar == '\0' || lexer.getTokenCode() == 0){
                    break;
                }
                if (lexer.getTokenCode() == -1) {
//                    System.out.println("Error: Invalid token " + lexer.getTokenText());
                    writer.write("Error: Invalid token " + lexer.getTokenText() + "\n");
                } else {
                    writer.write("( " + lexer.getTokenCode() + ", " + lexer.getTokenText() + " )\n");
//                    System.out.printf("(%d, %s)\n", lexer.getTokenCode(), lexer.getTokenText());
                }
            }
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // 读文件并做处理
    public void readFile(String file) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader(file));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) {
            sb.append(line);
            sb.append("\n");
        }
        br.close();
        input = sb.toString().toCharArray();
        nextChar();
    }

    // 构造函数
    public Lexer(String file) throws IOException {
        readFile(file);
        // 构造 HashMap
        for (String element : keywords){
            tokenTable.put(element, KEYWORD);
        }
    }

    // 获取下一个单词符号的内部编码和值
    public void nextToken() {
        // 滤掉空格和注释
        while (isWhitespace(currentChar) || isComment()) {
            nextChar();
        }

        // 处理关键字 / 标识符
        if (isLetter(currentChar)) {
            StringBuilder sb = new StringBuilder();
            while (isLetterOrDigit(currentChar)) {
                sb.append(currentChar);
                nextChar();
            }

            tokenText = sb.toString();
            tokenCode = tokenTable.getOrDefault(tokenText, IDENTIFIER);
        }

        // 处理常数
        else if (isDigit(currentChar) || currentChar == '.') {
            StringBuilder sb = new StringBuilder();
            boolean isDecimal = false;
            // 当前字符是数字 或 当前字符是小数点且 flag == false 或 当前字符是 e/E 且 flag == false 或 当前是算符且前一个字符正常
            while (isDigit(currentChar) || currentChar == '.'
                    || (isDecimal && currentChar == 'e') || (isDecimal && currentChar == 'E')
                    || (isOperator(currentChar) && (isDigit(input[pos - 1]) || input[pos - 1] == 'e' || input[pos - 1] == 'E') )) {
                if (currentChar == '.' || currentChar == 'e' || currentChar == 'E') {
                    isDecimal = true;
                }
                sb.append(currentChar);
                nextChar();
            }
            tokenText = sb.toString();
            // 数字检验
            int dotPos = tokenText.indexOf('.');
            int ePos = tokenText.indexOf('e'), EPos = tokenText.indexOf('E');
            // 小数点在首位或小数点后面没有别的了
            if (dotPos == 0 || dotPos == tokenText.length() - 1){
                tokenCode = -1;
            }
            // e/E 在首位
            else if (ePos == 0 || EPos == 0){
                tokenCode = -1;
            }
            else{
                tokenCode = CONSTANT;
            }
        }

        // 处理运算符和分隔符
        else if (isOperator(currentChar) || isDelimiter(currentChar)) {
            StringBuilder sb = new StringBuilder();
            sb.append(currentChar);
            nextChar();
            if (isOperator(sb.toString())) {
                // 运算符组
                while (isOperator(sb.toString() + currentChar)) {
                    sb.append(currentChar);
                    nextChar();
                }
                tokenText = sb.toString();
                tokenCode = OPERATOR;
            } else {
                tokenText = sb.toString();
                tokenCode = DELIMITER;
            }
        }

        // 非法字符
        else {
            tokenText = Character.toString(currentChar);
            tokenCode = -1;
            nextChar();
        }
    }

    // 判断当前字符是否为空格、制表符或换行符
    private boolean isWhitespace(char c) {
        return c == ' ' || c == '\t' || c == '\n';
    }

    // 判断当前字符是否是字母
    private boolean isLetter(char c) {
        return Character.isLetter(c);
    }

    // 判断当前字符是否是数字
    private boolean isDigit(char c) {
        return Character.isDigit(c);
    }

    // 判断当前字符是否是字母或数字
    private boolean isLetterOrDigit(char c) {
        return Character.isLetterOrDigit(c);
    }

    // 判断当前符号是否为运算符
    private boolean isOperator(char c) {
        return c == '+' || c == '-' || c == '*' || c == '/' ||
                c == '<' || c == '>' || c == '=' || c == '!'
                || c == '&' || c == '|' || c == '%';
    }

    // 判断给定字符序列是否为运算符
    private boolean isOperator(String op) {
        return op.equals("+=") || op.equals("-=") || op.equals("*=") || op.equals("/=") ||
                op.equals("<") || op.equals("<=") || op.equals(">") || op.equals(">=") ||
                op.equals("==") || op.equals("!=") || op.equals("=") || op.equals("!")
                || op.equals("++") || op.equals("--") ;
    }

    // 判断当前符号是否为分隔符
    private boolean isDelimiter(char c) {
        return c == ';' || c == ',' || c == '(' || c == ')' ||
                c == '[' || c == ']' || c == '{' || c == '}'
                || c == ':'  || c == '\'' || c == '\"';
    }

    // 判断当前字符是否为注释的起始符号
    private boolean isComment() {
        if (currentChar == '/') {
            // 单行注释，滤到行末
            if (peekChar() == '/') {
                while (currentChar != '\n') {
                    nextChar();
                }
                return true;
            }
            // 多行注释，滤到注释结束符号
            else if (peekChar() == '*') {
                nextChar(); // 消耗掉 /
                nextChar(); // 消耗掉 *
                while (true) {
                    if (currentChar == '*' && peekChar() == '/') {
                        // 找到注释结束符号，消耗掉
                        nextChar();
                        nextChar();
                        break;
                    } else if (currentChar == '\0') {
                        // 未找到注释结束符号，报错并跳过注释
                        System.out.println("Error: Unterminated comment");
                        nextChar();
                        break;
                    } else {
                        nextChar();
                    }
                }
                return true;
            }
        }
        return false;
    }

    // 获取当前位置的下一个字符，不修改 pos
    private char peekChar() {
        if (pos < input.length - 1) {
            return input[pos + 1];
        } else {
            return '\0';
        }
    }

    // 获取下一个字符并修改 pos
    private void nextChar() {
        if (pos < input.length - 1) {
            pos += 1;
            currentChar = input[pos];
        } else {
            currentChar = '\0';
        }
    }

    // 获取当前单词符号的内部编码
    public int getTokenCode() {
        return tokenCode;
    }

    // 获取当前单词符号的值
    public String getTokenText() {
        return tokenText;
    }
}