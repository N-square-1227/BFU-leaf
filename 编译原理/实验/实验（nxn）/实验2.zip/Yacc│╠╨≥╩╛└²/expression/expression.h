/****************************************************************************
*                     U N R E G I S T E R E D   C O P Y
* 
* You are on day 33 of your 30 day trial period.
* 
* This file was produced by an UNREGISTERED COPY of Parser Generator. It is
* for evaluation purposes only. If you continue to use Parser Generator 30
* days after installation then you are required to purchase a license. For
* more information see the online help or go to the Bumble-Bee Software
* homepage at:
* 
* http://www.bumblebeesoftware.com
* 
* This notice must remain present in the file. It cannot be removed.
****************************************************************************/

/****************************************************************************
* expression.h
* C header file generated from expression.y.
* 
* Date: 05/02/13
* Time: 22:56:04
* 
* AYACC Version: 2.07
****************************************************************************/

#ifndef _EXPRESSION_H
#define _EXPRESSION_H

#include <yypars.h>

#define NUMBER 257
#define UMINUS 258
#endif
