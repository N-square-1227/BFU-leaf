#ifndef _P1_H
#define _P1_H

#include <lex.h>

#ifndef INITIAL
#define INITIAL 0
#endif

#endif
