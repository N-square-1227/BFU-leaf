#ifndef _P2_H
#define _P2_H

#include <yacc.h>

#define NAME 257
#define EQ 258
#define PRICE 259
#endif
