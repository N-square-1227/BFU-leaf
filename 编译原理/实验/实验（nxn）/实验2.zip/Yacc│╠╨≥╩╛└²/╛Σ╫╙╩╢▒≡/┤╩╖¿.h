#ifndef ______H
#define ______H

#include <lex.h>

#ifndef INITIAL
#define INITIAL 0
#endif

#endif
