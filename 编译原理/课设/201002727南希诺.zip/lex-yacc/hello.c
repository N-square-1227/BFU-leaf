#include<stdio.h>
#include <stdlib.h>

int main(){
printf("hello world");
system("PAUSE");
return 0;
}
