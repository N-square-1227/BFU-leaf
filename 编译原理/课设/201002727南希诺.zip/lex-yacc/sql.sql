
CREATE TABLE student (age INT, major VARCHAR(50), name VARCHAR(50));

-- void add_student(int age, char* name, char* major);
INSERT INTO student (age, major, name) VALUES (18, 'CScience', 'Tom');
INSERT INTO student (age, major, name) VALUES (21, 'sailor',   'Kazuha');
INSERT INTO student (age, major, name) VALUES (27, 'Botanic',  'Tignari');
INSERT INTO student (age, major, name) VALUES (21, 'Pkmn',     'Satoshi');

-- void delete_student(int age);
DELETE FROM student WHERE age = 18;

-- void query_student();
SELECT * FROM student;

-- void query_student_major();
SELECT major FROM student;

SELECT name FROM student WHERE age >= 20;

-- void modify_student_age_by_name(int age, char* name); 
UPDATE student SET age = 20 WHERE name = 'Tom';

DROP TABLE student;
