# ERRORS

## define YYSTYPE 放在 include y.tab.h 上面

如果是 Linux 的话就是 include y.tab.h，Windows 就是 include sql.tab.h，因为执行`bison -d sql.y`或者`yacc -d sql.y`的时候，根据系统的不同，产出的文件也不同。

## 如何传入NUMBER,STRING,STRING？









# 心得体会

- `%left '+' '-' ` 、`%left '*' '/'` 是什么意思？

这是在编写语法分析器时使用的语法规则定义。它定义了运算符的优先级和结合性。

`%left '+' '-' `表示加减运算符具有相同的优先级和左结合性，即先计算左侧表达式，再计算右侧表达式。

`%left '*' '/' `表示乘除运算符具有相同的优先级和左结合性，即先计算左侧表达式，再计算右侧表达式。

这个定义告诉语法分析器，在处理表达式时应该先计算乘除运算符，再计算加减运算符。如果出现多个运算符时，按照优先级和结合性的规则进行计算，以保证表达式的正确性。

- .匹配任意字符（除\n外），不做任何操作


- 如果只输入一个数字 1，而有两个匹配，那么程序会把它判定为谁的 pattern 呢？

  flex 的规则有着隐藏优先级：匹配长度相同时，将最上面的规则作为匹配结果。

- yacc 文件分析下面这句代码

  `INSERT INTO student (age, major, name) VALUES (18, 'CScience', 'Tom');`

​	按照定义，18, 'CScience', 'Tom' 是 value_list 这个整体的内容。那么应该如何分别提取出这三个	参数，并分别传入到 add_student(int age, char* major, char* name)？

​	在 yacc 文件中，使用 `%union` 字段来对 lex 的词法分析的输出进行分类存储，比如添加一个 int_val 和 一个 string_val，lex 就会自动将你的词法规则输出的内容与之相匹配，在这之后在 yacc 文件中直接调用即可。



