import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

public class SQLParser {

    /**
     * 存放单词的数组
     */
    private List<String> tokens;
    /**
     * 当前位置
     */
    private int index;
    /**
     * 使用链表来模拟表的数据结构
     */
    private LinkedList<Integer> list;
    /**
     * 表名
     */
    private String tableName;
    /**
     * 列名
     */
    private String columnName;
    /**
     * 列值
     */
    private int value;
    /**
     * 普通的数据
     */
    private static final int ORDINARY = 1;
    /**
     * 表名
     */
    private static final int TABLE_NAME = 2;
    /**
     * 列名
     */
    private static final int COLUMN_NAME = 3;

    public SQLParser(String input) {
        tokens = tokenize(input);
        index = 0;
    }
    /**
     * 把输入的 sql 语句分割为一个个语法成分
     * @param sql 输入的 sql 语句
     * @return 分割后的数组
     */
    public static ArrayList<String> process(String sql) {
        StringBuilder stringBuilder = new StringBuilder();
        ArrayList<String> word = new ArrayList<>();
        for (int i = 0; i < sql.length(); i++) {
            // 是空格，总结为一个单词，将其大写存入数组里
            if (sql.charAt(i) == ' ' && !stringBuilder.isEmpty()) {
                word.add(stringBuilder.toString().toUpperCase());
                stringBuilder = new StringBuilder();
            }
            // 是字母或数字，继续添加
            else if (Character.isLetterOrDigit(sql.charAt(i))) {
                stringBuilder.append(sql.charAt(i));
            }
            // 是标点
            else if (sql.charAt(i) == '(' || sql.charAt(i) == ')' ||
                    sql.charAt(i) == ',' || sql.charAt(i) == ';' ||
                    sql.charAt(i) == '=') {
                if (!stringBuilder.isEmpty()) {
                    word.add(stringBuilder.toString().toUpperCase());
                    stringBuilder = new StringBuilder();
                }
                // 是标点
                word.add(String.valueOf(sql.charAt(i)));
            }
        }
//        for (String str : word) {
//           System.out.println(str);
//        }
        return word;
    }

    /**
     * 将输入的 SQL 语句经过分割后，存入数组里
     * @param input 输入的 SQL 语句
     * @return 数组
     */
    private List<String> tokenize(String input) {
        tokens = SQLParser.process(input);
        return tokens;
    }

    /**
     * 获取下一个下标的单词
     */
    private String consume() {
        return tokens.get(index++);
    }

    /**
     * 你输入正确的 token，在对应数组位置是否也是你希望的 token.
     * 如果是的话，对应数组的下标 + 1，意为开始匹配下一个字符。
     * @param token 理应是这个（正确的语法）
     * @return 语法正确 true，否则 false
     */
    private boolean match(String token) {
        // 数组下标不越界                  语法正确
        if (index < tokens.size() && tokens.get(index).equals(token)) {
            // 下标 +1，匹配下一个字符
            index++;
            return true;
        }
        return false;
    }
    /**
     * @param token 期待的字符
     * @return 匹配是否成功
     */
    private boolean expect(String token) {
        if (match(token)) {
            return true;
        } else {
            throw new RuntimeException("Expected " + token + " but found " + tokens.get(index));
        }
    }

    /**
     * 根据传入的 type 采取对应的措施
     * @param type 不同的标识符对应着不同的处理措施
     */
    private boolean identifier(int type) {
        // 普通的值，只需要校验是否符合要求
        if (type == ORDINARY){
            if (consume().matches("[A-Za-z]+")) {
                return true;
            } else {
                throw new RuntimeException("Expected identifier but not exists. ");
            }
        }
        // 表名，进入表名处理
        if (type == TABLE_NAME) {
            return table_name();
        }
        // 列名，进入列名处理
        if (type == COLUMN_NAME) {
            return column_name();
        }
        return false;
    }

    /**
     * 表名，校验表名合法性
     * 如果已经有了表名，检测是否和你之前定义的表名一样
     */
    private boolean table_name() {
        String token = consume();
        if (token.matches("[A-Za-z]+")) {
            if (tableName == null) {
                tableName = token;
            }
            return token.equals(tableName);
        } else {
            throw new RuntimeException("Expected identifier but found " + token);
        }
    }
    /**
     * 列名，校验列名合法性
     * 如果已经有了列名，检测是否和你之前定义的列名一样
     */
    private boolean column_name() {
        String token = consume();
        if (token.matches("[A-Za-z]+")) {
            if (columnName == null) {
                columnName = token;
            }
            return token.equals(columnName);
        } else {
            throw new RuntimeException("Expected identifier but found " + token);
        }
    }

    /**
     * 列 → 列类型
     */
    private boolean column() {
        String token = consume();
        if (token.matches("[A-Za-z]+")) {
            return type();
        } else {
            throw new RuntimeException("Expected identifier but found " + token);
        }
    }

    /**
     * 类型：INT
     */
    private boolean type() {
        return match("INT");
    }

    /**
     * 判断是否是数字
     */
    private boolean number() {
        String token = consume();
        if (Character.isDigit(token.charAt(0))) {
            value = Integer.parseInt(token);
            return true;
        } else {
            throw new RuntimeException("Expected number but found " + token);
        }
    }

    /**
     * 条件列表
     * @return 是否匹配
     */
    private boolean condition_list() {
        // 回溯
        int startIndex = index;
        //String token = columnName;
        if (identifier(COLUMN_NAME)) {
            if (match("=")) {
                if (number()) {
                    return true;
                }
            }
        }
        index = startIndex;
        return false;
    }
    /**
     * 创建语句的分析
     */
    private boolean createTableStatement() {
        return expect("CREATE") && expect("TABLE")
                && identifier(TABLE_NAME) && expect("(")
                && column() &&  expect(")")
                && expect(";");
    }
    private boolean insertStatement() {
        return expect("INSERT") && expect("INTO")
                && identifier(TABLE_NAME) && expect("VALUES") && expect("(")
                && number() && expect(")") && expect(";");
    }

    private boolean deleteStatement() {
        return expect("DELETE") && expect("FROM")
                && identifier(TABLE_NAME) && expect("WHERE")
                && condition_list() && expect(";");
    }

    private boolean selectStatement() {
        return expect("SELECT") && identifier(COLUMN_NAME)
                && expect("FROM") && identifier(TABLE_NAME)
                && expect(";");
    }

    private boolean updateStatement() {
        return expect("UPDATE") && identifier(TABLE_NAME)
                && expect("SET") && identifier(COLUMN_NAME)
                && expect("=") && number()
                && expect(";");
    }

    private boolean dropTableStatement() {
        return expect("DROP") && expect("TABLE")
                && identifier(TABLE_NAME) && expect(";");
    }

    /**
     * 分析
     */
    public void parse() {
        // 接受语句返回结果的正确性
        while (index < tokens.size()) {
            String token = tokens.get(index);
            switch (token) {
                case "CREATE" -> {
                    // 分析正确，模拟创建表
                    if (createTableStatement()) {
                        System.out.println("sql> CREATE 语句分析成功，创建表 " + tableName);
                        // 初始化链表
                        list = new LinkedList<>();
                    }
                }
                case "INSERT" -> {
                    if (insertStatement()) {
                        System.out.println("sql> INSERT 语句分析成功，插入数值 " + value);
                        list.add(value);
                    }
                }
                case "DELETE" -> {
                    if (deleteStatement()) {
                        System.out.println("sql> 删除指定元素 " + value);
                        // 删除节点
                        list.remove(value - 1);
                        System.out.println("     输出所有元素：" + list);
                    }
                }
                case "SELECT" -> {
                    if (selectStatement()) {
                        System.out.println("sql> 输出所有元素：" + list);
                    }
                }
                case "UPDATE" -> {
                    if (updateStatement()) {
                        System.out.println("sql> 更新元素为 " + value);

                        ListIterator<Integer> iterator = list.listIterator();
                        while (iterator.hasNext()) {
                            iterator.next(); // 将迭代器的位置移动到下一个元素
                            iterator.set(3);
                        }

                        System.out.println("     修改后节点如下：" + list);
                    }
                }
                case "DROP" -> {
                    if (dropTableStatement()) {
                        System.out.println("sql> 已经删除表 " + tableName );
                        list.clear();
                    }
                }
                default -> throw new RuntimeException("Unexpected token " + token);
            }
        }
    }

    public static void main(String[] args) {

        String input = """
                CREATE TABLE array (idx INT);
                INSERT INTO array VALUES (1);
                INSERT INTO array VALUES (2);
                INSERT INTO array VALUES (3);
                INSERT INTO array VALUES (4);
                SELECT idx FROM array;
                DELETE FROM array WHERE idx = 4;
                SELECT idx FROM array;
                UPDATE array SET idx = 3;
                DROP TABLE array;
                """;
        SQLParser parser = new SQLParser(input);
        parser.parse();
    }
}