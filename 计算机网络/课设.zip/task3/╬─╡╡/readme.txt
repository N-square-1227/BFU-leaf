这里运行程序的方式默认是命令行，若有现成的编译器可以直接在编译器上编译运行。

运行环境：

若在同一台主机上测试用（既当 server 又当 host）：
    运行环境：win 10  idea 2021.3.1 Oracle openJDK 17.0.2
    serverIP 输入 127.0.0.1, serverPort 输入 12000
    先开启 server 再启动 client。


主机client + 虚拟机server：
    运行环境：windows10， Ubuntu 20.04。

	windows jdk： Oracle openJDK 17.0.2
	Ubuntu jdk： openjdk 11.0.16 2022-07-19
	                    OpenJDK Runtime Environment (build 11.0.16+8-post-Ubuntu-0ubuntu120.04)
	                    OpenJDK 64-Bit Server VM (build 11.0.16+8-post-Ubuntu-0ubuntu120.04, mixed mode, sharing)


TCPClient 放在主机上，TCPServer 放在客户机上，Util 在两个机器上都放一份。
liyue.txt 文件放在主机上，处于  TCPClient.java 的上一级目录。

1. 在各自机器命令行中输入 javac Util.java
1.1 在主机上命令行输入 javac TCPClient.java
1.2 在客户机上命令行输入 javac TCPServer.java

2. 客户机命令行输入 java TCPServer 启动服务端程序

3. 主机命令行输入 java TCPClient 启动客户端程序。
3.1 根据提示输入各项数值，IP 写自己虚拟机的 IP，PORT 写 12000！！！

4.看程序的输出，最后导出的 txt 文件和 txt 文件处于同一目录下。