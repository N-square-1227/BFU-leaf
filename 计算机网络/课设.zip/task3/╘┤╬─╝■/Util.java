import java.nio.charset.StandardCharsets;

public class Util
{
    /**
     * TYPE 字段
     */
    public static final String INITIAL = "10";
    public static final String AGREE = "20";
    public static final String REVERSE_REQ = "30";
    public static final String REVERSE_ANS = "40";

    public static final int PORT = 12000;
    public static final int TYPE_BEGIN = 0;
    public static final int TYPE_END = 2;
    public static final int DATA_BEGIN = 6;

    /**
     * 按照指定字节位数截取 String(规定字符编码 = UTF-8)
     * @param receiveMsg 字符串
     * @param startIndex 开始处字节索引包含startIndex
     * @param endIndex 结束处字节索引不包含endIndex
     * @return 截取后的字符串
     */
    public static String subStringByByte(String receiveMsg, int startIndex, int endIndex)
    {
        // 将收到的 String 转换为 byte 格式的数组
        byte[] bytes = receiveMsg.getBytes(StandardCharsets.UTF_8);
        int subLen = endIndex - startIndex;
        // 判断起终点位置是否合法
        if (startIndex < 0) {
            return "startIndex 小于 0！";
        }
        if (endIndex > bytes.length) {
            return "endIndex 大于最远长度！";
        }
        if (subLen <= 0) {
            return " endIndex 与 startIndex 之差小于 0！";
        }

        // 创建合适大小的字节串
        byte[] subBytes = new byte[subLen];
        // 填充 byte 数组
        int i = 0;
        while (startIndex < endIndex)
        {
            subBytes[i] = bytes[startIndex];
            i += 1;
            startIndex += 1;
        }
        return new String(subBytes, StandardCharsets.UTF_8);
    }

    /**
     * 返回反转后的字符串
     * @param context 反转前的字符串
     * @return 反转后的字符串
     */
    public static String reverseString(String context) {
        return new StringBuilder(context).reverse().toString();
    }
}
