import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;


public class TCPServer
{
    private int N = Integer.MAX_VALUE - 1;

    private final Socket socket;
    private final InputStream inputStream;
    private final OutputStream outputStream;
    private final ServerSocket serverSocket;
    private final DataInputStream dataInputStream;
    private final DataOutputStream dataOutputStream;

    public TCPServer() throws IOException
    {
        serverSocket = new ServerSocket(Util.PORT);
        socket = serverSocket.accept();

        inputStream = socket.getInputStream();
        outputStream = socket.getOutputStream();

        dataInputStream = new DataInputStream(inputStream);
        dataOutputStream = new DataOutputStream(outputStream);
    }
    public void close() throws IOException
    {
        dataInputStream.close();
        dataOutputStream.close();

        inputStream.close();
        outputStream.close();

        serverSocket.close();
        socket.close();
    }

    public void setN(int n)
    {
        N = n;
    }
    public String generateRevPkg(String content)
    {
        StringBuffer Type = new StringBuffer(Util.REVERSE_ANS);
        // 生成报文的 Length 域
        String len = String.valueOf(content.length());
        StringBuffer Length = new StringBuffer(len);
        // 4 位，补全位数
        do {Length.insert(0,"0");}
        while (Length.length() < 4);
        // 生成报文
        return String.valueOf(Type.append(Length).append(content));
    }
    // 根据收到报文的 head 决定如何处理
    public void myOut(String type, String rcvMsg) throws IOException
    {
        switch (type)
        {
            // Client:Init
            // 通过 Init 报文更新 totalNum
            case Util.INITIAL -> {
                int N = Integer.parseInt(Util.subStringByByte(rcvMsg, Util.TYPE_END, Util.DATA_BEGIN));
                setN(N);
                // 送回送报文
                dataOutputStream.writeUTF(Util.AGREE);
            }

            // Client:request
            // 获取并处理 Client 传过来的原始报文
            case Util.REVERSE_REQ -> {
                // 内容
                String content = Util.subStringByByte(rcvMsg, Util.DATA_BEGIN, rcvMsg.length());
                // 反转后的内容
                String reverseContent = Util.reverseString(content);
                // 生成报文
                String replyPkg = generateRevPkg(reverseContent);
                // 发送报文
                dataOutputStream.writeUTF(replyPkg);
            }
            default -> {}
        }
    }
    public void receive() throws IOException
    {
        int count = 0;
        // N + 1 是因为那个 Init 包
        while (count < (N + 1))
        {
            byte[] bytes = new byte[1024];
            int len = dataInputStream.read(bytes);
            String receiveMsg = new String(bytes,0, len);
            // 获得 Type 字段
            String type = Util.subStringByByte(receiveMsg, Util.TYPE_BEGIN, Util.TYPE_END);
            myOut(type, receiveMsg);
            count += 1;
        }
    }
    public static void main(String[] args) throws Exception
    {
        Thread.sleep(300);
        TCPServer tcpServer = new TCPServer();
        tcpServer.receive();
        tcpServer.close();
    }
}