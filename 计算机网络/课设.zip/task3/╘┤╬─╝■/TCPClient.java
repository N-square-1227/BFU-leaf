import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class TCPClient
{
    /**
     * req 报文个数
     */
    private int N;
    private int Lmin;
    private int Lmax;
    /**
     * 初始的文本数组，每个位置是一个字符
     */
    private ArrayList<String> originText;
    /**
     * 所有的发送报文
     */
    private ArrayList<String> allPackets;
    /**
     * 所有反转后的报文
     */
    private final StringBuffer reverseText;

    private int serverPort;
    private String serverIP;
    InputStream  inputStream ;
    OutputStream outputStream;
    private final Socket socket;
    DataInputStream dataInputStream;
    DataOutputStream dataOutputStream;

    public TCPClient() throws IOException
    {
        // 初始化 内容 数组
        readFile();
        // 设置 IP 和 端口号
        setServerIP();
        setServerPort();
        // todo:v1.0：random 生成 Lmin, Lmax
        setLmin();
        setLmax();
        // 生成 req 报文数组
        generateAllPackets();
        // 生成 N
        setN(allPackets.size());
        // 生成 Initialization 报文并插入到 allPkg 首位
        generateInitPkg();
        // 初始化
        reverseText = new StringBuffer();
        socket = new Socket(serverIP, serverPort);
        inputStream = socket.getInputStream();
        outputStream = socket.getOutputStream();
        dataInputStream = new DataInputStream(inputStream);
        dataOutputStream = new DataOutputStream(outputStream);
    }

    public void setN(int n)
    {
        N = n;
    }

    public int getLmin()
    {
        return Lmin;
    }

    public void setLmin()
    {
        System.out.print("TCPClient:> 请输入Lmin：");
        Scanner scanner = new Scanner(System.in);
        this.Lmin = scanner.nextInt();
        while( this.Lmin < 0 || this.Lmin > originText.size())
        {
            System.out.print("TCPClient:> Lmin 不合法，请重新输入 Lmin：");
            scanner = new Scanner(System.in);
            this.Lmin = scanner.nextInt();
        }
    }

    public int getLmax()
    {
        return Lmax;
    }

    public void setLmax()
    {
        System.out.print("TCPClient:> 请输入Lmax：");
        Scanner scanner = new Scanner(System.in);
        this.Lmax = scanner.nextInt();
        while(this.Lmax <= this.Lmin || this.Lmax > originText.size())
        {
            System.out.print("TCPClient:> Lmax 不合法，请重新输入Lmax：");
            scanner = new Scanner(System.in);
            this.Lmax = scanner.nextInt();
        }
    }

    public void setServerIP()
    {
        System.out.print("TCPClient> 请输入serverIp：");
        Scanner scanner = new Scanner(System.in);
        this.serverIP = scanner.next();
    }


    public void setServerPort()
    {
        System.out.print("TCPClient> 请输入serverPort：");
        Scanner scanner = new Scanner(System.in);
        this.serverPort = scanner.nextInt();
    }

    /**
     * 生成 Hello！ 报文
     */
    public void generateInitPkg()
    {
        StringBuffer Type = new StringBuffer(Util.INITIAL);
        // 生成报文的 Length 域
        String len = String.valueOf(N);
        StringBuffer Length = new StringBuffer(len);
        // 4 位，补全位数
        do {Length.insert(0,"0");}
        while (Length.length() < 4);
        // 生成 Init 报文
        String initPkg = String.valueOf(Type.append(Length));
        // 在首位插入该报文
        // 这也是不使用 String[] 的原因
        allPackets.add(0, initPkg);
    }

    private void saveAsFileWriter()
    {
        FileWriter fileWriter = null;
        try {
            // true 表示不覆盖原来的内容，而是加到文件的后面
            // 若要覆盖原来的内容，省略这个参数
            fileWriter = new FileWriter("./euyil.txt", true);
            fileWriter.write(String.valueOf(reverseText));
        } catch (IOException ex) {
            ex.printStackTrace();
        } finally
        {
            try
            {
                assert fileWriter != null;
                fileWriter.flush();
                fileWriter.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }
    /**
     * 看情况生成 Data 域
     * @param Data stringBuffer
     * @param index 起始位置
     * @param end 结束位置
     */
    public void generateData(StringBuffer Data, int index, int end)
    {
        for (int i = index; i < end; i++) {
            Data.append(originText.get(i));
        }
    }
    /**
     * 生成 req 报文
     */
    public void generateAllPackets()
    {
        allPackets = new ArrayList<>(30);
        // 内容数组的起始位置
        int index = 0;
        while (index < originText.size())
        {
            // 从 Lmin，Lmax 中生成一个长度，作为报文 data 的单词数
            Random random = new Random();
            int charNum = random.nextInt(getLmin(), getLmax());
            StringBuffer Data = new StringBuffer();
            // 没超出边界，可以生成该单词长度的报文
            // 超边界了，直接运行到末尾结束即可
            generateData(Data, index, Math.min(index + charNum, originText.size()));
            // 生成报文的 Length 域
            String len = String.valueOf(charNum);
            StringBuffer Length = new StringBuffer(len);
            // 4 位，补全位数
            do {Length.insert(0,"0");}
            while (Length.length() < 4);

            // 生成报文的 Type 域
            StringBuffer Type = new StringBuffer(Util.REVERSE_REQ);
            // 组装成一条完整的报文
            String reqPkt = String.valueOf(Type.append(Length).append(Data));
            // 把这条报文放到 allPackets 数组里
            allPackets.add(reqPkt);
            // 改变 index 的值
            index += charNum;
        }
    }
    /**
     * 将文件中的内容读入初始数组中。
     */
    public void readFile() throws IOException
    {
        String fileName = "./liyue.txt";
        File file = new File(fileName);
        FileInputStream fileInputStream = new FileInputStream(file);
        InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream);
        BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

        originText = new ArrayList<>();
        int tempChar;
        while((tempChar = bufferedReader.read()) != -1) {
            char c = (char)tempChar;
            originText.add(String.valueOf(c));
        }
        bufferedReader.close();
    }

    public void tcpBye() throws IOException
    {
        dataOutputStream.close();
        dataInputStream.close();

        outputStream.close();
        inputStream.close();

        socket.close();
    }

    public void myOut(String type, int count, String rcvMsg)
    {
        // 内容的长度
        if (Util.REVERSE_ANS.equals(type))
        {
            // 内容
            String content = Util.subStringByByte(rcvMsg, Util.DATA_BEGIN, rcvMsg.length());
            System.out.println("第 " + count + " 块：" + content);
            // 将文本保存下来，待输出文件时用
            reverseText.insert(0, content);
        }
    }
    public void tcpHello() throws IOException
    {
        // 读取数组中的每一条报文并发送
        int count = 0;
        for (String sendMsg : allPackets)
        {
            dataOutputStream.write(sendMsg.getBytes(StandardCharsets.UTF_8));
            String receiveMsg = dataInputStream.readUTF();
            // 取前两字节
            String Type = Util.subStringByByte(receiveMsg, Util.TYPE_BEGIN, Util.TYPE_END);
            myOut(Type, count, receiveMsg);
            count += 1;
        }
    }
    public static void main(String[] args) throws Exception
    {
        TCPClient tcpClient = new TCPClient();
        tcpClient.tcpHello();
        tcpClient.tcpBye();
        tcpClient.saveAsFileWriter();
    }
}