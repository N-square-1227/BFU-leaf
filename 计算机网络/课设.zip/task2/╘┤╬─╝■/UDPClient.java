import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class UDPClient
{
    /**
     * 服务器 IP 地址
     * 由命令行手动指定
     */
    private String serverIP;
    /**
     * 服务器端口号
     * 由命令行手动指定
     */
    private int serverPort;
    /**
     * 数据传输 socket
     */
    DatagramSocket datagramSocket;
    // 接收:
    DatagramSocket datagramSocketR;
    /**
     * 丢包率
     */
    private double lossRate = 0.0;
    /**
     * 最大 RTT
     */
    private long maxRTT = 0;
    /**
     * 平均 RTT
     */
    private long avgRTT = 0;
    /**
     * RTT 标准差
     */
    private long stdRTT = 0;
    /**
     * 最小 RTT
     */
    private long minRTT = 100;
    /**
     * RTT 数组
     */
    private final ArrayList<Long> RTTs = new ArrayList<>();
    /**
     * 所有收到的 request 报文
     */
    private final HashMap<Integer, String> allReceived = new HashMap<>();
    /**
     * 服务器时间
     */
    private long serverTime;

    /**
     * client 端启动时在命令行方式下指定 serverIP，serverPort.
     */
    public void setServerIP()
    {
        System.out.print("UDPClient> 请输入serverIp：");
        Scanner scanner = new Scanner(System.in);
        this.serverIP = scanner.next();
    }


    public void setLossRate()
    {
        this.lossRate = 1.0 - (double) RTTs.size() / (UDPUtil.PKT_NUM);
    }

    /**
     * 求三个 RTT 的值
     */
    public void setThreeRTT()
    {
        //极限情况全都丢了
        if (RTTs.size() == 0){
            return;
        }
        for (long rtt : this.RTTs)
        {
            if (rtt > maxRTT) {
                maxRTT = rtt;
            }
            if (rtt < minRTT) {
                minRTT = rtt;
            }
            avgRTT += rtt;
        }
        // 求标准差算法
        long average = avgRTT / this.RTTs.size();
        long total = 0;
        for (Long rtt : this.RTTs) {
            total += (rtt - average) * (rtt - average);
        }
        double standardDeviation = Math.sqrt(total / (double) this.RTTs.size());

        stdRTT = (long) standardDeviation;
        avgRTT /= this.RTTs.size();
    }

    /**
     * client端启动时在命令行方式下指定 serverIP，serverPort.
     */
    public void setServerPort()
    {
        System.out.print("UDPClient> 请输入serverPort：");
        Scanner scanner = new Scanner(System.in);
        this.serverPort = scanner.nextInt();
    }

    public UDPClient() throws SocketException, UnknownHostException
    {
        // 设置 IP 地址和端口号
        setServerIP();
        setServerPort();
        datagramSocket = new DatagramSocket();
        // 连接指定服务器和端口
        datagramSocket.connect(InetAddress.getByName(serverIP), serverPort);
        datagramSocketR = new DatagramSocket(10000);
    }

    /**
     * 生成报文
     * @return 发送报文
     */
    public String generatePacket(String seqNo, String syn, String re, String data)
    {
        StringBuilder stringBuffer = new StringBuilder();
        if (seqNo.length() < 2){
            seqNo = "0" + seqNo;
        }
        return String.valueOf(stringBuffer.append(seqNo).append(UDPUtil.VER)
                .append(syn).append(re).append(UDPUtil.DEFAULT_SERVER_TIME).append(UDPUtil.DEFAULT_RTT)
                .append(data));
    }
    public int sPos(String s)
    {
        for (int i = s.length() - 1; i > 0; i--)
        {
            if (s.charAt(i) == 's'){
                return i;
            }
        }
        return -1;
    }

    public int clientReceive(DatagramSocket datagramSocket) throws IOException
    {
        byte[] buffer = new byte[1024];
        DatagramPacket datagramPacket = new DatagramPacket(buffer, buffer.length);
        datagramSocket.receive(datagramPacket);

        String resp = new String(datagramPacket.getData(), datagramPacket.getOffset(), datagramPacket.getLength());
        // 算 rtt
        int sPos = sPos(resp);
        int rtt = Integer.parseInt(
                UDPUtil.subStringByByte(resp, sPos - 3, sPos
                ));
        // 看 RTT，大于 100
        if (rtt > 100)
        {
            // 输出
            System.out.println("sequence no: " + Integer.parseInt(
                    UDPUtil.subStringByByte(resp, UDPUtil.SEQ_BEGIN, UDPUtil.VER_BEGIN
                    )) + ", request time out");
            // 看重传次数，大于 2
            if (Integer.parseInt(
                    UDPUtil.subStringByByte(resp, UDPUtil.RETIME_BEGIN, UDPUtil.SERVERTIME_BEGIN
                    )) >= 2) {
                return UDPUtil.CANNOT_RESEND;
            }
            else {
                return UDPUtil.CAN_RESEND;
            }
        }
        // 合格！进行处理后过！
        // 收到
        if (!UDPUtil.LAST_PKT.equals(UDPUtil.subStringByByte(resp, UDPUtil.SEQ_BEGIN, UDPUtil.VER_BEGIN)) &&
            !UDPUtil.FIRST_PKT.equals(UDPUtil.subStringByByte(resp, UDPUtil.SEQ_BEGIN, UDPUtil.VER_BEGIN)))
        {
            System.out.println("sequence no: " + Integer.parseInt(
                    UDPUtil.subStringByByte(resp, UDPUtil.SEQ_BEGIN, UDPUtil.VER_BEGIN
                    )) + ", serverIP: " + serverIP + ", serverPort: " + serverPort +
                    ",RTT: " + rtt);

            allReceived.put(Integer.parseInt(
                    UDPUtil.subStringByByte(resp, UDPUtil.SEQ_BEGIN, UDPUtil.VER_BEGIN
                    )), resp);
            // RTT 放
            sPos = sPos(resp);
            RTTs.add((long) Integer.parseInt(UDPUtil.subStringByByte(resp, sPos - 3, sPos)));
        }
        return UDPUtil.PASS;
    }
    /**
     * 客户端发包
     */
    public void clientSend() throws IOException
    {
        String udpRequestPacket = null;
        // 重发的次数
        int re = 0;
        DatagramPacket datagramPacket;
        for (int i = UDPUtil.PKG_BEGIN; i <= UDPUtil.PKG_END; i++)
        {
            // “我 UDP「最初」的报文。”
            if (i == 0) {
                udpRequestPacket = generatePacket(String.valueOf(i), UDPUtil.SYN_NOT,
                        String.valueOf(re), UDPUtil.CLIENT_HELLO);
                // 发送
                byte[] data = udpRequestPacket.getBytes(StandardCharsets.UTF_8);
                datagramPacket = new DatagramPacket(data, data.length);
                datagramSocket.send(datagramPacket);
                continue;
            }
            else if (i == 13){
                udpRequestPacket = generatePacket(String.valueOf(i), UDPUtil.SYN_NOT,
                        String.valueOf(re), UDPUtil.CLIENT_BYE);
            }
            // 这里就是我的错误地方了！
            /*
            错因：一开始将 函数的调用放到了 if 里，导致接收函数的部分被执行两次（那个或）
            所以造成了阻塞。
             */
            int res = clientReceive(datagramSocketR);
            // 重置 re，等待发出下一个包
            if (res == UDPUtil.PASS || res == UDPUtil.CANNOT_RESEND) {
                re = 0;
            }
            // 可以重发，i 恢复，re + 1
            else
            {
                i -= 1;
                re += 1;
            }
            // 正常报文
            if (i != 0 && i != 13){
                udpRequestPacket = generatePacket(String.valueOf(i),
                        UDPUtil.SYN_YES, String.valueOf(re),
                        "I am the " + i + " package of client");
            }
            // 发送
            byte[] data = udpRequestPacket.getBytes(StandardCharsets.UTF_8);
            datagramPacket = new DatagramPacket(data, data.length);
            datagramSocket.send(datagramPacket);
        }
    }

    /**
     * 获取 server 的整体响应时间
     */
    public void serverTimeDiff()
    {
        // 通过map.entrySet()获得键值对，性能较高
        Set<Map.Entry<Integer, String>> en = allReceived.entrySet();
        /*
         *  firstTime 取 server 最早的时间
         *  lastTime 取 server 最晚的时间
         */
        long firstTime = new Date().getTime();
        long lastTime = new Date(0).getTime();
        // 遍历 hashMap，为两个变量重新赋值

        for (Map.Entry<Integer, String> entry : en)
        {
            int spos = sPos(entry.getValue());
            firstTime = Math.min(Long.parseLong(UDPUtil.subStringByByte(entry.getValue(),
                    UDPUtil.SERVERTIME_BEGIN, spos - 3)), firstTime);
            lastTime = Math.max(Long.parseLong(UDPUtil.subStringByByte(entry.getValue(),
                    UDPUtil.SERVERTIME_BEGIN, spos - 3)), lastTime);
        }
        serverTime = (lastTime - firstTime) ;
    }

    public static void main(String[] args) throws IOException
    {
        UDPClient udpClient = new UDPClient();
        // 开始发送接收包
        udpClient.clientSend();
        // 输出
        udpClient.myOut();
    }

    /**
     * 输出信息专用函数
     */
    public void myOut()
    {
        // 计算统计信息并输出
        this.setLossRate();
        this.setThreeRTT();
        this.serverTimeDiff();
        System.out.println(
                "接收到了 " + this.allReceived.size() + " 个 udp packets" +
                "\n丢包率为：" + this.lossRate +
                "\n最大 RTT 是：" + this.maxRTT +
                "\n最小 RTT 是：" + this.minRTT +
                "\n平均 RTT 是：" + this.avgRTT +
                "\nRTT 的标准差是：" + this.stdRTT +
                "\nServer 的整体响应时间是：" + this.serverTime);
    }
}


/*
 * 飞翔吧，就像飞鸟那样飞翔吧
 * 带我看看这个世界吧
 * 带我飞到高天之上吧
 */