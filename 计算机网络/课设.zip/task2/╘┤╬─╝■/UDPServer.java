
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class UDPServer
{
    DatagramSocket datagramSocket;
    DatagramSocket datagramSocketS;
    public int iPos(String s)
    {
        for (int i = s.length() - 1; i > 0; i--)
        {
            if (s.charAt(i) == 'I' || s.charAt(i) == 'C'){
                return i;
            }
        }
        return -1;
    }
    public void serverReceive() throws IOException
    {
        String udpRequestPacket;
        // 监听指定端口
        datagramSocket = new DatagramSocket(UDPUtil.PORT);
        datagramSocketS = new DatagramSocket();
        // 连接指定服务器和端口
        datagramSocketS.connect(InetAddress.getByName("192.168.43.185"), 10000);
        while (true)
        {
            // 数据缓冲区:
            byte[] buffer = new byte[1024];
            DatagramPacket datagramPacket = new DatagramPacket(buffer, buffer.length);
            // 收取一个UDP数据包
            datagramSocket.receive(datagramPacket);
            // 收取到的数据存储在 buffer 中，由 packet.getOffset(), datagramPacket.getLength() 指定起始位置和长度
            // 将其按 UTF-8 编码转换为 String:
            udpRequestPacket = new String(datagramPacket.getData(), datagramPacket.getOffset(), datagramPacket.getLength(), StandardCharsets.UTF_8);
            // todo:对报文进行处理
            // 输出信息看看
            int iPos = iPos(udpRequestPacket);
            String data = UDPUtil.subStringByByte(udpRequestPacket, iPos, udpRequestPacket.length());
            System.out.println(data);
            // 生成回复包, 回复
            serverSend(generateReplyPacket(udpRequestPacket), datagramSocketS);
            // 如果是 bye 包，就出循环
            if (UDPUtil.CLIENT_BYE.equals(data)){
                break;
            }
        }
        datagramSocket.close();
        datagramSocketS.close();
    }
    /**
     * server 简单发送一个包
     * @param udpReplyPacket 传过来的包
     */
    public void serverSend(String udpReplyPacket, DatagramSocket datagramSocket) throws IOException
    {
        // 发送数据:
        byte[] data = udpReplyPacket.getBytes(StandardCharsets.UTF_8);
        DatagramPacket datagramPacket = new DatagramPacket(data, data.length);
        datagramSocket.send(datagramPacket);
    }

    /**
     * 设置 rtt
     */
    public String getRTT(String udpRequestPacket)
    {
        // 第一个包
        if (UDPUtil.FIRST_PKT.equals(UDPUtil.subStringByByte(udpRequestPacket, UDPUtil.SEQ_BEGIN, UDPUtil.VER_BEGIN))){
            return UDPUtil.DEFAULT_RTT;
        }
        // 最后的包
        if (UDPUtil.LAST_PKT.equals(UDPUtil.subStringByByte(udpRequestPacket, UDPUtil.SEQ_BEGIN, UDPUtil.VER_BEGIN))){
            return UDPUtil.DEFAULT_RTT;
        }
        Random random = new Random();
        int rtt = random.nextInt(140);
        String srtt = String.valueOf(rtt);
        // 补长度
        if (srtt.length() < 3){
            srtt = "0" + srtt;
        }
        return srtt;
    }

    /**
     * 根据接收到的 request 包生成 reply 包
     * @param udpRequestPacket 从 client 那儿接收到的 request 包
     */
    public String generateReplyPacket(String udpRequestPacket)
    {
        return UDPUtil.subStringByByte(udpRequestPacket, UDPUtil.SEQ_BEGIN, UDPUtil.VER_BEGIN) +
                UDPUtil.VER +
                UDPUtil.SYN_YES +
                UDPUtil.subStringByByte(udpRequestPacket, UDPUtil.RETIME_BEGIN, UDPUtil.SERVERTIME_BEGIN) +
                new Date().getTime() +
                getRTT(udpRequestPacket) + "server return";
    }

    public static void main(String[] args) throws IOException
    {
        UDPServer udpServer = new UDPServer();
        udpServer.serverReceive();
    }
}




/*
 * 飞翔吧，就像飞鸟那样飞翔吧
 * 代我看看这个世界吧
 * 代我飞到高天之上吧
 */