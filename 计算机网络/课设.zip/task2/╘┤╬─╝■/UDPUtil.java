import java.nio.charset.StandardCharsets;

public class UDPUtil
{
    public static final int PORT = 12000;
    public static final int PKT_NUM = 12;
    public static final String SYN_NOT = "0";
    public static final String SYN_YES = "1";
    public static final String FIRST_PKT = "00";
    public static final String LAST_PKT = "13";

    public static final int CANNOT_RESEND = 0;
    public static final int CAN_RESEND = 1;
    public static final int PASS = 2;

    public static final int PKG_BEGIN = 0;
    public static final int PKG_END = 13;

    public static final int SEQ_BEGIN = 0;
    public static final int VER_BEGIN = 2;
    public static final int RETIME_BEGIN = 4;
    public static final int SERVERTIME_BEGIN = 5;

    public static final String VER = "2";
    /**
     * 默认系统时间
     */
    public static final String DEFAULT_SERVER_TIME = "0000000000000";
    /**
     * 默认 RTT
     */
    public static final String DEFAULT_RTT = "000";
    public static final String CLIENT_HELLO = "Client：hello Server!";
    public static final String CLIENT_BYE = "Client：bye Server!";

    /**
     * 按照指定字节位数截取 String(规定字符编码 = UTF-8)
     * @param receiveMsg 字符串
     * @param startIndex 开始处字节索引包含startIndex
     * @param endIndex 结束处字节索引不包含endIndex
     * @return 截取后的字符串
     */
    public static String subStringByByte(String receiveMsg, int startIndex, int endIndex)
    {
        // 将收到的 String 转换为 byte 格式的数组
        byte[] bytes = receiveMsg.getBytes(StandardCharsets.UTF_8);
        int subLen = endIndex - startIndex;
        // 判断起终点位置是否合法
        if (startIndex < 0) {
            return "startIndex 小于 0！";
        }
        if (endIndex > bytes.length) {
            return "endIndex 大于最远长度！";
        }
        if (subLen <= 0) {
            return " endIndex 与 startIndex 之差小于 0！";
        }

        // 创建合适大小的字节串
        byte[] subBytes = new byte[subLen];
        // 填充 byte 数组
        int i = 0;
        while (startIndex < endIndex)
        {
            subBytes[i] = bytes[startIndex];
            i += 1;
            startIndex += 1;
        }
        return new String(subBytes, StandardCharsets.UTF_8);
    }
}
