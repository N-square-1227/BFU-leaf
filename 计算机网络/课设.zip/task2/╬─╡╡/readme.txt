运行环境：

如果在同一台主机上测试用（既当 server 又当 host）：
    运行环境：win 10  idea 2021.3.1 Oracle openJDK 17.0.2
    先把另一个同名文件改个名，再把 UDPServer.txt 后缀改成 .java
    在编译器上开启 server 再启动 client。

1.在文件所属目录下右键--点击”在这里打开终端“
依次输入 javac UDPUtil.java, javac UDPServer.java，javac  UDPClient.java
若编译通过（我测试是通过的）会在当前目录下生成三个文件对应的.class 字节码文件

3.主机打开 wireshark，网卡选择 loopback，开始捕获报文

3.在终端中输入 java UDPServer，开启服务器

4.输入java UDPClient 程序，输入serverIP：127.0.0.1，serverPort：12000

5.愉快地观察输入输出以及报文抓包结果~

——————————————————————————————————————
主机client + 虚拟机server：
    运行环境：windows10， Ubuntu 20.04。

	windows jdk： Oracle openJDK 17.0.2
	Ubuntu jdk： openjdk 11.0.16 2022-07-19
	                    OpenJDK Runtime Environment (build 11.0.16+8-post-Ubuntu-0ubuntu120.04)
	                    OpenJDK 64-Bit Server VM (build 11.0.16+8-post-Ubuntu-0ubuntu120.04, mixed mode, sharing)


运行说明：


1.首先在将UDPUtil.java,  UDPServer.java，  UDPClient.java, 这三个文件传到虚拟机上，
将 UDPServer.java 第 28 行的 IP 改成自己的虚拟机 IP

2.在文件所属目录下右键--点击”在这里打开终端“
依次输入 javac UDPUtil.java, javac UDPServer.java
若编译通过（我测试是通过的）会在当前目录下生成文件对应的.class 字节码文件

3.主机打开 wireshark，网卡选择 VMnet8，开始捕获报文

3.在虚拟机终端中输入 java UDPServer，开启服务器

4.在主机中运行 UDPClient.java 程序，输入serverIP：192.168.159.129，serverPort：12000

5.愉快地观察输入输出以及报文抓包结果~