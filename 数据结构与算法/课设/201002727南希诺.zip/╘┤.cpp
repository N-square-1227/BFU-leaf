﻿#include<bits/stdc++.h>
#include<iostream>
#include<Windows.h>
using namespace std;
const int MAXSIZE = 200;
const int MAXROUTE = 10000;//4.4用
const double CMP = 1e-6;//4.2快排，浮点数比大小
/* eg
  日期      开盘价  收盘价 最高价 最低价 成交量（手） 成交额（万元） 换手率 涨跌额 涨跌幅（%）
 20211108   18.38  18.31  18.6  18.13 1204523.83     221103      0.00% 0.49   2.75%
 */
typedef struct UpDown//股票每日涨跌数据 
{
	//      日期   换手率      涨跌幅（%） 
	string date, ChangeRate, UpdownRate;
	double oprice, cprice, high, low, OkNum, OkProfit, UpdownProfit;
	//     开盘价   收盘价 最高价 最低价 成交量 成交额（万元）   涨跌额 
};
typedef struct Stock//股票
{        //代码   名称  行业编码 一级门类 二级门类，网址，主营业务
	string code, name, workcode, fir, sec, web, business;
	string MaxUpdownRate, MaxUPDate;//4.2用，非每个企业都有
	float MaxUpdownRateNum;//非每个企业都有
	float UpDownRateNum;//同上
	float score;//4.3专用，非每个企业都有
	int vexnum;//4.4专用，非每个企业都有
	UpDown daily[162];//每个txt文件里有这么多数据,■ ■ ■ 原来是这里多数了一个
};
typedef struct LNode//链表
{
	Stock  data;
	struct LNode* next;
}*LinkList, LNode;
typedef struct BNode//二叉排序树
{
	Stock data;
	string date;
	struct BNode* lchild, * rchild;
}*BTree, BNode;
typedef struct Vex//顶点
{
	Stock data;
	int num;
};
typedef struct//邻接矩阵
{
	int matrix[61][61];//用1-60
}AMGraph;
typedef struct Queue//队列
{
	int arr[20];
	int front;
	int rear;
	int counter;//记录队列中元素个数
} Queue;
typedef struct Edge//5.1,边
{
	int from;
	int to;//与边相邻的两个点
	int weight;//边的权值
};


int Next[50];//KMP算法需要的辅助数组
int floor1 = 0;//3.3用
int dist[61][61];//4.5,4.6 一起用.dist -- 长度数组。即，dist[i][j]=sum表示，"顶点i"到"顶点j"的最短路径的长度是sum。
Stock Data[200];//3.3 new BTree 用，存储了200支股票的所有信息，谁都可以用~
Edge ConEdge[1653];//5.1,连通的相邻边,ecnt知道了后回来改的,ecnt=1653说明连通网中有这么多条点是相通的
LinkList HT[97];//Real哈希

//Captain In Bridge!
void CaptainOnBridge()
{
	cout << endl << "				  欢迎登录股票查询与分析系统！本系统主要包括查询和分析两个功能！" << endl;
	cout << endl << "						      查询功能如下：" << endl << endl;
	cout << "		功能1：输入股票代码，查询股票名称、股票代码、股票所属一级行业、所属二级行业、主营业务，同时输出查找成功的ASL。" << endl << endl;
	cout << "		功能2：根据输入的网址字符串的子串，查询所有股票的“网址”字段，如果匹配成功，输出该股票的名称和代码。" << endl << endl;
	cout << "		功能3：输入股票代码，查询得到股票最近一日的开盘价、收盘价和涨跌幅，同时输出查找成功的ASL。" << endl << endl;
	cout << "		功能4：输入日期，查询当日所有股票的开盘价、收盘价和涨跌幅。" << endl << endl;
	cout << endl << "					               分析功能如下：" << endl << endl;
	cout << "		功能5：输入日期，分别按照“开盘价”、“收盘价”和“涨跌幅”对所有股票进行排序，并输出排序后的结果。" << endl << "		结果包括“序号”+“股票代码”+“股票名称”+“开盘价”+“收盘价”+“涨跌幅”。" << endl << "		同时,将排序后的结果按照输出的格式存储在excel文件中，文件名为“价格和涨跌幅排序结果”。" << endl << endl << endl;
	cout << "		功能6：输入一级行业名称，根据每支股票数据中的最大涨跌幅，对同一行业内的股票进行由高到低的排序。" << endl << "		输出结果为“序号”+“股票代码”+“股票名称”+“涨跌幅”+“日期”。" << endl << endl << endl;
	cout << "		功能7：对有评分的股票数据根据股票的评分或最近一日的“收盘价”进行排序。" << endl << "		每行由高到低输出结果，包括“序号”+“股票代码”+“股票名称”+“收盘价”。" << endl << "		同时，将两个排序后的结果按照输出的格式存储在两个excel文件中，文件名分别为“评分排序”及“收盘价排序”。" << endl << endl << endl;
	cout << "		功能8：这个功能可以计算任意两支股票之间的最短距离，将输出任意两点（两支股票）间的最短路径。" << endl << endl;
	cout << "		功能9：Q宝为你智能挑选6支股票作为最优的基金组合！" << endl << "		输出包含“边的权值”+“边的结点1：股票名称”+“边的结点2：股票名称”。" << endl << "		注：若多条边权值相等，则根据企业评分排序~" << endl << endl;
	cout << "		功能10：任意输入的十个有序号的股票的序号，（数字范围为[1,60]）。" << endl << "		输出结果给出是否可以构成二部图，如果是二部图，则以“序号”+“股票名称”的形式给出节点的结果。" << endl << "		注：若不是二部图，直接输出“不是二部图”。" << endl << endl;
	cout << "		功能11：魔法少女Teriri为你智能挑选6支股票作为最优的基金组合！" << endl << "		输出包含“边的权值”+“边的结点1：股票名称”+“边的结点2：股票名称”。" << endl << "		注：若多条边权值相等，则根据企业评分排序~" << endl << "		（使用该功能后将直接退出程序）" << endl << endl;
	cout << "请输入你希望使用的功能的数字~：";
}

//3.1 哈希表
/*
在哈希表中，要是上下楼的话靠的不是上一个的指针，而是用外层控制循环的变量i来做到随机访问每一个地方的
如果使用next的方法，那么指的就是横行了
链地址法的查找ASL为：1+α/2，α为装填因子=记录数/长度
*/
void HashASL(LinkList HT[])//计算哈希表ASL 
{
	int count[200] = { 0 }, max = 0;//count[0]不用
	float ASL = 0;
	for (int i = 0; i < 97; i++)
	{
		int j = 1;
		LinkList p = HT[i];
		while (p->next)
		{
			count[j]++;
			j++;
			p = p->next;
		}
		if (j > max)
			max = j;
	}
	for (int i = 1; i <= max; i++)
		ASL += i * count[i];
	cout << ASL / 200;
}
void HashRemake(LinkList lk)//建立哈希表
{
	for (int i = 0; i < 97; i++)    //初始化哈希表
	{
		HT[i] = new LNode;
		HT[i]->next = NULL;
	}
	LinkList p = lk->next;
	while (p)//遍历大链表，创建新链表
	{
		int num = 0;
		for (int i = 0; i < 9; i++)
			num += p->data.code[i] - '0';
		num %= 97;//num是该节点在新链表里的位置

		LinkList rear = HT[num];
		while (rear->next)  //rear移动到下标为num的单链表的尾部,尾插
			rear = rear->next;

		LinkList q = new LNode;
		q->data = p->data;
		q->next = NULL;
		rear->next = q;   //将结点q插入单链表尾部 
		rear = rear->next;

		p = p->next;
	}
	HashASL(HT);
}
int FindPos(string s)//看当前公司在哈希表的哪一位,3.1用
{
	int Number = 0;
	for (int i = 0; i < s.length(); i++)
		Number += s[i] - '0';//获得股票代码的每个字符的值的和
	return Number % 97;
}
void CreateTable(LinkList ht[])//读文件，创建哈希表 
{
	for (int i = 0; i < 97; i++)
	{
		ht[i] = new LNode;
		ht[i]->next = NULL;
	}
	//————————————————————————————————————————————————读文件——————————————————————————————————————————————————
	ifstream ifs;							//创建流对象
	ifs.open("A股公司简介.csv", ios::in);	//打开文件
	if (!ifs.is_open())						//判断文件是否打开
	{
		cout << "csv文件打开失败\_(ツ)_/\n" << endl;
		return;
	}
	string line;//临时存储文件中的一行数据
	int flag = 0;
	while (getline(ifs, line))  //利用 getline（）读取文件中的每一行
	{
		stringstream ss(line);
		string sub;
		//一次性读一行的写法:
		//while (getline(ss, sub, '\n'))                           
		if (flag)
		{
			LinkList temp = new LNode;
			//向徐向波老师学习xd
			getline(ss, sub, ',');
			temp->data.code = sub;

			/*——————————————————————————读当前企业对应的txt文件，并存数据到UpDown数组中——————————————————————*/
			string text = sub + ".txt";
			ifstream ifsTXT;							//创建流对象
			string lineTXT;                            //临时存储文件中的一行数据
			ifsTXT.open(text, ios::in);	              //打开文件：改错（不会嘛）
			if (!ifsTXT.is_open())						//判断文件是否打开
			{
				cout << "txt文件打开失败\_(ツ)_/\n" << endl;
				return;
			}
			int i = -1, flagTXT = 0;
			while (getline(ifsTXT, lineTXT, '\n'))
			{
				stringstream ssTXT(lineTXT);
				string subTXT;//临时存储一个数据项
				double ssubTXT;
				if (flagTXT)
				{
					getline(ssTXT, subTXT, ' ');
					temp->data.daily[i].date = subTXT;

					getline(ssTXT, subTXT, ' ');
					ssubTXT = stof(subTXT);//改错：string 转 double
					temp->data.daily[i].oprice = ssubTXT;

					getline(ssTXT, subTXT, ' ');
					ssubTXT = stof(subTXT);
					temp->data.daily[i].cprice = ssubTXT;

					getline(ssTXT, subTXT, ' ');
					ssubTXT = stof(subTXT);
					temp->data.daily[i].high = ssubTXT;

					getline(ssTXT, subTXT, ' ');
					ssubTXT = stof(subTXT);
					temp->data.daily[i].low = ssubTXT;

					getline(ssTXT, subTXT, ' ');
					ssubTXT = stof(subTXT);
					temp->data.daily[i].OkNum = ssubTXT;

					getline(ssTXT, subTXT, ' ');
					ssubTXT = stof(subTXT);
					temp->data.daily[i].OkProfit = ssubTXT;

					getline(ssTXT, subTXT, ' ');
					temp->data.daily[i].ChangeRate = subTXT;

					getline(ssTXT, subTXT, ' ');
					ssubTXT = stof(subTXT);
					temp->data.daily[i].UpdownProfit = ssubTXT;

					getline(ssTXT, subTXT, ' ');
					temp->data.daily[i].UpdownRate = subTXT;
				}
				flagTXT++;
				i++;
			}
			ifsTXT.close();
			/*————————————————————————————txt文件读取完毕——————————————————————*/
			getline(ss, sub, ',');
			temp->data.name = sub;

			getline(ss, sub, ',');
			temp->data.workcode = sub;

			getline(ss, sub, ',');
			temp->data.fir = sub;

			getline(ss, sub, ',');
			temp->data.sec = sub;

			for (int i = 0; i < 7; i++)
				getline(ss, sub, ',');

			getline(ss, sub, ',');
			temp->data.web = sub;

			for (int i = 0; i < 2; i++)
				getline(ss, sub, ',');

			getline(ss, sub, ',');
			temp->data.business = sub;
			/*------------------------ - 读csv文件的一行完毕-------------------- - */
			//插入
			int pos = FindPos(temp->data.code);
			LinkList p = ht[pos];
			while (p->next)
				p = p->next;
			temp->next = NULL;
			p->next = temp;   //尾插法

			Data[flag - 1] = temp->data;//改错：不同顺序创建出的排序二叉树是不一样的！！！！！！！！！！！折磨我两个小时！！！！！
		}
		flag++;
	}
}
void StockInfoHash(LinkList ht[])//基于哈希表的股票基本信息查询，输入输出部分 
{
	/*输入股票代码
	  输出“股票名称”、“股票代码”、“股票所属一级行业”、“所属二级行业”、“主营业务”
	  同时输出查找成功的ASL。*/
	cout << "注意：如果输入的代码错误，则不输出信息；" << endl;
label:
	cout << "请输入要查询的股票代码，如：cn_002142：";
	string code;
	cin >> code;
	int pos = FindPos(code);
	while (pos < 0 || pos>96)
	{
		cout << "这个代码不对应任何股票，重新输入一次吧！" << endl << "请输入要查询的股票代码：";
		code = "";
		cin >> code;
		int pos = FindPos(code);
	}
	//有对应的股票
	LinkList p = ht[pos]->next;
	int flag = 0;
	while (p)
	{
		if (code == p->data.code)
		{
			cout << endl << "股票名称：" << p->data.name << endl << "股票代码： " << p->data.code << endl << "所属一级行业：" << p->data.fir << endl << "所属二级行业：" << p->data.sec << endl << "主营业务:" << p->data.business << endl;
			break;
		}
		p = p->next;
	}

	cout << endl << "哈希表查找的ASL为：";
	HashRemake(*ht);
	cout << endl << "继续查找请按y，否则按除回车外的任意键，再按回车键返回主菜单：";
	string c;
	cin >> c;
	if (c == "y")
		goto label;
	else
	{
		CaptainOnBridge();
		return;
	}
}


//5.2 基于二叉排序树的股票基本信息删除
/*O(logn)~O(n)*/
void TreeRemake(BTree& bt, Stock s)//建立二叉树
{
	if (bt == NULL)
	{
		bt = new BNode;
		bt->data = s;
		bt->lchild = NULL;
		bt->rchild = NULL;
		return;
	}
	else
	{
		if (s.code < bt->data.code)
			TreeRemake(bt->lchild, s);    //比当前结点小 放左边 
		else
			TreeRemake(bt->rchild, s);  //比当前结点值大 放右边
	}
}
int GetWidth(BTree bt, int& depth, int width[])//DFS获得二叉树每层的节点个数 
{
	depth++;//每进入一次，深度加一
	if (bt == NULL) //如果节点为空，return并且深度减一
	{
		depth--;
		return 1;
	}
	else
	{
		width[depth]++;//如果此节点有数据，该深度的节点个数加一，即宽度加一 
		GetWidth(bt->lchild, depth, width);
		GetWidth(bt->rchild, depth, width);
		depth--;//当左右都节点遍历完成后，会退回双亲结点，所以深度减一
	}
}
void BTreeASL(BTree bt)//计算二叉树ASL 
{
	int depth = 0, width[200] = { 0 };
	int ASL = 0;
	GetWidth(bt, depth, width);

	for (int i = 1; i < 200; i++)
	{
		if (width[i] == 0)//二叉树到底了，终止循环
			break;
		ASL += i * width[i];
	}
	cout << (double)ASL / 200;
}
void NewBTree(BTree& nbt, LinkList lk)
{
	for (int i = 0; i < 200; i++)
		TreeRemake(nbt, Data[i]);
	BTreeASL(nbt);
}
//3.3 基于二叉排序树的股票基本信息查询old
/*
最好：log2n（形态匀称，与二分查找的判定树相似）
最坏:（n+1)/2（单支树）
*/
void CreateTree(BTree& bt, LinkList lk, int i)//通过遍历链表的方式创建
{
	bt = new BNode;
	bt->data = lk->data;
	bt->date = lk->data.daily[i].date;
	bt->lchild = NULL;
	bt->rchild = NULL;
}
void InsertTree(BTree& bt, LinkList lk, int i)//非递归插入 
{
	BTree temp = bt;
	if (lk->data.daily[i].date < bt->date)
	{
		while (lk->data.daily[i].date < bt->data.daily->date && temp->lchild)//日期比当前节点靠前，放左边
			temp = temp->lchild;
		CreateTree(temp->lchild, lk, i);
	}
}
LinkList GetLNode(string s, LinkList lk)//通过输入的股票序号找到链表里对应的那个节点
{
	LinkList p = lk->next;
	while (p)
	{
		if (p->data.code == s)
			return p;
		p = p->next;
	}
	return NULL;
}
BTree Traverse(string s, BTree bt, BTree& templ, BTree& tempr)//遍历二叉树找目标节点 
{
	if (!bt)
		return NULL;
	else
	{
		floor1++;
		templ = bt;//前一个节点
		if (s == bt->date)
			return bt;
		if (s > bt->date)
			return NULL;
		return Traverse(s, bt->lchild, templ, tempr);
		tempr = bt;//后一个节点
	}
}
void Search(BTree& bt, string s, BTree& del, BTree& parent)//获取要删除节点的父节点 
{
	while (bt != NULL)
	{
		if (bt->data.code == s)
		{
			del = bt;
			return;
		}
		else if (bt->data.code > s)
		{
			parent = bt;
			bt = bt->lchild;
		}
		else
		{
			parent = bt;
			bt = bt->rchild;
		}
	}
}
void DelBNode(BTree& bt, string cd)//5.2 删除主函数，判断节点的位置以及做删除结点的工作 
{
	BTree del = NULL, parent = NULL;
	Search(bt, cd, del, parent);

	if (del == NULL)
		return;
	if (!del->lchild && !del->rchild)//要删的是叶子节点
	{
		cout << "这是叶子节点，删了之后这里就没东西了，它也没有左右子节点！" << endl;
		BTree temp = bt;
		delete temp;
		temp = NULL;
		return;
	}
	else if ((del->lchild && !del->rchild) || (!del->lchild && del->rchild))//单枝
	{
		BTree child = NULL;
		if (del->lchild && !del->rchild)//左单支
			child = del->lchild;
		else if (!del->lchild && del->rchild)//右单枝
			child = del->rchild;
		cout << "名称：" << child->data.name << endl << "代码：" << child->data.code << endl << "行业：" << child->data.business << endl << "网址：" << child->data.web << endl;

		BTree temp = del;
		if (parent->lchild == del)
			parent->lchild = child;
		else if (parent->rchild == del)
			parent->rchild = child;
		delete temp;
		temp = NULL;

		if (child->lchild)
			cout << endl << "左孩子节点信息：" << endl << "名称：" << child->lchild->data.name << endl << "代码：" << child->lchild->data.code << endl << "行业：" << child->lchild->data.business << endl << "网址：" << child->lchild->data.web << endl;
		if (child->rchild)
			cout << endl << "右孩子节点信息：" << endl << "名称：" << child->rchild->data.name << endl << "代码：" << child->rchild->data.code << endl << "行业：" << child->rchild->data.business << endl << "网址：" << child->rchild->data.web << endl;
	}
	else//del是根节点
	{
		//看这篇文章吧，我觉得讲的很好
		//https://blog.csdn.net/zxnsirius/article/details/52131433
		//左子树的最右叶子节点 或 右子树的最左节点
		parent = del;  //父节点指向当前节点
		BTree NextNode = NULL;
		NextNode = del->lchild;   //设置子节点
		while (NextNode->rchild != NULL)
		{
			parent = NextNode;
			NextNode = NextNode->rchild;
		}
		del->data = NextNode->data;  //替换数据
		cout << "名称：" << del->data.name << endl << "代码：" << del->data.code << endl << "行业：" << del->data.business << endl << "网址：" << del->data.web << endl << endl;
		cout << "左孩子节点信息：" << endl << "名称：" << del->lchild->data.name << endl << "代码：" << del->lchild->data.code << endl << "行业：" << del->lchild->data.business << endl << "网址：" << del->lchild->data.web << endl << endl;
		cout << "右孩子节点信息：" << endl << "名称：" << del->rchild->data.name << endl << "代码：" << del->rchild->data.code << endl << "行业：" << del->rchild->data.business << endl << "网址：" << del->rchild->data.web << endl << endl;

		//把NextNode“移动”到del的位置上
		if (parent->lchild == NextNode)
			parent->lchild = NextNode->lchild;
		else
			parent->rchild = NextNode->rchild;
		delete NextNode;
		NextNode = NULL;
	}
}
void StockInfoTree(BTree& bt, LinkList lk)//3.3基于二叉排序树的股票基本信息查询
{
	/*
	  输入股票代码
	  输出包括最近一日的“开盘价”、“收盘价”和“涨跌幅”，同时输出查找成功的ASL。
	*/
label:
	cout << "请输入待查询的股票代码：";
	string s;
	cin >> s;
	string cd = s;
	LinkList p = GetLNode(s, lk);//Test OK
	cout << endl << "请输入要查询的日期（格式年月日，数字，之间不用分隔）：";
	cin >> s;
	CreateTree(bt, p, 0);
	BTree bt2 = bt;
	BTree templ = new BNode, tempr = new BNode;//设置临时变量用来存储与输入日期最近的数据
	for (int k = 1; k < 162; k++)
		InsertTree(bt, p, k);
	BTree ans = Traverse(s, bt2, templ, tempr);
	if (ans == NULL)//输入的日期与所有的日期都不匹配，输出templ或者tempr的数据
	{
		cout << "该股票在你要查询的日期没有变化哦~不过我为你找到了最近的数据，你可以参考一下：" << endl;
		cout << "日期：" << templ->date << endl << "开盘价：" << templ->data.daily[floor1].oprice << endl << "收盘价：" << templ->data.daily[floor1].cprice << endl << "涨跌幅：" << templ->data.daily[floor1].UpdownRate << endl;
	}
	else//输入的日期和已有的能对上，直接输出已有的数据即可
	{
		cout << "你所查询的日期中股票有波动，请看消息：" << endl;
		floor1--;
		cout << "日期：" << ans->date << endl << "开盘价：" << ans->data.daily[floor1].oprice << endl << "收盘价：" << ans->data.daily[floor1].cprice << endl << "涨跌幅：" << ans->data.daily[floor1].UpdownRate << endl;
	}
	cout << "二叉排序树的ASL为：";
	BTree nbt = NULL;
	NewBTree(nbt, lk);
	//现在nbt不是NULL了
	cout << endl << "		你开启了隐藏的支线功能！" << endl << "		这个功能可以根据删除刚才建立的树的节点，并且告诉你该节点位置的新节点信息以及左右子节点信息！要试试吗？（y）：";
	char x;
	cin >> x;
	if (x == 'y')
		DelBNode(nbt, cd);
	cout << endl;
	floor1 = 0;
	cout << "你还要继续查吗？(y表示是，否则按任意键回车返回上级菜单）：";
	char c;
	cin >> c;
	if (c == 'y')
		goto label;
	else
	{
		CaptainOnBridge();
		return;
	}
}

//3.2 KMP
/*
KMP的时间复杂度是：匹配过程的时间复杂度为O (n)，计算next的O (m)时间，两个独立的环节串行，所以整体时间复杂度为O (m + n)
开辟了一个新的Next数组，所以空间复杂度：O(m)
*/
void GetNext(string sub)//初始化next数组 
{
	Next[0] = 0;//容器的首位必定为0
	int k = 1;
	for (int i = 1, j = 0; i < sub.length(); i++)//i来控制循环次数，0号位是0，所以从1号位开始了
	{
		while (j > 0 && sub[j] != sub[i])
			j = Next[j - 1];
		if (sub[i] == sub[j])//比对上了，j继续往下移动
			j++;
		Next[k++] = j;
	}
}
bool KMPMain(LinkList p, string target, string sub)//KMP查找主函数 
{
	for (int i = 0, j = 0; i < p->data.web.length(); i++)//主串永不回退
	{
		while (j > 0 && target[i] != sub[j])
			j = Next[j - 1];
		if (target[i] == sub[j])
			j++;
		if (j == sub.length())
			return true;//找到了,直接返回
	}
	return false;
}
void StockWeb(LinkList ht[])//基于KMP的股票网址查询
{
	//根据输入的网址字符串的子串，查询所有股票的网址字段，如果匹配成功，则输出该股票的名称和代码。
	//输入的字符串可以是公司全部名称或部分名称
	for (int i = 0; i < 50; i++)
		Next[i] = 0;//Next数组初始化
label:
	cout << "请输入要查询的股票网址（可以是全部网址或部分网址字段）：";
	string s;
	cin >> s;
	GetNext(s);
	for (int i = 0; i < 97; i++)//从上到下遍历整个哈希表（大链表（■ ■
	{
		LinkList p = ht[i]->next;
		while (p != NULL)
		{
			if (KMPMain(p, p->data.web, s) == true)//找到了
			{
				cout << "该股票名称为：" << p->data.name << " " << "股票代码为：" << p->data.code << endl;
				cout << "继续查找请按y，否则按任意键返回上级菜单：";
				char c;
				cin >> c;
				if (c == 'y')
					goto label;
				else
				{
					CaptainOnBridge();//改错：把菜单和选项分开
					return;
				}
			}
			p = p->next;
		}
	}
	cout << "没有找到你输入字段所对应的公司哦！请检查是否输入有误~" << endl;
	goto label;
}

//3.4 基于单链表的股票价格信息查询
/*
时间复杂度O(n)
*/
void InitList(LinkList& lk)//初始化链表 
{
	lk = new LNode;
	lk->next = NULL;
}
LinkList GetRear(LinkList p)//获取链表尾节点 
{
	LinkList rear = p;
	while (rear->next)
		rear = rear->next;
	return rear;
}
void CreateList(LinkList ht[], LinkList& lk)//遍历哈希表（），创建单链表
{
	LinkList rear = lk;
	for (int i = 0; i < 97; i++)
	{
		LinkList p = ht[i]->next;
		if (p)
		{
			rear = GetRear(lk);//当前主链表的尾端（NULL前面那个节点）
			rear->next = p;//尾端连上p
		}
	}
}
void StockPrice(LinkList lk)//3.4基于单链表的股票价格信息查询
{
	//输入为“日期”,查询某一日所有股票的“开盘价”、“收盘价”和“涨跌幅”。
label:
	cout << "请输入需要查找的日期：";
	string s;
	cin >> s;
	LinkList p = lk->next;
	int flag = 0;
	int i = 0;
	while (p)
	{
		while (i != 162)
		{
			if (p->data.daily[i++].date == s)
			{
				cout << "股票代码:" << p->data.code << endl << "股票名称:" << p->data.name << endl << "开盘价:" << p->data.daily[i].oprice << endl << "收盘价:" << p->data.daily[i].cprice << endl << "涨跌幅:" << p->data.daily[i].UpdownRate << endl << endl;
				flag = 1;//输出过数据，说明不用考虑鲁棒性
			}
		}
		i = 0;
		p = p->next;
	}
	if (flag == 0)//查询的日期没数据
		cout << "这一天没有股票有价格波动哦！换个日期或者检查下日期输入是否合法吧！" << endl;
	cout << "你还要继续查吗？(y表示是，否则按任意键回车返回上级菜单）：";
	char c;
	cin >> c;
	if (c == 'y')
		goto label;
	else
	{
		CaptainOnBridge();
		return;
	}
}
int GetDatePos(string s, LinkList p)//根据日期找下标，链表适配
{
	int i = 0;//i从0开始计数的，要是有错看一下这里
	while (1)
	{
		if (p->data.daily[i].date == s)//该日期就是查找的日期
			return i;
		i++;
	}
}

//4.1 插入排序  基于直接插入排序的股票价格分析
/*
时间复杂度
在插入排序中，当待排序数组是有序时是最优的情况，只需当前数跟前一个数比较一下就可以了，这时一共需要比较N- 1次，时间复杂度为O(n)。
最坏的情况是待排序数组是逆序的，此时需要比较次数最多，总次数记为：1+2+3+…+N-1，所以，插入排序最坏情况下的时间复杂度为 O(n^2)。
平均来说，A[1..j-1]中的一半元素小于A[j]，一半元素大于A[j]。插入排序在平均情况运行时间与最坏情况运行时间一样，是输入规模的二次函数。
空间复杂度
插入排序的空间复杂度为常数阶O(1)
*/
bool CaseFirst(string dt, LinkList& lk)//根据开盘价排序 
{
	long date = stoi(dt);
	if (date <= 20211108 && date >= 20210311)//鲁棒性
	{
		int pos = GetDatePos(dt, lk->next);
		LinkList p, pnext, pre, first;
		first = lk->next;
		p = first->next;
		first->next = NULL;//把两个链表断开
		while (p)
		{
			pnext = p->next;
			pre = lk;
			while (pre->next != NULL && pre->next->data.daily[pos].oprice > p->data.daily[pos].oprice)//找到旧链表里第一个小于新链表数据的位置
				pre = pre->next;
			//插入
			p->next = pre->next;
			pre->next = p;
			p = pnext;
		}
		int i = 1;
		ofstream ofile;
		ofile.open("价格和涨跌幅排序结果(按开盘价排序）.csv", ios::out | ios::trunc);
		p = lk->next;
		while (p)
		{
			cout << endl << "序号：" << i << endl << "股票代码：" << p->data.code << endl << "股票名称：" << p->data.name << endl << "开盘价：" << p->data.daily[pos].oprice << endl << "收盘价：" << p->data.daily[pos].cprice << endl << "涨跌幅：" << p->data.daily[pos].UpdownRate << endl;
			ofile << "序号" << "," << "股票代码" << "," << "股票名称" << "," << "开盘价" << "," << "收盘价" << "," << "涨跌幅" << endl;
			ofile << i << "," << p->data.code << "," << p->data.name << "," << p->data.daily[pos].oprice << "," << p->data.daily[pos].cprice << "," << p->data.daily[pos].UpdownRate << endl;
			i++;//不要i++。。。。。。
			p = p->next;
		}
		return true;
	}
	else
	{
		cout << "日期不合法哦，请重新输入吧" << endl;
		return false;
	}
}
bool CaseSecond(string dt, LinkList lk)//根据收盘价排序 
{
	long date = stoi(dt);
	if (date <= 20211108 && date >= 20210311)//鲁棒性
	{
		int pos = GetDatePos(dt, lk->next);
		LinkList p, pnext, pre, first;
		first = lk->next;
		p = first->next;
		first->next = NULL;//把两个链表断开
		while (p)
		{
			pnext = p->next;
			pre = lk;
			while (pre->next != NULL && pre->next->data.daily[pos].cprice > p->data.daily[pos].cprice)//找到旧链表里第一个小于新链表数据的位置
				pre = pre->next;
			//插入
			p->next = pre->next;
			pre->next = p;
			p = pnext;
		}
		int i = 1;
		ofstream ofile;
		ofile.open("价格和涨跌幅排序结果(按收盘价排序）.csv", ios::out | ios::trunc);
		p = lk->next;
		while (p)
		{
			cout << endl << "序号：" << i << endl << "股票代码：" << p->data.code << endl << "股票名称：" << p->data.name << endl << "开盘价：" << p->data.daily[pos].oprice << endl << "收盘价：" << p->data.daily[pos].cprice << endl << "涨跌幅：" << p->data.daily[pos].UpdownRate << endl;
			ofile << "序号" << "," << "股票代码" << "," << "股票名称" << "," << "开盘价" << "," << "收盘价" << "," << "涨跌幅" << endl;
			ofile << i << "," << p->data.code << "," << p->data.name << "," << p->data.daily[pos].oprice << "," << p->data.daily[pos].cprice << "," << p->data.daily[pos].UpdownRate << endl;
			i++;//不要i++。。。。。。
			p = p->next;
		}
		return true;
	}
	else
	{
		cout << "日期不合法哦，请重新输入吧" << endl;
		return false;
	}
}
bool CaseThird(string dt, LinkList lk)//根据涨跌幅排序 
{
	long date = stoi(dt);
	if (date <= 20211108 && date >= 20210311)//鲁棒性
	{
		int pos = GetDatePos(dt, lk->next);
		LinkList p, pnext, pre, first;
		first = lk->next;
		p = first->next;
		first->next = NULL;//把两个链表断开
		while (p)
		{
			string ps = p->data.daily[pos].UpdownRate.substr(0, p->data.daily[pos].UpdownRate.length() - 1);
			float psd = stof(ps);
			p->data.UpDownRateNum = psd;

			pnext = p->next;
			pre = lk;
			string pres = pre->next->data.daily[pos].UpdownRate.substr(0, pre->next->data.daily[pos].UpdownRate.length() - 1);
			float presd = stof(pres);
			pre->next->data.UpDownRateNum = presd;

			while (pre->next != NULL && pre->next->data.UpDownRateNum > p->data.UpDownRateNum)//找到旧链表里第一个小于新链表数据的位置
				pre = pre->next;
			//插入
			p->next = pre->next;
			pre->next = p;
			p = pnext;
		}
		int i = 1;
		ofstream ofile;
		ofile.open("价格和涨跌幅排序结果(按涨跌幅排序）.csv", ios::out | ios::trunc);
		p = lk->next;
		while (p)
		{
			cout << endl << "序号：" << i << endl << "股票代码：" << p->data.code << endl << "股票名称：" << p->data.name << endl << "开盘价：" << p->data.daily[pos].oprice << endl << "收盘价：" << p->data.daily[pos].cprice << endl << "涨跌幅：" << p->data.daily[pos].UpdownRate << endl;
			ofile << "序号" << "," << "股票代码" << "," << "股票名称" << "," << "开盘价" << "," << "收盘价" << "," << "涨跌幅" << endl;
			ofile << i << "," << p->data.code << "," << p->data.name << "," << p->data.daily[pos].oprice << "," << p->data.daily[pos].cprice << "," << p->data.daily[pos].UpdownRate << endl;
			i++;//不要i++。。。。。。
			p = p->next;
		}
		return true;
	}
	else
	{
		cout << "日期不合法哦，请重新输入吧" << endl;
		return false;
	}
}
void InsertSort(LinkList lk)//插入排序主函数 
{
	LinkList p = lk->next;
	cout << "请输入日期以进行排序：";
	string s;
	cin >> s;
label:
	cout << endl << "排序规则：1.“开盘价” 2.“收盘价” 3.“涨跌幅”，请输入规则对应的数字：";
	int x;
	cin >> x;
	//改错：变量之间用中文逗号隔开，怪不得不认识嗷??
	switch (x)
	{
	case 1:
	{
		int flag = CaseFirst(s, lk);
		if (!flag)
			goto label;
		break;
	}
	case 2:
	{
		int flag = CaseSecond(s, lk);
		if (!flag)
			goto label;
		break;
	}
	case 3:
	{
		int flag = CaseThird(s, lk);
		if (!flag)
			goto label;
		break;
	}
	default:
	{
		cout << endl << "输入不对哦，再重新输入吧：";
		goto label;
	}
	}
	cout << "你还要继续查吗？(y表示是，否则按任意键回车返回上级菜单）：";
	char c;
	cin >> c;
	if (c == 'y')
		goto label;
	else
	{
		CaptainOnBridge();
		return;
	}
}

//4.2 快速排序（从大到小）
/*
在平均状况下，排序 n 个项目要 Ο(nlogn) 次比较。在最坏状况下则需要 Ο(n2) 次比较，但这种状况并不常见。

从数列中挑出一个元素，称为 "基准"（pivot）;
重新排序数列，所有元素比基准值小的摆放在基准前面，所有元素比基准值大的摆在基准的后面（相同的数可以到任一边）。在这个分区退出之后，该基准就处于数列的中间位置。这个称为分区（partition）操作；
递归地（recursive）把小于基准值元素的子数列和大于基准值元素的子数列排序；
*/
void QuickSort(Stock arr[], int left, int right)//快排 算法 
{
	if (left < right)
	{
		int lo = left, hi = right;
		Stock pivot = arr[left];
		while (lo < hi)
		{
			//改错：浮点数只能比较纯大于或纯小于，但凡带一点等号都不行，都得用绝对值的方法判断！
			while (arr[hi].MaxUpdownRateNum <= pivot.MaxUpdownRateNum && fabs(arr[hi].MaxUpdownRateNum - pivot.MaxUpdownRateNum) > CMP && lo < hi)// 从右向左找第一个大于pivot的数
				hi--;
			if (lo < hi)
				arr[lo++] = arr[hi];//由于已经将arr[0]中的数保存到pivot中，可以理解成在数组arr[0]上挖了个坑，可以将其它数据填充到这来。

			while (arr[lo].MaxUpdownRateNum >= pivot.MaxUpdownRateNum && fabs(arr[hi].MaxUpdownRateNum - pivot.MaxUpdownRateNum) > CMP && lo < hi)// 从左向右找第一个小于等于pivot的数
				lo++;
			if (lo < hi)
				arr[hi--] = arr[lo];
		}
		arr[lo] = pivot;
		QuickSort(arr, left, lo - 1); // 递归调用
		QuickSort(arr, lo + 1, right);
	}
}
bool Find(string* arr, string s, int num)//GetQSNumber适配 在数组中找某个元素是否已经出现过了 
{
	for (int i = 0; i < num; i++)
	{
		if (arr[i] == s)
			return true;
	}
	return false;
}
void GetQSNumber(string s, LinkList lk)//快排主函数，建立同一行业所有股票信息的数组并跳转到排序，最后输出 
{
	LinkList p = lk->next, q = p;
	int num = 0;//num从0开始的！
	//----------------------创建60支股票的标志数组----------------------//
	//读文件
	string sixty[60];
	ifstream ifs;							//创建流对象
	ifs.open("60支股票信息csv.csv", ios::in);	//打开文件
	if (!ifs.is_open())						//判断文件是否打开
	{
		cout << "csv文件打开失败\_(ツ)_/\n" << endl;
		return;
	}
	string line;//临时存储文件中的一行数据
	int flag = 0, i = 0;
	while (getline(ifs, line, '\n'))  //利用 getline（）读取文件中的每一行到line
	{
		if (flag == 61)
			break;//改错：bbzl
		stringstream ss(line);//line到ss
		string sub;
		//一次性读一行的写法:
		//while (getline(ss, sub, '\n'))  
		if (flag)
		{
			for (int j = 0; j < 10; j++)
				getline(ss, sub, ',');
			sixty[i++] = sub;
		}
		flag++;
	}
	ifs.close();
	/*-----------------------sixty数组建立完毕 -------------------------*/
reborn:
	while (p)
	{
		if (p->data.fir == s && Find(sixty, p->data.code, i))//改错：一级行业的英文是什么啊（战术后仰）
			num++;
		p = p->next;
	}
	if (num == 0)//输的行业不在我的预期内
	{
		cout << "你输入的一级行业不对应任何的股票哦！请重新输入吧！：";
		cin >> s;
		goto reborn;
	}
	//改错：构造一个大小合适的数组，用指针的方式可以模拟vector大小合适的方法
	//这里就不能用调试看大小的方法了，因为输入的行业不一样，num也不一样，没办法确定一个定值！
	Stock* arr = new Stock[num];
	num = 0;
	p = q;//改错：977行过了之后p都到底了还怎么遍历啊
	while (p)
	{
		if (p->data.fir == s && Find(sixty, p->data.code, i))
			arr[num++] = p->data;
		p = p->next;
	}
	//补全每只股票的涨跌额最大值以及其对应的信息
	for (int i = 0; i < num; i++)
	{
		string irate;
		for (int k = 0; k < arr[i].daily[0].UpdownRate.size(); k++)
		{
			if (arr[i].daily[0].UpdownRate[k] != '%')
				irate += arr[i].daily[0].UpdownRate[k];
		}
		float irated = stof(irate);
		arr[i].MaxUpdownRateNum = irated;
		arr[i].MaxUPDate = arr[i].daily[0].date;
		for (int j = 1; j < 161; j++)//对应那162条每日数据
		{
			if (arr[i].daily[j].UpdownRate.size() == 0)
				break;//??■ ■ ■ ■ ■,说的就是你，100条数据??????
			string jrate;
			for (int k = 0; k < arr[i].daily[j].UpdownRate.size(); k++)
			{
				if (arr[i].daily[j].UpdownRate[k] != '%')
					jrate += arr[i].daily[j].UpdownRate[k];
			}
			float jrated = stof(jrate);//改错：float可以存到double里，但不能反过来(细节)
			if (irated < jrated)
			{
				arr[i].MaxUpdownRate = arr[i].daily[j].UpdownRate;
				arr[i].MaxUPDate = arr[i].daily[j].date;
				arr[i].MaxUpdownRateNum = jrated;
			}
		}
	}
	//-----------------补全完毕-----------------------
	QuickSort(arr, 0, num - 1);
	//输出排序结果
	for (int i = 0; i < num; i++)
		cout << endl << "序号：" << i + 1 << endl << "股票代码:" << arr[i].code << endl << "股票名称：" << arr[i].name << endl << "涨跌幅：" << arr[i].MaxUpdownRate << endl << "日期：" << arr[i].MaxUPDate << endl;
	cout << "30s后返回主菜单!" << endl;
	Sleep(30000);
	CaptainOnBridge();
}
void QSortStartup(LinkList lk)//4.2
{
	cout << "请输入一级行业名称：";
	string s;
	cin >> s;
	GetQSNumber(s, lk);
}

//4.3选择排序 基于简单选择排序的股票价格分析
/*
无论什么数据进去都是 O(n2) 的时间复杂度。所以用到它的时候，数据规模越小越好。唯一的好处可能就是不占用额外的内存空间了吧。

首先在未排序序列中找到最小（大）元素，存放到排序序列的起始位置。
再从剩余未排序元素中继续寻找最小（大）元素，然后放到已排序序列的末尾。
重复第二步，直到所有元素均排序完毕。
*/
int Find(string s, Stock node)//返回日期对应的daily下标
{
	for (int i = 0; i < 163; i++)
	{
		if (s == node.daily[i].date)
			return i;
		else if (s > node.daily[i].date)//鲁棒性，日期找不到对应的具体天数，随便（划掉）返回一个虚值
			return i + 1;
	}
	return -1;
}
void ChooseSortSC(string date, Stock* arr)//按评分排序 
{
	for (int i = 0; i < 59; i++)//从第一个开始，所以要这是循环次数
	{
		int max = i;
		for (int j = i + 1; j < 60; j++)
			if (arr[j].score > arr[max].score)
				max = j;
		Stock temp = arr[max];
		arr[max] = arr[i];
		arr[i] = temp;
	}
}
void ChooseSortCP(string date, Stock* arr)//按收盘价排序 
{
	for (int i = 0; i < 59; i++)
	{
		int max = i;
		for (int j = i + 1; j < 60; j++)
		{
			int pos1 = Find(date, arr[i]);
			int pos2 = Find(date, arr[max]);
			if (arr[j].daily[pos1].cprice > arr[max].daily[pos2].cprice)//改错：是j不是i，吐血了
				max = j;
		}
		Stock temp = arr[max];
		arr[max] = arr[i];
		arr[i] = temp;
	}
}
int Find(string* arr, string s)//返回当前元素在数组中的第几位 
{
	for (int i = 0; i < 60; i++)
	{
		if (arr[i] == s)
			return i;
	}
}
void CSortStartup(LinkList lk)// 创建60支股票信息的数组，排序，输出 
{
	LinkList p = lk->next, q = p;
	int num = 0;//num从0开始的！
	//----------------------创建60支股票的标志数组----------------------//
	//读文件
	string sixty[60];//代码,数组里面的代码对应的股票是有评分的
	float scr[60] = { 0 };//评分
	ifstream ifs;							//创建流对象
	ifs.open("股票评分.csv", ios::in);	    //打开文件
	if (!ifs.is_open())						//判断文件是否打开
	{
		cout << "csv文件打开失败\_(ツ)_/\n" << endl;
		return;
	}
	string line;//临时存储文件中的一行数据
	int flag = 0, i = 0;
	while (getline(ifs, line, '\n'))  //利用 getline（）读取文件中的每一行到line
	{
		//if (flag == 61)
		//	break;//改错：bbzl
		stringstream ss(line);//line到ss
		string sub;
		//一次性读一行的写法:
		//while (getline(ss, sub, '\n'))  
		if (flag >= 2)
		{
			getline(ss, sub, ',');
			sixty[i] = sub;

			for (int j = 0; j < 2; j++)
				getline(ss, sub, ',');
			scr[i++] = stof(sub);
		}
		flag++;
	}

	ifs.close();//改错：好几个文件都没关。。记得关啊
	/*-----------------------sixty，scr数组建立完毕 -------------------------*/
	Stock* arr = new Stock[60];//评分是确定的，所以大小也是确定的
	num = 0;
	p = q;
	while (p)//补全每只股票的评分
	{
		if (Find(sixty, p->data.name, i))
		{
			arr[num] = p->data;
			arr[num].score = scr[Find(sixty, p->data.name)];
			num++;
		}
		p = p->next;
	}
label:
	cout << "请输入日期：";
	string s;
	cin >> s;
	//arr没错了
	/*——————————————————————————选择排序准备工作完毕————————————————————————————————————————*/
	ChooseSortSC(s, arr);//输出排序结果并保存
	ofstream ofile;
	ofile.open("评分排序.csv", ios::out | ios::trunc);
	cout << "按评分排序：" << endl;
	for (int i = 0; i < num; i++)
	{
		cout << endl << "序号：" << i + 1 << endl << "股票代码:" << arr[i].code << endl << "股票名称：" << arr[i].name << endl << "评分：" << arr[i].score << endl;
		ofile << "序号" << "," << "股票代码" << "," << "股票名称" << "," << "评分" << "," << endl;
		ofile << i + 1 << "," << arr[i].code << "," << arr[i].name << "," << arr[i].score << "," << endl;
	}
	ofile.close();

	Sleep(3000);

	ChooseSortCP(s, arr);//输出排序结果并保存
	ofile.open("收盘价排序.csv", ios::out | ios::trunc);
	cout << "按收盘价排序：" << endl;
	for (int i = 0; i < num; i++)
	{
		cout << endl << "序号：" << i + 1 << endl << "股票代码:" << arr[i].code << endl << "股票名称：" << arr[i].name << endl << "收盘价：" << arr[i].daily[Find(s, arr[i])].cprice << endl;
		ofile << "序号" << "," << "股票代码" << "," << "股票名称" << "," << "收盘价" << "," << endl;
		ofile << i + 1 << "," << arr[i].code << "," << arr[i].name << "," << arr[i].daily[Find(s, arr[i])].cprice << "," << endl;
	}
	ofile.close();
	cout << "你还要继续吗？(y表示是，否则按任意键回车返回上级菜单）：";
	char c;
	cin >> c;
	if (c == 'y')
		goto label;
	else
	{
		CaptainOnBridge();
		return;
	}
}

//4.4 公用
void VexList(string n, int vnum, LinkList& lk)//4.4用，将有序号的点的序号标上
{
	LinkList p = lk->next;
	while (p)
	{
		if (p->data.name == n)
		{
			p->data.vexnum = vnum;
			return;
		}
		p = p->next;
	}
}
void CreateGraph(AMGraph& amg, LinkList& lk)//图真正存数据是从1开始到60，创建邻接矩阵 
{
	//-------------初始化图-----------------------
	for (int i = 0; i <= 60; i++)
	{
		amg.matrix[i][0] = i;
		amg.matrix[0][i] = i;
	}
	for (int i = 1; i <= 60; i++)
		for (int j = 1; j <= 60; j++)
			amg.matrix[i][j] = MAXROUTE;//改错：路程长度不能初始化为0，不然弗洛伊德算法会认为0是最小的路程，就等于0了
	//------------初始化部分完毕-------------------

	//-------------读文件-------------------------
	ifstream ifs;							//创建流对象
	ifs.open("160支股票信息csv.csv", ios::in);	//打开文件
	if (!ifs.is_open())						//判断文件是否打开
	{
		cout << "csv文件打开失败\_(ツ)_/\n" << endl;
		return;
	}
	string line;//临时存储文件中的一行数据
	int flag = 0;
	while (getline(ifs, line))  //利用 getline（）读取文件中的每一行到line
	{
		//改错：我明白了！！！保存csv文件的时候如果选csv(UTF-8编码）就是乱码，但是下面的格式还有一个是普普通通简简单单的csv！用那个就行了！！
		stringstream ss(line);//line到ss
		string sub;
		//一次性读一行的写法:
		//while (getline(ss, sub, '\n'))  
		if (flag)
		{
			getline(ss, sub, ',');
			int p1 = stoi(sub);

			getline(ss, sub, ',');
			int p2 = stoi(sub);

			getline(ss, sub, ',');
			int weight = stoi(sub);

			amg.matrix[p1][p2] = weight;
			amg.matrix[p2][p1] = weight;//股票之间相关性肯定是无向的啊

			for (int i = 0; i < 3; i++)
				getline(ss, sub, ',');

			if (flag < 61)
			{
				getline(ss, sub, ',');
				int vexnum = stoi(sub);

				getline(ss, sub, ',');
				string name = sub;

				VexList(name, vexnum, lk);

				getline(ss, sub, ',');//股票代码闲置不用
			}
		}
		flag++;
	}
	ifs.close();
}
int Find(string s, LinkList lk)//4.4Floyd用，通过股票的中文名称找到它的序号
{
	LinkList p = lk->next;
	while (p)
	{
		if (p->data.name == s)
			return p->data.vexnum;
		p = p->next;
	}
}

//4.5,4.6都要用到的函数
//4.4 基于Floyd的股票相关性计算
/*
弗洛伊德算法中每一个顶点都是出发访问点，所以需要将每一个顶点看做被访问顶点，求出从每一个顶点到其他顶点的最短路径。
时间复杂度O(n^3)，空间复杂度O(n）
*/
string FindName(LinkList lk, int vnum)//4.5找到序号对应的名字
{
	LinkList p = lk->next;
	while (p)
	{
		if (p->data.vexnum == vnum)
			return p->data.name;
		p = p->next;
	}
}
int GetArrSize(int* arr)//获得数组长度
{
	int cnt = 0;
	for (int i = 0; i < 50; i++)
	{
		if (arr[i] > 0)
			cnt++;
		else
			return cnt;
	}
}
bool FindIntArr(int* arr, int x)//4.5用，找数组中是不是已经有一样的值了
{
	int arrsize = GetArrSize(arr);
	for (int i = 0; i < arrsize; i++)
	{
		if (arr[i] == x)
			return true;//找到了
	}
	return false;
}
void FloydRel(AMGraph amg, LinkList lk)//Floyd主要算法函数 
{
label:
	cout << endl << "请输入你要查找距离的两支股票中文名称(回车或空格隔开）：";
	string s1, s2;
	cin >> s1 >> s2;
	if (s1 == s2)
	{
		cout << "这俩是一个股票，距离肯定是0啊，重新输下吧" << endl;
		goto label;
	}
	int p1 = Find(s1, lk), p2 = Find(s2, lk);
	// 初始化
	for (int i = 0; i <= 60; i++)
	{
		dist[i][0] = i;
		dist[0][i] = i;
	}
	for (int i = 1; i <= 60; i++)
	{
		for (int j = 1; j <= 60; j++)
		{
			dist[i][j] = amg.matrix[i][j];    // "顶点i"到"顶点j"的路径长度为"i到j的权值"。
			dist[j][i] = amg.matrix[j][i];
		}
	}
	// 计算最短路径：我就统一都求出来了，不管问的是几全求出来，方便
	for (int k = 1; k <= 60; k++)//拿出每个顶点作为遍历条件
	{	//对于第k个顶点来说，遍历网中任意两个顶点，判断间接的距离是否更短
		for (int i = 1; i <= 60; i++)
		{
			for (int j = 1; j <= 60; j++)
			{//判断经过顶点k的距离是否更短，如果判断成立，则存储距离更短的路径
				if (dist[i][j] > dist[i][k] + dist[k][j])// 如果经过下标为k顶点路径比原两点间路径更短，则更新dist[i][j]
				{
					dist[i][j] = dist[i][k] + dist[k][j];// "i到j最短路径"对应的值设，为更小的一个(即经过k)
					dist[j][i] = dist[i][k] + dist[k][j];// 无向图
				}
			}
		}
	}
	printf("%s和%s之间的最短距离是：%d\n", s1.c_str(), s2.c_str(), dist[p1][p2]);
	cout << "你还要继续吗？(y表示是，否则按任意键回车返回上级菜单）：";
	char c;
	cin >> c;
	if (c == 'y')
		goto label;
	else
	{
		CaptainOnBridge();
		return;
	}
}
//4.6 基于二部图的股票基金筛选
  //队列相关
void Init(Queue& q)
{
	q.front = 0;
	q.rear = -1;
	q.counter = 0;
}
bool IsFull(Queue& q)
{
	return (q.counter >= 20);
}
void EnQueue(Queue& q, int val)
{
	if (IsFull(q))
		return;
	q.rear = (q.rear + 1) % 20;
	q.arr[q.rear] = val;
	q.counter++;
}
bool IsEmpty(Queue& q)
{
	return (q.counter <= 0);
}
int Front(Queue& q)
{
	if (!IsEmpty(q))
		return q.arr[q.front];
}
void DeQueue(Queue& q)
{
	if (IsEmpty(q))
		return;
	q.front = (q.front + 1) % 20;
	q.counter--;
}
//队列相关 完毕
int FindPos(LinkList lk, int vnum)//4.5找到序号对应的名字
{
	LinkList p = lk->next;
	while (p)
	{
		if (p->data.vexnum == vnum)
			return p->data.vexnum;
		p = p->next;
	}
}
void IsBinGraph(AMGraph amg, LinkList& lk)//4.6，染色法判断是不是二部图,BFS
{
	int num[10];
label:
	for (int i = 0; i < 10; i++)
		num[i] = 0;
	cout << "请输入十个数字（范围为[1,60]）：";
	for (int i = 0; i < 10; i++)
	{
		int temp;
		cin >> temp;
		while (temp > 60 || temp < 1)
		{
			cout << "数据不满足边界范围！请重新输入该数！:";
			cin >> temp;
		}
		while (FindIntArr(num, temp))
		{
			cout << "数据重复了！这肯定不会是二部图的，重新输入吧！:";
			cin >> temp;
		}
		num[i] = temp;
	}
	//环的判断
	queue<int> color;
	int du[61] = { 0 };//度数节点
	for (int i = 0; i < 10; i++)
	{
		for (int j = 0; j < 10; j++)
		{
			if (amg.matrix[num[i]][num[j]] != MAXROUTE)
				du[num[i]]++;
		}
		if (du[num[i]] <= 1)
			color.push(num[i]);
	}
	int cnt = 0;
	while (!color.empty())
	{
		cnt++;
		int x = color.front();
		color.pop();
		for (int j = 0; j < 10; j++)
		{
			du[num[j]]--;
			if (du[num[j]] == 1)
				color.push(num[j]);
		}
	}
	if (cnt != 10)
	{
		cout << "不是二部图" << endl;
		exit(0);
	}
	//amg是原图，就是保存了邻居的图
	//visit数组初始化
	char visit[61] = { '#' };//一开始大家都是清白的，没有被染过色（什）
	for (int i = 0; i < 61; i++)
		visit[i] = '#';
	//visit数组初始化完毕————————————————————
	//以下开始BFS染色的算法
	int pos = 0;//pos存储当前num的第几个数
	int nei[10] = { 0 };//邻居，最多九个
	int flag = 1;//flag用来控制染成什么颜色

	Queue q;
	Init(q);
	EnQueue(q, num[pos]);//1,2,3,4,6,7,8,9,10,11
	visit[num[0]] = 'B';//初始点标记为B
	while (!IsEmpty(q))
	{
		int size = q.counter;
		//int cnt = 0;
		while (size--)
		{
			int cnt = 0;//作用域一开始弄得太大了,cnt是nei的计数器
			for (int i = pos + 1; i < 10; i++)//从当前节点的序号开始，遍历num数组求邻居
			{
				if (amg.matrix[num[pos]][num[i]] != MAXROUTE)
				{
					nei[cnt] = num[i];//改错：是改这里
					cnt++;
				}
			}//nei里面保存的是邻居,cnt是数组长度

			DeQueue(q);
			for (int i = 0; i < cnt; i++)
			{
				if (visit[nei[i]] == '#')//未走过，可以走,同时你得是我邻居才行啊
				{
					if (visit[num[pos]] == 'B')
						visit[nei[i]] = 'R';//改错：nei[i]啊！！你num[i]个什么劲啊真有意思，nei[i]才是邻居啊！
					else
						visit[nei[i]] = 'B';
					EnQueue(q, nei[i]);
				}
				else//以前走过，那看看是不是允许呢？
				{
					if ((visit[num[pos]] == 'B' && visit[nei[i]] == 'R') || (visit[num[pos]] == 'R' && visit[nei[i]] == 'B'))
						continue;
					else
					{
						cout << endl << "它们不能构成二部图o(TヘTo)" << endl;
						Sleep(2000);
						return;
					}
				}

			}
			for (int i = 0; i < cnt; i++)//clr nei for next use
				nei[i] = 0;
			pos++;
		}
	}

	int b = 0, r = 0;
	for (int i = 0; i < 10; i++)
	{
		if (visit[num[i]] == 'B')//孤立顶点
			b++;
		else if (visit[num[i]] == 'R')
			r++;
	}
	if ((b == 10 || r == 10) || pos == 1)
	{
		cout << "不是二部图" << endl;
		return;
	}
	//如果你走到了这里，那恭喜你！这是一个二部图！
	cout << "恭喜你！这是一个二部图！" << endl;
	for (int i = 0; i < 10; i++)
	{
		if (visit[num[i]] == '#')//孤立顶点
			visit[num[i]] = 'R';
	}
	cout << "两组节点情况如下：" << endl << endl << "第一组：" << endl;
	for (int i = 0; i < 61; i++)
	{
		if (visit[i] == 'B')
			cout << "序号：" << FindPos(lk, i) << "  股票名称：" << FindName(lk, i) << endl;
	}
	cout << endl << "第二组：" << endl;
	for (int i = 0; i < 61; i++)
	{
		if (visit[i] == 'R')
			cout << "序号：" << FindPos(lk, i) << "  股票名称：" << FindName(lk, i) << endl;
	}
	return;
}

//5.1 基于Kruskal最小生成树的股票基金筛选
/*
Kruskal算法至多对n条边各扫描一次，每次选择最小代价的边仅需要O (logn)的时间。 因此，克鲁斯卡尔算法的时间复杂度为O (nlogn)。

克鲁斯卡尔算法查找最小生成树的方法是：将连通网中所有的边按照权值大小做升序排序，
从权值最小的边开始选择，只要此边不和已选择的边一起构成环路，就可以选择它组成最小生成树。
对于 N 个顶点的连通网，挑选出 N-1 条符合条件的边，这些边组成的生成树就是最小生成树。
*/
void KruOut(Edge* vex, LinkList lk)//Kruskal 输出 
{
	/*输出前两个权值是1的公司*/
	string name = FindName(lk, vex[0].from);
	cout << "	边的权值：1" << endl << "	边的节点1：" << name;
	name = FindName(lk, vex[0].to);
	cout << "		边的节点2：" << name << endl;//23,24
	//从1到13，共13-1+1=13个权值为2的企业

	name = FindName(lk, vex[1].from);
	cout << "	边的权值：2" << endl << "	边的节点1：" << name;
	name = FindName(lk, vex[1].to);
	cout << "		边的节点2：" << name << endl;

	name = FindName(lk, vex[2].from);
	cout << "	边的权值：2" << endl << "	边的节点1：" << name;
	name = FindName(lk, vex[2].to);
	cout << "		边的节点2：" << name << endl;

	cout << endl << "呜呜呜~Teriri的魔力用光了，要好好休息才行呢~（六秒后退出程序）" << endl;
	Sleep(6000);
	exit(0);
}
void CreateKruTree(AMGraph amg, LinkList lk)//建立Kruskal最小生成树 算法 
{
	//dist数组:连通
	//amg.matrix：邻接
	int ecnt = 0, vcnt = 0;//ecnt是ConEdge的长度，vcnt是连通顶点数组的长度
	int vex[60] = { 0 };//它的大小是相互之间连通的顶点有几个，内容是相互连通的顶点都是谁（丢失先后信息）
	Edge KruTree[57];//5.1,[pnum-1],顶点数-1
	for (int i = 1; i <= 60; i++)
	{
		for (int j = i + 1; j <= 60; j++)
		{
			if (dist[i][j] != MAXROUTE)//说明i与j之间有点连线,i 与 j是连通的
			{
				Edge temp;
				temp.from = i;
				temp.to = j;
				temp.weight = dist[i][j];

				ConEdge[ecnt++] = temp;

				if (!FindIntArr(vex, i))
					vex[vcnt++] = i;
				if (!FindIntArr(vex, j))
					vex[vcnt++] = j;
			}
		}
	}
	//ConEdge数组构建完毕

	/*——————————————————————以下开始创建kru树——————————————————————————————*/
	//vcnt=61,但[57][58]都是60，不知道怎么回事，打个补丁修一下
	int truevex[58];
	for (int i = 0; i < 58; i++)
		truevex[i] = vex[i];
	vcnt = 58;//vcnt=58
	for (int i = 0; i < ecnt - 1; i++) //ConEdge数组按权值升序排序
	{
		int min = i;
		for (int j = i + 1; j < ecnt; j++)
			if (ConEdge[j].weight < ConEdge[min].weight)
				min = j;
		Edge temp = ConEdge[i];
		ConEdge[i] = ConEdge[min];
		ConEdge[min] = temp;
	}
	//ConEdge排序完毕（选择排序）

	int pnum = vcnt;
	//pnum=58,顶点个数

	int assist[58];//每个顶点配备一个标记值，0-57
	for (int i = 0; i < pnum; i++)
		assist[i] = i;//初始状态下每个顶点的标记都不一样
	//遍历所有的边
	int kcnt = 0;//KruTree计数用
	for (int i = 0; i < ecnt; i++)
	{
		//找到当前边的两个顶点在 ConEdge 数组中的位置下标
		//特性：i一定是小于j的，因为你遍历的时候j是从i+1开始算的
		//所以就让i为起点，j为终点吧
		int from = ConEdge[i].from;
		int to = ConEdge[i].to;
		//这俩顶点一定不同
		if (assist[from] != assist[to])//	//如果顶点的标记不同，说明不在一个集合中，不会产生回路
		{
			KruTree[kcnt++] = ConEdge[i];//记录该边,作为最小生成树的组成部分,计数+1
			int ele = assist[to];
			for (int k = 0; k < pnum; k++)//将新加入生成树的顶点标记全部改为一样的
			{
				if (assist[k] == ele)
					assist[k] == assist[from];
			}
		}
		//如果选择的边的数量和顶点数相差1，证明最小生成树已经形成，退出循环
		if (kcnt == pnum - 1)
			break;
	}
	KruOut(KruTree, lk);
}
//4.5另一部分函数 基于Prim最小生成树的股票基金筛选
/*
时间复杂度O(60^60)，空间复杂度O(v)
*/
Stock FindStock(LinkList lk, int vnum)//4.5找到序号对应的数据便于排序
{
	LinkList p = lk->next;
	while (p)
	{
		if (p->data.vexnum == vnum)
			return p->data;
		p = p->next;
	}
}
void QSortFund(Stock* s, int l, int r)//4.5用，fund根据评分快排
{
	if (l < r)
	{
		int i = l, j = r;
		double x = s[l].daily[0].OkNum;
		while (i < j)
		{
			while (i < j && s[j].daily[0].OkNum >= x) // 从右向左找第一个小于x的数
				j--;
			if (i < j)
				s[i++] = s[j];

			while (i < j && s[i].daily[0].OkNum < x) // 从左向右找第一个大于等于x的数
				i++;
			if (i < j)
				s[j--] = s[i];
		}
		s[i].daily[0].OkNum = x;
		QSortFund(s, l, i - 1); // 递归调用 
		QSortFund(s, i + 1, r);//改错：名字不改跳到别的函数里去了
	}
}
void PrimOut(int* vex, LinkList lk)//prim 
{
	/*输出前两个权值是1的公司*/
	string name = FindName(lk, vex[0]);
	cout << "	边的权值：1" << endl << "	边的节点1：" << name;
	name = FindName(lk, vex[1]);
	cout << "		边的节点2：" << name << endl;

	Stock w2[24];
	int k = 0;
	for (int i = 2; i < 24; i++)//权值为2的企业们开始,排序
		w2[k++] = FindStock(lk, vex[i]);

	QSortFund(w2, 0, 23);

	name = FindName(lk, w2[2].vexnum);
	cout << "	边的权值：2" << endl << "	边的节点1：" << name;
	name = FindName(lk, w2[3].vexnum);
	cout << "		边的节点2：" << name << endl;

	name = FindName(lk, w2[4].vexnum);
	cout << "	边的权值：2" << endl << "	边的节点1：" << name;
	name = FindName(lk, w2[5].vexnum);
	cout << "		边的节点2：" << name << endl;

	cout << endl << "以上是Q宝为您选出的六支股票~6秒后返回主菜单咯~" << endl;
	Sleep(6000);
	//int vsize = 23;//0-23,共24个数，我数的，也可以用GetArrSize,一样
	CaptainOnBridge();
	return;
}
void CreatePrimTree(int(*dist)[61], int n, LinkList lk)//4.5，就是闭圈法,n传60，创建Prim树 
{
	bool visit[61];//bool型变量的visit数组表示：i是否已经包括在visit中
	int lowcost[61];//存储visit中到达对应的其它各点的最小权值分别是多少
	int closest[61];//closest数组保存的是：未在visit中的点所到达visit中包含的最近的点是哪一个,如:closest[i]=1表示i最靠近的visit中的点是1
	visit[1] = true;//从第一个结点开始寻找,扩展
	//初始化
	for (int i = 1; i <= n; i++)
	{
		lowcost[i] = dist[1][i];
		closest[i] = 0;//现在所有的点对应的已经在visit中的最近的点是1
		visit[i] = false;
	}
	//初始化完毕
	for (int i = 1; i < n; i++)//[1,60),59次
	{
		int min = MAXROUTE;//后面用来记录lowcost数组中的最小值
		int j = 1;
		for (int k = 2; k <= n; k++)//寻找lowcost中的最小值
		{
			if ((lowcost[k] < min) && (!visit[k]))//到达k点的权值小于MAXROUTE,即有k点
			{
				min = lowcost[k];
				j = k;
			}
		}
		visit[j] = true;//添加点j到集合visit中
		for (int k = 2; k <= n; k++)//因为新加入了j点,所以要查找 新加入的j点 到 未在visit中的k点中 的权值 是不是可以因此更小
		{
			if ((dist[j][k] < lowcost[k]) && (!visit[k]))
			{
				lowcost[k] = dist[j][k];
				closest[k] = j;
			}
		}
	}

	//注意：dist里存储了每两个节点中的最短距离，但是丢失了点的信息
	int vex[50];//存储目标节点
	int k = 0;

	for (int i = 1; i <= 60; i++)
	{
		for (int j = 1; j <= 60; j++)
		{
			int vsize = GetArrSize(vex);
			if (vsize >= 2)
				break;
			if (dist[i][j] == 1)//先存权值是1的两个节点
			{
				if (FindIntArr(vex, i) == 0)
					vex[k++] = i;
				if (FindIntArr(vex, j) == 0)
					vex[k++] = j;
			}
		}
	}
	//以上ok

	for (int i = 1; i <= 60; i++)
	{
		for (int j = 1; j <= 60; j++)
		{
			if (dist[i][j] == 2)//再存权值是2的两个节点
			{
				if (FindIntArr(vex, i) == 0)
					vex[k++] = i;
				if (FindIntArr(vex, j) == 0)
					vex[k++] = j;
			}
		}
	}
	//以上ok，可以访问vex[23]
	PrimOut(vex, lk);
}
void CreateDist(int choice, AMGraph amg, LinkList lk)//建立最短路径图 
{
	//int dist[61][61];
	//// 初始化 改错：这里忘记删除局部变量了……
	for (int i = 0; i <= 60; i++)
	{
		dist[i][0] = i;
		dist[0][i] = i;
	}
	for (int i = 1; i <= 60; i++)
	{
		for (int j = 1; j <= 60; j++)
		{
			dist[i][j] = amg.matrix[i][j];    // "顶点i"到"顶点j"的路径长度为"i到j的权值"。
			dist[j][i] = amg.matrix[j][i];
		}
	}
	// 计算最短路径：我就统一都求出来了，不管问的是几全求出来，方便
	for (int k = 1; k <= 60; k++)
	{
		for (int i = 1; i <= 60; i++)
		{
			for (int j = 1; j <= 60; j++)
			{
				if (dist[i][j] > dist[i][k] + dist[k][j])// 如果经过下标为k顶点路径比原两点间路径更短，则更新dist[i][j]和path[i][j]
				{
					dist[i][j] = dist[i][k] + dist[k][j];// "i到j最短路径"对应的值设，为更小的一个(即经过k)
					dist[j][i] = dist[i][k] + dist[k][j];//无向图
				}
			}
		}
	}
	if (choice == 9)
		CreatePrimTree(dist, 60, lk);
	else if (choice == 10)
	{
		IsBinGraph(amg, lk);
		CaptainOnBridge();
	}
	else //choice == 11,5.1
		CreateKruTree(amg, lk);
}

void Welcome(LinkList& lk, LinkList ht[], BTree& bt, AMGraph& amg)
{
	CaptainOnBridge();
	int x;
	while (cin >> x)
	{
		switch (x)
		{
		case 1:StockInfoHash(ht); break;
		case 2:StockWeb(ht); break;
		case 3:StockInfoTree(bt, lk); break;
		case 4:StockPrice(lk); break;
		case 5:InsertSort(lk); break;
		case 6:QSortStartup(lk); break;
		case 7:CSortStartup(lk); break;
		case 8:FloydRel(amg, lk); break;
		case 9:CreateDist(9, amg, lk); break;
		case 10:CreateDist(10, amg, lk); break;
		case 11:CreateDist(11, amg, lk); break;
		default:
		{
			cout << "你输入的数字好像不对应有效功能哦，要重新输入吗？（y确定，其余符号退出）：";
			char c;
			cin >> c;
			if (c == 'y')
				cin >> x;
			else
				return;
		}
		}
	}
}
int main()
{
	LinkList lk;
	LinkList ht[97];
	BTree bt = NULL;
	AMGraph amg;
	CreateTable(ht);//哈希表
	InitList(lk);//链表的创建·上
	CreateList(ht, lk);//链表的创建·下
	CreateGraph(amg, lk);//图的创建

	Welcome(lk, ht, bt, amg);
	return 0;
}

//May all the beauty be blessed.