package com.hfad.lecture06viewmodellivedatabinding;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelProviders;

import android.app.Application;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.hfad.lecture06viewmodellivedatabinding.databinding.ActivityMainBinding;

// ViewModel + LiveData + DataBinding

public class MainActivity extends AppCompatActivity {

    TextViewModel textViewModel;
    ActivityMainBinding textBinding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 创建一个 ActivityMainBinding 类型的 data binding 对象，并与布局资源关联
        textBinding = DataBindingUtil.setContentView(this, R.layout.activity_main);

        // 创建一个 TextViewModel 类型的对象: 方式 1
//        textViewModel = new ViewModelProvider(this,
//                new ViewModelProvider.NewInstanceFactory()).get(TextViewModel.class);

        // 创建一个 TextViewModel 类型的对象: 方式 2
        textViewModel = ViewModelProviders.of(this).get(TextViewModel.class);

        // 把 textViewModel 关联到 textBinding: ViewModel 到 data binding 的关联
        textBinding.setPowerfulTextViewModel(textViewModel);

        // 启动 data binding
        textBinding.setLifecycleOwner(this);

    }
}
