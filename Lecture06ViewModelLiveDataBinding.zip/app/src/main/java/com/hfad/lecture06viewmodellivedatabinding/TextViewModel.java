package com.hfad.lecture06viewmodellivedatabinding;

import android.app.Application;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

// 本业包含两种 TextViewModel 的实现：分别派生自不同的父类。

/*
public class TextViewModel extends ViewModel {

    private MutableLiveData<String> textLiveData;

//    final String str1 = "Sunny";
//    final String str2 = "Overcast";

    final String str1 = "OLD";
    final String str2 = "NEW";


    public TextViewModel() {
        this.textLiveData = new MutableLiveData<>();
        this.textLiveData.setValue(str1);
    }

    public MutableLiveData<String> getTextLiveData() {
        return textLiveData;
    }

    public void setTextLiveData(MutableLiveData<String> textLiveData) {
        this.textLiveData = textLiveData;
    }

    // 供外部调用的服务（与业务逻辑有关的）
    public void switchText() {
        if(this.textLiveData.getValue().equals(str1)) {
            this.textLiveData.setValue(str2);
        } else {
            this.textLiveData.setValue(str1);
        }
    }
}

 */

/**
 * TextViewModel 类是一个ViewModel，但其父类是 AndroidViewModel，
 * 相比较于 ViewModel 类，AndroidViewModel 类可以获得活动上下文，
 * 即，其提供一个接口 getApplication() 来返回活动的上下文，这样就可以在
 * TextViewModel 类内部获得系统服务，比如，下面类中使用了 Toast。
 *
 * 实际上 AndroidViewModel 也是 ViewModel的子类，如果需要在 TextViewModel
 * 中调用系统服务的话，把其父类指定为 ViewModel 更合适。
 *
 */
public class TextViewModel extends AndroidViewModel {

    private MutableLiveData<String> textLiveData;

//    final String str1 = "Sunny";
//    final String str2 = "Overcast";

    final String str1 = "OLD";
    final String str2 = "NEW";

    public TextViewModel(@NonNull Application application) {
        super(application);
        this.textLiveData = new MutableLiveData<>();
        this.textLiveData.setValue(str1);
    }

    public MutableLiveData<String> getTextLiveData() {
        return textLiveData;
    }

    public void setTextLiveData(MutableLiveData<String> textLiveData) {
        this.textLiveData = textLiveData;
    }

    /**
     * 功能：点击 switch 按键时，文本框内容不变，底部弹出提醒消息
     *
     * 提醒消息弹出，是通过调用了系统服务Toast来实现了， makeText()
     * 的第一个参数，就是通过 AndroidViewModel 提供的系统调用获取活动上下文（粗略的说，就是UI主线程）。
     */
    public void switchText() {
        Toast.makeText(getApplication(), "按键功能尚未实现", Toast.LENGTH_LONG).show();
    }
}
