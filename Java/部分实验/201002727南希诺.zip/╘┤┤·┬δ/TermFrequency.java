package TermFrequency;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


class Stock {
    private String code; //代码
    private String text; // 全文本
    public ArrayList<String> keywords; //关键字数组
    private int kwordsnum;
    private int kwordslen; // 关键字总长度
    private int textlen;
    private double rou;

    public Stock()
    {
        this.code = "";
        this.text = "";
        this.keywords = new ArrayList<>();
        this.kwordsnum = 0;
        this.kwordslen = 0;
        this.textlen = 0;
        this.rou = 0.0;
    }

    public int getKwordsnum() {
        return kwordsnum;
    }

    public void setKwordsnum() {
        this.kwordsnum = keywords.size();
    }


    public double getRou() {
        return rou;
    }

    public void setRou() {
        this.rou = (double) this.getKwordslen() / this.getTextlen();
    }

    public int getKwordslen() {
        return kwordslen;
    }

    public int getTextlen() {
        return textlen;
    }

    public void setTextlen(int cnt) {
        this.textlen = this.getText().length() - cnt;
    }

    public void setKwordslen(int kwordslen) {
        this.kwordslen += kwordslen;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public ArrayList<String> getKeywords() {
        return keywords;
    }
}

/**
 * 这个类里的数组存储 Keywords.txt的文字
 */
class RiskWords {
    private final String[] riskwords = new String[122];

    //添加官方给定风险关键词到数组里
    public void addWords() throws FileNotFoundException {
        String path = "D:\\Keywords.txt";
        Scanner in = new Scanner(new File(path));
        int i = 0;
        while (in.hasNext()) {
            riskwords[i++] = in.nextLine();
        }
        // System.out.println(rwords); 这个数组对了
    }

    public String[] getRiskwords() {
        return riskwords;
    }
}

/**
 * 打开并读取文件
 */
class LoadSourceText
{
    private final HashMap<String, Stock> smap;
    public ArrayList<Stock> res;
    public LoadSourceText()
    {
        this.smap = new HashMap<>();
        this.res = new ArrayList<>();
    }

    /**
     * 打开 + 读xls文件
     */
    public void load() {

        Workbook workbook = null;
        try {
            workbook = Workbook.getWorkbook(new File("D:\\SourceText.xls"));
        } catch (IOException | BiffException e) {
            e.printStackTrace();
        }
        assert workbook != null;
        Sheet sheet = workbook.getSheet(0);
        //调用add函数把内容读到数组里
        add(sheet);
    }

    /**
     * 处理字符串中的空格和换行符
     */
    public String replaceBlank(String str) {
        String s = "";
        if (str != null) {
            Pattern p = Pattern.compile("\\s*|\t|\r|\n|\s");
            Matcher m = p.matcher(str);
            s = m.replaceAll("");
        }

//       结果无差别
//       String s = "";
//       for (int i = 0; i < str.length(); i++) {
//            if(str.charAt(i) != '\n' || str.charAt(i) != ' '
//             || str.charAt(i) != '\r'){
//                s += str.charAt(i);
//            }
//        }
        return s;
    }

    /**
     * 把内容读到 HashMap 里 , 并排序
     */
    public void add(Sheet sheet) {
        int row = sheet.getRows();

        for (int i = 1; i < row; i++) {
            int j = 0;

            String txt = "";
            String key = sheet.getCell(j, i).getContents();
            j++;//year,跳过
            j++;//text-3
            txt += sheet.getCell(j, i).getContents();
            //txt = replaceBlank(txt);
            j++;//text-4
            txt += sheet.getCell(j, i).getContents();
            //txt = replaceBlank(txt);
            j++;//text-5
            txt += sheet.getCell(j, i).getContents();
            txt = replaceBlank(txt);
            // 以前加过
            if (!smap.isEmpty() && smap.containsKey(key)){
                // 取出来加上新的文本
                txt = smap.get(key).getText() + txt;
                txt = replaceBlank(txt);
                // 。。。
            }
            //新建一个temp配置好放到HashMap中去
            Stock temp = new Stock();
            temp.setText(txt);
            temp.setCode(key);
            //放到Map里
            smap.put(temp.getCode(), temp);
        }
        valueSort();
    }
    //value-sort,并开辟一个新数组放到里面
    public void valueSort()
    {
        List<HashMap.Entry<String, Stock>> list = new ArrayList<>(smap.entrySet());
        list.sort((o1, o2) -> o1.getValue().getCode().compareTo(o2.getValue().getCode()));
        //用迭代器对list中的键值对元素进行遍历
        for (HashMap.Entry<String, Stock> item : list) {
            Stock temp = item.getValue();
            res.add(temp);
        }
    }
    // int indexOf(String str):返回的是str在字符串中第一次出现的位置
    public int getCount(String substr, String str) {
        int count = 0;
        while ((str.indexOf(substr)) != -1) {
            // 截取未被查找到目标字符串的子串
            int index = str.indexOf(substr);
            str = str.substring(index + substr.length());
            count++;
        }
        return count;
    }
    //统计字符串中的空格etc数
    public int CountSpace(String s){
        int count = 0;
        for (int i = 0; i < s.length(); i++) {
            if(s.charAt(i) == ' ' || s.charAt(i) == '\n'
                    || s.charAt(i) == '\r' || s.charAt(i) == '\t'){
                count ++;
            }
        }
        return count;
    }
    /**
     * 去重
     */
    //关键字去重
    public void QuChong(String big, String small)
    {
        for (Stock re: res)
        {
            for (int j = 0; j < re.keywords.size(); j++)
            {
                if (small.equals(re.keywords.get(j))) {
                    re.keywords.remove(big);
                }
            }
        }
    }
    /**计算每只股票的关键字长度和关键词个数*/
    public void Kwordslen()
    {
        for (Stock re : res) {
            ArrayList<String> arr = re.getKeywords();
            for (String s : arr) {
                re.setKwordslen(s.length());
            }
            // 统计完之后计算关键词个数
            re.setKwordsnum();
        }
    }
    /**
     * 完善每个公司对应的风险词数组
     */
    public void GetRiskWords(RiskWords rsk)
    {
        //接受官方rsk数组
        String[] rskwords = rsk.getRiskwords();
        for (Stock re : res)
        {
            // txt获得每一个key(股票编号)对应的描述文本
            String txt = re.getText();
            //遍历rsk数组，看rsk数组中的每一项分别都出现了几（cnt）次
            for (String rskword : rskwords) {
                int cnt = getCount(rskword, txt);
                // 出现几次，就在原股票对应的自己的rsk数组中添加几次
                for (int k = 0; k < cnt; k++) {
                    re.keywords.add(rskword);
                }
            }
        }
        QuChong("风险","信用风险");
        QuChong("风险","风险管理");
        QuChong("风险","经营风险");
        QuChong("风险","流动性风险");
        QuChong("风险","市场风险");
        QuChong("不确定","不确定性");//
        for (Stock re : res)
        {
            String txt = re.getText();
            for (String rskword : rskwords)
            {
                int cnt = getCount("不确定性", txt);
                if(cnt!=0) {
                    re.keywords.remove("不确定");
                    break;
                }
            }
        }
        QuChong("过剩","产能过剩");
        QuChong("下行","经济下行");
        QuChong("放缓","增速放缓");
        QuChong("波动","汇率波动");
        QuChong("波动","价格波动");
        QuChong("激烈","日趋激烈");
    }

    /**
     * 完善每个公司对应的密度，两个长度
     */
    public void SetRouAndLen() {
        for (Stock re : res) {
            int cnt = CountSpace(re.getText());
            re.setTextlen(cnt);
            re.setRou();
        }
    }
    //返回正确格式的关键词列表
    public String getKwordsList(Stock s){
        ArrayList<String> words = s.getKeywords();
        if(words.isEmpty()){
            return "";
        }
        StringBuilder wordlist = new StringBuilder();
        for (String word : words) {
            wordlist.append(word);
            wordlist.append(",");
        }
        wordlist = new StringBuilder(wordlist.substring(0, wordlist.length() - 1));
        return wordlist.toString();
    }
    public void Write() {
        try {
            //1:创建excel文件
            File file = new File("D:/finalResult.xls");
            file.createNewFile();
            //2:创建工作簿
            WritableWorkbook workbook2 = Workbook.createWorkbook(file);
            //3:创建sheet,设置第二三四..个sheet，依次类推即可
            WritableSheet sheet1 = workbook2.createSheet("ToSheet", 0);
            //4：设置titles
            String[] titles = {"股票代号", "文本长度", "关键词个数",
                    "关键词长度", "关键词密度", "关键词列表"};
            //5:单元格
            Label label;
            //6:给第一行设置列名
            for (int i = 0; i < titles.length; i++)
            {
                //x,y,第一行的列名
                label = new Label(i, 0, titles[i]);
                //7：添加单元格
                sheet1.addCell(label);
            }
            //8：模拟数据库导入数据
            int j = 1;
            for (Stock re : res) {

                int i = 0;
                //添加股票代号，第二行第一列
                label = new Label(i++, j, re.getCode());
                sheet1.addCell(label);
                //添加文本长度
                label = new Label(i++, j, String.valueOf(re.getTextlen()));
                sheet1.addCell(label);
                //添加关键词个数
                label = new Label(i++, j, String.valueOf(re.getKwordsnum()));
                sheet1.addCell(label);
                //添加关键词长度
                label = new Label(i++, j, String.valueOf(re.getKwordslen()));
                sheet1.addCell(label);
                //添加关键词密度
                label = new Label(i++, j, String.valueOf(re.getRou()));
                sheet1.addCell(label);
                //添加关键词列表
                label = new Label(i++, j, getKwordsList(re));
                sheet1.addCell(label);
                j++;
            }
            //写入数据
            workbook2.write();
            //关闭工作簿
            workbook2.close();
        } catch (IOException | WriteException e) {
            e.printStackTrace();
        }
    }
}

/**
 * @author 计算机203-201002727-南希诺
 */
public class TermFrequency {
    public static void main(String[] args) throws FileNotFoundException {
        //先做好官方数组
        RiskWords rsk = new RiskWords();
        rsk.addWords();
        //然后excel里的数据加载到程序中并做处理
        LoadSourceText loadSourceText = new LoadSourceText();
        //加载大段文本和股票代码
        loadSourceText.load();
        //加载关键字数组
        loadSourceText.GetRiskWords(rsk);
        //去重并计算关键字数组长度
        loadSourceText.Kwordslen();
        //计算密度和大段文本长度
        loadSourceText.SetRouAndLen();
        //写到文档里
        loadSourceText.Write();
        System.out.println("工作完成！");
    }
}
