package com.hfad.messager;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

/**
 * 第二个活动类：用来接收、显示第一个活动发送来的消息
 *
 * 实现上述功能，整个工作基本流程就是 3 步走（详见下面代码中的注释）
 *
 * 当前类对应的 View (布局) 是 activity_receive_message.xml
 *
 */
public class ReceiveMessageActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receive_message);

        /**
         * 文本框：显示从第一个活动中发来的消息（消息内容是字符串）
         *
         * 这里的文本框资源在 activity_receive_message.xml 中定义，虽然也是用 R.id. 来索引，
         * 但不会与在 activity_create_message.xml 中定义的文本框混淆，因此不用担心。
         */
        TextView textView = findViewById(R.id.output);

        /**
         * step 1. 接收到一个 intent 对象（还是寄付的）
         *
         * 快递小哥：Dang Dang Dang, Knock, Knock, xxx在么？你快递到了！
         */
        Intent intent = getIntent();

        /**
         * step 2. 尚未洗漱、上网课中的你：毫不犹豫取快递、开开心心拆快递！
         *
         * 注意：调用 getStringExtra(..) 拆快递的时候，要指定事先约定好的消息类型。
         */
        String recvMessage = intent.getStringExtra(CreateMessageActivity.MESSAGE_TYPE);

        /**
         * step 3. 在朋友圈秀一下收到的礼物！
         *
         * 把从上一个活动中发来的消息显示在当前(第二个)活动的文本框中。
         */
        textView.setText(recvMessage);
    }
}
