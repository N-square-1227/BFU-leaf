package com.hfad.messager;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.content.Intent;
import android.widget.Button;
import android.widget.EditText;


/**
 * 第一个活动类：用来发送一个消息给第二个活动或者给OS
 *
 * 按照 AndroidManifest.xml 文件中指定，程序启动后进入当前活动。
 *
 * 当前类对应的 View (布局) 是 activity_create_message.xml
 *
 */
public class CreateMessageActivity extends AppCompatActivity {

    /**
     * 必须要实现指定消息类型，内核按照该指定的类型，实现"包裹"的正确投递
     *
     * 你会发现：(1) 在当前的"发送类/活动"与"接收类/活动"中，在消息收发操作上，都提及了该消息。
     *          (2) 该消息类型被定义/限定为 final
     */
    public static final String MESSAGE_TYPE = "just a kind of message";

    EditText editText;  // 对应文本输入框
    Button resetBtn;    // 对应"重新输入"按键

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_message);

        /**
         * 关联控件资源（到本地的两个引用）
         */
        editText = findViewById(R.id.input);
        resetBtn = findViewById(R.id.reset);

        /**
         * 该按键的功能用来清空输入文本框中的内容
         *
         * 这里的实现方式是直接用一个Listener （定义为"匿名内部类"）
         * 当然，你也可以在当前类内独立写一段响应该按键
         * 的函数，并把这个函数名字指定到 activity_create_message.xml 中本按键对应
         * 的 onClick 属性上。
         *
         * 注意：如果使用Listener，一定要实现它（重载它的 onClick() 方法），以保证传到
         *      setOnClickListener() 方法中的是一个具体的对象，而不是仅仅一个类型/形参。
         */
        resetBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editText.setText("");
            }
        });

    }

    /**
     * 消息发送按键响应
     *
     * 功能：把文本框中的字符串发送到第二个活动中，同时启动第二个活动界面，同时展示该字符串
     *
     * 这里包含了两个场景：
     *      场景2：把消息发送给第二个活动（场景2），
     *      场景1：把消息发送给OS，由OS来决定如何处理该消息。
     *
     * 使用 Intent 机制发送消息的基本流程如下：
     *      (1) 确定待发送消息的内容(本例中是字符串)
     *      (2) 创建一个 Intent 实例/对象，两个参数分别指定通信双方
     *      (3) 装载待发送消息到 intent 对象中，此时的 intent 就是快递小哥
     *
     * @param view
     */
    public void onSendMessage(View view) {

        /**
         * 从输入框中获取其内容(并转换为字符串类型)
         */
        String sendMessage = editText.getText().toString();

        /**
         * 场景1：启动内部的活动（自己定义的，就像示例中用来接收消息的第二个活动）
         *
         * 创建一个 intent 并且把它以message的形式发送给第二个活动(i.e., ReceiveMessageActivity)
         *
         * 注意：
         *      (1) 这里通信双方是当前类/活动、接收类/活动，以参数的形式指定到 Intent 实例化过程中
         *      (2) 装载待发送数据到 intent 中，要指定消息类型（本例中是 MESSAGE_TYPE）
          */
         Intent intent = new Intent(this, ReceiveMessageActivity.class);
         intent.putExtra( MESSAGE_TYPE , sendMessage); // 装载待发送消息到 intent 对象中

//        /**
//         * 场景2：启动外部的活动（可能是OS提供的其它服务、apps等）

//         * 创建一个 intent 并且在系统搜索可以支持该功能的所有 apps
//         *
//         * 注意：
//         *      (1) 这里通信双方是当前类/活动、OS，对于发送类需求，指定参数 ACTION_SEND 即可
//         *      (2) 装载待发送数据到 intent 中，依然需要指定消息类型
//         */
//        Intent intent = new Intent(Intent.ACTION_SEND);
//        intent.setType("text/plain");
//        intent.putExtra(Intent.EXTRA_TEXT, message); // 装载待发送消息到 intent 对象中

        /**
         *  启动发送 intent， 上述两个场景无论使用了哪一个，下面的语句都需要
          */
        startActivity(intent);
    }

}
