package com.hfad.stopwatchv1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView timeView;
    Button startButton, stopButton, resetButton;

    // 时钟
    Timer timer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 组合(包含)一个时钟对象, 封装了业务(时钟状态 + 操作逻辑)
        timer = new Timer();

        // 关联 View 上的控件资源
        timeView = findViewById(R.id.time_view);
        startButton = findViewById(R.id.start_btn);
        stopButton = findViewById(R.id.stop_btn);
        resetButton = findViewById(R.id.reset_btn);

        /**
         * 下面三个方法，是三个按键的响应代码
         *
         * 实现方式：创建 3 个 listeners 分别来监听按键操作。
         *
         * 设计原则（以 start button 响应为例）：
         *      启动时钟的事情，不在当前的 MainActivity 类中实现，因为当前类是一个 Controller，
         *      最好不要包含业务细节，业务细节应该是 "Model" 类的事情。
         *
         *      因此，在 startButton 的 listener 的 onClick() 重载中，调用了 timer 对象的
         *      接口 start()，即，MainActivity 把开启时钟的事情 "转交" 给 timer 了。
         *
         *      所以，这里的设计原则也是充分的遵循 decoupling 的原则。
         *
         */

        // start 按键响应实现
        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                timer.start();
            }
        });

        // stop 按键响应实现
        stopButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                timer.stop();
            }
        });

        // reset 按键响应实现
        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                timer.reset();
                timeView.setText(timer.getReading());
            }
        });

        // 调用类自身的 runTimer方法，实现启动额外的线程，独立完成时钟读数按秒增加
        runTimer();
    }

    /**
     * 以线程的形式实现时钟的计时
     *
     * 实现方式：Android Handler 机制
     *
     * 设计原则：仔细观察，runTimer() 方法的实现中，依然没有涉及时钟具体的状态和业务逻辑，
     *          只不过是调用了几个由 timer 提供的接口(服务/操作)
     *
     *          再次体现了 decoupling
     *
     * post(), postDelayed() 是 Handler 类最重要的两个接口
     *
     */
    public void runTimer() {
        final Handler handler = new Handler();
        handler.post(new Runnable() {
            @Override
            public void run() {
                if(timer.getStatus()) {
                    timer.goOneSecond();
                    timeView.setText(timer.getReading());
                }
                handler.postDelayed(this, 1000);
            }
        });

    }
}
