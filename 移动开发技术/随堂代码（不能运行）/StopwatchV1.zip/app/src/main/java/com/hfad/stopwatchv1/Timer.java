package com.hfad.stopwatchv1;

/**
 * Timer 类：在本示例中作为 MVC 中的 Model
 *
 * 设计原则：尽可能把业务有关的状态和业务逻辑从用户代码（本示例中就是 Controller）中
 *          分离出来，然后封装到一个类中。
 *
 * 该类维护两个状态：
 *  (1) running [boolean]: 运行与否
 *  (2) totalInSecond [int]: 启动后截止目前累计的总秒数
 *
 * 该类封装了几个与时钟操作有关的接口，可被外部调用
 *
 */
public class Timer {

    public Timer() {
        this.totalInSecond = 0;
        this.running = false;
    }

    public int getHours() { return totalInSecond / 3600; }
    public int getMinutes() { return (totalInSecond % 3600) / 60; }
    public int getSeconds() { return totalInSecond % 60; }

    /**
     * 返回时钟当前的读数
     *
     * @return 
     */
    public String getReading() {
        return String.format("%02d:%02d:%02d", getHours(), getMinutes(), getSeconds() );
    }

    public boolean getStatus() { return this.running; }

    public void goOneSecond() { if(running) {totalInSecond++;} }

    /**
     * 该 Timer 类支持三个典型操作：启动、停止、重置(清零)；这里以3个接口的形式给出
     */
    public void start() { this.running = true; }
    public void stop() { this.running = false; }
    public void reset() { this.running = false; this.totalInSecond = 0; }


    ////////////////////////////////////////////////////////////////////////

    private int totalInSecond;
    private boolean running;
}
