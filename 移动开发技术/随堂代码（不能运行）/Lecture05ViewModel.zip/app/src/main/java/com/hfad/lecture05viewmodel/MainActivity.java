package com.hfad.lecture05viewmodel;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProviders;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

/**
 * 当前活动要通过按键点击，把文本框中内容从"old"改为"new"。
 *
 * 为了避免屏幕旋转带来的 UI 界面文本框数据丢失（或回归程序运行初的状态），这里
 * 使用了 ViewModel 类，该类"持有" UI界面文本框所需的内容（这里是一个字符串）。
 *
 */
public class MainActivity extends AppCompatActivity {

    TextView textView;
    Button changeButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        Log.v("lifecycle", "onCreate() is called.");

        textView = findViewById(R.id.text_view);
        changeButton = findViewById(R.id.change_btn);

        /**
         * ViewModel 对象的创建：使用 ViewModelProviders.of().get() 接口
         */
        final TextViewModel textViewModel = ViewModelProviders.of(this).get(TextViewModel.class);

//        textView.setText("Old");
        textView.setText( textViewModel.getText() );

        /**
         * 按键响应方法：点击按键 -> 修改 textView控件中的文本
         *
         * 注意：要把最新的值更新到 textViewModel 对象中
          */
        changeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                textViewModel.setText("New");
                textView.setText(textViewModel.getText());

            }
        });

    }

    /**
     * 旋转屏幕时，OS会自动调用 onStop() 方法
     */
    @Override
    protected void onStop() {
        super.onStop();
//        Log.v("lifecycle", "onStop() is called.");
    }
}
