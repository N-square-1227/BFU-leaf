package com.hfad.lecture05viewmodel;

import androidx.lifecycle.ViewModel;

/**
 * TextViewModel 是 ViewModel 的一个子类。
 */
public class TextViewModel extends ViewModel {

    private String text = "Old";

    public TextViewModel() { }

    public void setText(String text) {
        this.text = text;
    }

    public String getText() {
        return this.text;
    }
}
