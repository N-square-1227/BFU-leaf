package com.hfad.beeradviser;

import java.util.ArrayList;
import java.util.List;

/**
 * How you doing? 我是啤酒品鉴专家！整一杯吧？
 *
 * --- 微醺....
 *
 * 当前类定义了业务，因此是 MVC 中的 "Model"
 *
 * 当然，可以在当前类中定义更丰富的业务有关的接口来给外部（主要指Controller）调用
 *
 */
public class BeerExpert {

    public BeerExpert() {}

    /**
     * 这个方法是一个业务逻辑接口，可由外部调用
     *
     * 注：由于写代码的人很懒，并未针对每类beer 实现一个口味评价，仅用一个if-else 结构企图蒙混过关
     *
     * @param color
     * @return
     */
    List<String> taste(String color) {
        List<String> info = new ArrayList<String>();
        if(color.equals("light")) {
            info.add("Jack Amber");
            info.add("I love beer so much 啊!");
        } else {
            info.add("Too strong!");
            info.add("我超不喜欢这个啤酒");
        }
        return info;
    }

}
