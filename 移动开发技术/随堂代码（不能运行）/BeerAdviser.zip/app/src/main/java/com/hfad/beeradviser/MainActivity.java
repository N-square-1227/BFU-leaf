package com.hfad.beeradviser;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.List;


/**
 * Hi all, 我是一个 Controller, 就是 "everything is under control" 的那个 Controller.
 *
 * ------ 表情逐渐认真.....
 *
 * 当前类定义了一个界面与业务之间的"接口"，是 MVC 中的 "Controller"
 *
 * 严格来讲，与业务有关的（复杂）实现代码，不出现在当前类中，当前类中只是完成对业务的调用、对控件的"认领"。
 *
 */
public class MainActivity extends AppCompatActivity {

    /**
     *  Step 0: 邀请 View 对象(引用)、Model对象"纷纷出场"
      */
    // Model 出场：在当前类中，包含(组合)一个指向"啤酒专家"对象的引用，该专家作为Model的实例以备被传唤（调用）。
    private BeerExpert expert = new BeerExpert();

    // View (控件)出场：在当前类中，包含指向控件的引用（注意：此时下述引用尚未初始化）
    //
    // 注意：(1) 下面的三个引用，将要指向控件对象，而不是它们各空间自身的内容！
    //      (2) 下面声明了三个引用，并未给它们初始化（用的时候再输初始化）
    //
    TextView beerInformation; // 文本框：显示由专家返回的啤酒信息
    Spinner colorSpinner; // 下拉框：显示啤酒的颜色
    Button findBeerBtn; // 按键：点击启动（调用）专家提供的服务

    ////////////////////////////////////////////////////////////////////////////////////
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /**
         * Step 1: 找（关联）到三个控件对象，并分配给对应的引用
         */
        //
        beerInformation = findViewById(R.id.beer_info);
        colorSpinner = (Spinner) findViewById(R.id.color_spinner);
        findBeerBtn = findViewById(R.id.find_beer);

        /**
         * Step 2: 实现（定义）按键响应
         *
         * 方式1：设置一个 Listener，一旦按键点击被听到，就通知专家出来干活儿。
         *
         * 注意：（1）如果使用方式1，在 activity_main.xml 中就不需要为 Button 指定 onClick 属性。
         *      （2）如果使用方式1，就不要同时使用方式2来响应按键
         */
//        findBeerBtn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                // Step 2-1: 获取点击选项，转换为字符串数据，将作为啤酒专家服务接口的参数
//                String beerType = colorSpinner.getSelectedItem().toString();
//
//                // Step 2-2: 调用专家对象（作为一个Model）的接口，显示专家返回的结果
//                List<String> infoList = expert.taste(beerType); // 专家开始干活啦！
//                StringBuilder infoFormatted = new StringBuilder();
//                for( String brand : infoList ) {
//                    infoFormatted.append(brand).append('\n');
//                }
//
//                beerInformation.setText(infoFormatted); // 显示专家返回的结果
//            }
//        });
    }

    ////////////////////////////////////////////////////////////////////////////////////
    /**
     * Step 2: 实现（定义）按键响应
     *
     * 方式：自定义一个函数，来实现按键的响应
     *
     * 注意：如果使用方式2，要在 xml 文件中的 Button 声明块中添加语句：android:onClick="当前函数的名字"；
     *      仔细体会，这与方式1不同。
     *
     * @param view：如果删掉参数，运行后怎样？试一下！
     */
    public void onClickFindBeer(View view) {
        /**
         * Step 2-1: 获取点击选项，转换为字符串数据，将作为啤酒专家服务接口的参数
         */
        String beerType = colorSpinner.getSelectedItem().toString();


        /**
         * Step 2-2: 调用专家对象（作为一个Model）的接口，显示专家返回的结果
         *
         * 注意：下面代码并未实现业务逻辑，—而是由调用的专家接口——taste() ——来输出与
         * 指定的 beerType 对应的啤酒信息
         */
        List<String> infoList = expert.taste(beerType); // 专家开始干活啦！
        StringBuilder infoFormatted = new StringBuilder();
        for( String brand : infoList ) {
            infoFormatted.append(brand).append('\n');
        }

        beerInformation.setText(infoFormatted); // 显示专家返回的结果

    }

}