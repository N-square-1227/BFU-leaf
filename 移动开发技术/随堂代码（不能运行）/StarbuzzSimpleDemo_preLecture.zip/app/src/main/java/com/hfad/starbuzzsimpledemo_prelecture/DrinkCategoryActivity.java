package com.hfad.starbuzzsimpledemo_prelecture;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * DrinkCategoryActivity: 是 ListActivity 的一个派生类
 *
 * 该类本身支持 ListView 操作，i.e., 本身包含了一个监听 ListView 控件点击的方法：onListItemClick() 方法。
 *
 */
public class DrinkCategoryActivity extends ListActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

//        Intent intent = getIntent();

        ListView drinkListView = getListView();

        ArrayAdapter<Drink> drinkAdapter = new ArrayAdapter<Drink>(
                this,
                android.R.layout.simple_list_item_1,
                Drink.drinks
        );

        drinkListView.setAdapter(drinkAdapter);
    }

    /**
     * 当前类自身的方法，用来响应点击。
     *
     * 参数 position 表示点击的 item 的位置/序号
     *
     * 使用 Intent 机制启动并转换到下一个界面（即 DrinkActivity 活动），同时在 intent 中嵌入
     * 被点击 item 的位置。
     *
      */
    @Override
    protected void onListItemClick(ListView l, View v, int position, long id) {
        super.onListItemClick(l, v, position, id);
        Intent intent = new Intent(this, DrinkActivity.class);
        intent.putExtra("DRINK_TYPE", position);
        startActivity(intent);
    }
}
