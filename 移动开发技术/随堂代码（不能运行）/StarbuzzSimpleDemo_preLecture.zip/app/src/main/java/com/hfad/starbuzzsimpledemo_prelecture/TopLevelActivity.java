package com.hfad.starbuzzsimpledemo_prelecture;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * TopLevelActivity：顶层活动，应用启动后进入该活动
 *
 * 关于 ListView 控件的使用分为 3 步：绑定资源、定义监听器、绑定监听器
 *
 */
public class TopLevelActivity extends AppCompatActivity {

    ImageView logoView;
    ListView menuListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ////////////////////////    step 1: 绑定两个控件资源   ////////////////////////
        logoView = findViewById(R.id.logo_view);
        menuListView = findViewById(R.id.list_options);

        //Target: 点击 Drinks 然后，当前界面(top)跳转到第二个活动(middle)

        /////////////  step 2: 定义一个监听器（使得可以对 ListView 控件点击做出正确反映） /////////////

        /**
         * 定义一个 listener，使其可以监听一个 ListView 控件上各个 item 的点击情况。
         *
         * 注意：(1) 该 listener 的类型为 AdapterView.OnItemClickListener
         *      (2) 重载方法 onItemClick(...)，其中的 i 表示 ListView 上 item 的编号(从 0 开始)
         *
         * 当前示例只实现了支持对 Drinks 这个 item 的点击（即，i==0 的情况）
         *
         */
        AdapterView.OnItemClickListener menuListViewListener = new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if(i==0) {
                    /**
                     * 使用 Intent 机制来启动下一个UI界面（中间层活动）。
                     *
                     * 这里，只需转换到下个界面，不需要向其传递数据。
                     */
                    Intent intent = new Intent( TopLevelActivity.this, DrinkCategoryActivity.class);
                    startActivity(intent);
                } else {
                    // 点击 Food, Others 这两个 items 时，不转换界面（因为尚未实现），但给出一个 Toast 通知。
                    Toast.makeText(TopLevelActivity.this, "coming soon", Toast.LENGTH_LONG).show();

                }
            }
        };

        /////////////////    step 3: 把个监听器绑定到当前的 ListView 控件上  ////////////////
        menuListView.setOnItemClickListener( menuListViewListener );
    }


}
