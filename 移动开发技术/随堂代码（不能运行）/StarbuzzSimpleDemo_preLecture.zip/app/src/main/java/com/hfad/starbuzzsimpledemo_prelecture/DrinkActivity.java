package com.hfad.starbuzzsimpledemo_prelecture;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * 该类是具体的饮品展示类。
 *
 * 根据上个活动传递过来的点击位置，找到对应的饮品，然后显示该饮品的具体信息到界面上。
 *
 */
public class DrinkActivity extends AppCompatActivity {

    ImageView drinkPhoto;
    TextView drinkDescription;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drink);

        drinkPhoto = findViewById(R.id.drink_photo);
        drinkDescription = findViewById(R.id.drink_description);

        // 从上个活动中传递过来的 intent 中提取点击信息（the position of the item clicked）
        int drinkNo = (int) getIntent().getExtras().get("DRINK_TYPE");

        // 下面两句：更新界面上的 ImageView 控件上的图片以及文字描述信息
        drinkPhoto.setImageResource(Drink.drinks[drinkNo].getImageResourceId());
        drinkDescription.setText(Drink.drinks[drinkNo].getName() + '\n' +
                Drink.drinks[drinkNo].getDescription());

    }
}
