package com.example.myapplication;


import androidx.annotation.NonNull;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Stack;

public class Calculator
{
    /**
     * 按类型细分好存储完成的数组
     */
    private static final List<Object> arithmetic_compartmentalized = new ArrayList<>();
    /**
     * 运算符数组
     */
    private static final char[] operator = {'+', '-', '×', '÷'};
    /**
     * 指定运算符及其优先级的 Map，# 是起始/结束符
     */
    private static final HashMap<Character, Integer> operator_values = new HashMap<>();
    static {
        operator_values.put('+', 1000001);
        operator_values.put('-', 1000001);
        operator_values.put('×', 1000002);
        operator_values.put('÷', 1000002);
        operator_values.put('#', 1000000);
    }
    /**
     * 处理并计算字符串的运算结果
     * @param arithmetic 输入字符串
     * @return 结果
     */
    public static Double calculate(@NonNull String arithmetic)
    {
        // 正则表达式匹配的过程，不重要
        String arithmetic_temp = arithmetic.replaceAll(" ", "")
                .replaceAll("\\+", "p+p")
                .replaceAll("-", "p-p")
                .replaceAll("×", "p×p")
                .replaceAll("÷", "p÷p")
                .replaceAll("p+", "p");
        String regex_all_lowercase = "[a-z]";
        // 将将原字符串的每一位装到字符串数组里
        String[] strings = arithmetic_temp.split(regex_all_lowercase);

        // 添加起始符
        arithmetic_compartmentalized.add('#');

        // 将原字符串的每一位装到数组里（这时将数字和运算符的数据类型分开了）
        for (String string : strings)
        {
            String regex_none_number = "\\D";
            if (!string.matches(regex_none_number))
            {
                arithmetic_compartmentalized.add(Double.parseDouble(string));
                continue;
            }
            for (Character character : operator)
            {
                if (string.equals(String.valueOf(character)))
                {
                    arithmetic_compartmentalized.add(character);
                    break;
                }
            }
        }

        arithmetic_compartmentalized.add('#');
        // String s = "1+2+3×4-4÷2";
        // arithmetic_compartmentalized = [#, 1.0, +, 2.0, +, 3.0, *, 4.0, -, 4.0, /, 2.0, #]

        // 将运算数和运算符装到各自的栈内
        /*
          OPND : 数
          OPRT : 符
         */
        Stack<Double> OPND = new Stack<>();
        Stack<Character> OPRT = new Stack<>();
        for (Object object : arithmetic_compartmentalized)
        {
            // 是数字，就把数字转换为 Double 并 push 到数字栈里
            if (object instanceof Double) {
                OPND.push((Double) object);
            }
            // 是字符
            else
            {
                Character character = (Character) object;
                // 字符栈为空，直接添加字符
                if (OPRT.isEmpty())
                {
                    OPRT.push(character);
                    continue;
                }
                // 字符栈不为空
                // 如果新来的运算符等级比栈里的低，并且不是结束符，就要先对栈里的数字进行一次运算
                if (operator_values.get(character) < operator_values.get(OPRT.peek()) && operator_values.get(character) != 1000000)
                {
                    // 取出数字栈最上面两个数字和字符栈上面的字符进行运算
                    Double b = OPND.pop();
                    Character oprt = OPRT.pop();
                    Double a = OPND.pop();
                    // 并把计算结果放到数字栈里
                    OPND.push(operate(a, oprt, b));
                }
                // 把新字符加到栈里面
                OPRT.push(character);
            }
        }

        // 将字符栈最顶端的 # pop 出去
        OPRT.pop();
        // 计算
        while (!OPRT.peek().equals('#'))
        {
            Double b = OPND.pop();
            Character oprt = OPRT.pop();
            Double a = OPND.pop();
            // 并把计算结果放到数字栈里
            OPND.push(operate(a, oprt, b));
        }
        // 返回结果
        return OPND.pop();
    }
    public static double operate(Double a, @NonNull Character oprt, Double b)
    {
        if (oprt.equals('+')) return a + b;
        if (oprt.equals('-')) return a - b;
        if (oprt.equals('×')) return a * b;
        if (oprt.equals('÷')) return a / b;
        return -1;
    }
    /**
     * 验证输入的计算式是否合法
     * @param input 输入的计算字符串
     * @return 合法 true，否则 false
     */
    public static boolean isValid(String input)
    {
        // 输入为空
        if (input == null){
            return false;
        }
        // 输入首位是符号
        if (!Character.isDigit(input.charAt(0))){
            return false;
        }

        char c = input.charAt(0);
        for (int i = 1; i < input.length(); i++)
        {
            char now = input.charAt(i);
            // 如果有两个连着的运算符
            if (!Character.isDigit(c) && !Character.isDigit(now)){
                return false;
            }
            // ÷ 0
            if (now == '0' && c == '÷') {
                return false;
            }
            c = now;

        }
        return true;
    }
}
