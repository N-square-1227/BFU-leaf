package com.example.myapplication;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

/*
    存储、更新 UI 数据
    调用 Calculate 类里的运算并改变结果
 */
public class CalculatorViewModel extends ViewModel
{
    /**
     * 输入字符串
     */
    private MutableLiveData<String> input ;
    /**
     * 结果字符串
     */
    private MutableLiveData<String> result ;
    /**
     * 单例设计模式返回 input
     * @return input 字符串
     */
    public MutableLiveData<String> getInput()
    {
        if (this.input == null) {
            this.input = new MutableLiveData<>();
            this.input.setValue("");
        }

        return this.input;
    }
    /**
     * 单例设计模式返回 result
     * @return result 字符串
     */
    public MutableLiveData<String> getResult()
    {
        if (this.result == null) {
            this.result = new MutableLiveData<>();
            this.result.setValue("");
        }

        return this.result;
    }
    public void addToString(String s){
        String text = input.getValue() + s;
        this.input.setValue(text);
    }
    /**
     * CE 只清空 result
     */
    public void clearResult(){
        this.result.setValue("");
    }
    /**
     *  C 两个都清空
     */
    public void clearBoth(){
        this.input.setValue("");
        this.result.setValue("");
    }
    /**
     * 调用 Calculate 里的计算方法处理字符串
     */
    public void Calculate()
    {
        String inputs = getInput().getValue();
        System.out.println(inputs);
         // 输入合法
        if (Calculator.isValid(inputs) ){
            double ans = Calculator.calculate(inputs); //ok
            this.result.setValue(String.valueOf(ans));
        }
         // 输入不合法
        else
        {
            // Toast.makeText(getA, "输入有问题，请重新输入！", Toast.LENGTH_SHORT).show();
            this.result.setValue("输入有问题，请重新输入！");
        }
    }
}
