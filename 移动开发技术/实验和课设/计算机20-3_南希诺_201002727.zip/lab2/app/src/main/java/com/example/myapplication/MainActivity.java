package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.lifecycle.ViewModelProvider;

import android.os.Bundle;

import com.example.myapplication.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    CalculatorViewModel calculatorViewModel;
    ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        // 初始化 UI，便于存储，调用数据，但不对数据做运算
        calculatorViewModel = new ViewModelProvider(
                this, new
                ViewModelProvider.NewInstanceFactory()
        ).get(CalculatorViewModel.class);

        // 将控件绑定到主界面
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main);

        // 将 binding 和 ViewModel 绑定起来
        binding.setLifecycleOwner(this);
        binding.setCalViewModel(calculatorViewModel);
    }
}