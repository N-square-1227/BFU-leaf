package com.example.myapplication;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Environment;
import android.widget.ImageView;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ImgProcess extends Activity
{
    /**
     * 自定义图片名，获取照片的 file
     */
    public File createImgFile(String photoPath)
    {
        // 创建图片文件并确定文件名
        @SuppressLint("SimpleDateFormat") String fileName = "img_"+new SimpleDateFormat("yyyy_MMdd_HH_mm_ss").format(new Date())+".jpg";
        File dir;
        // 如果已有目录则打开，否则新建一个目录
        if(Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)){
            dir = Environment.getExternalStorageDirectory();
        }else{
            dir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        }
        // 如果已有相同文件名就删之前的，创建的总是最新的
        File tempFile = new File(dir, fileName);
        try {
            if(tempFile.exists()){
                tempFile.delete();
            }
            tempFile.createNewFile();
        } catch (IOException e) {
            e.printStackTrace();
        }
        //获取文件绝对路径
        photoPath = tempFile.getAbsolutePath();
        return tempFile;
    }

    /**
     * 压缩图片，否则太大显示不出来
     */
    public void zipPicture(ImageView photoImageView, String photoPath)
    {
        //获取 imageview 的宽, 高
        int targetWidth = photoImageView.getWidth();
        int targetHeight = photoImageView.getHeight();

        //根据图片路径，获取 bitmap 的宽和高
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(photoPath,options);
        int photoWidth = options.outWidth;
        int photoHeight = options.outHeight;

        // 获取缩放比
        int inSampleSize = 1;
        // 按缩放比处理图片
        if(photoWidth > targetWidth || photoHeight > targetHeight)
        {
            int widthRatio = Math.round((float)photoWidth / targetWidth);
            int heightRatio = Math.round((float)photoHeight / targetHeight);
            inSampleSize = Math.min(widthRatio,heightRatio);
        }

        //使用现在的 options 获取 Bitmap
        options.inSampleSize = inSampleSize;
        options.inJustDecodeBounds = false;
        Bitmap bitmap = BitmapFactory.decodeFile(photoPath,options);
        // 更改屏幕上显示的图片
        photoImageView.setImageBitmap(bitmap);
    }

    // 将图片添加进手机相册
    public void albumAddPicture(Uri photoUri)
    {
        Intent intent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
        intent.setData(photoUri);
        // 调用广播通知
        this.sendBroadcast(intent);
    }
}
