package com.example.myapplication;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MainActivity extends Activity
{
    private ImgProcess imgProcess = new ImgProcess();

    private Button cameraButton;
    private Button albumButton;
    private ImageView photoImageView;

    private Uri photoUri;
    private String photoPath;

    private static final int TAKE_PHOTO = 0;
    private static final int PICK_PHOTO = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initViews();
    }

    /**
     * 初始化控件和监听器
     */
    public void initViews()
    {
        cameraButton = findViewById(R.id.camera);
        albumButton = findViewById(R.id.album);
        photoImageView = findViewById(R.id.photo);

        //拍照
        cameraButton.setOnClickListener(view -> {
            // 新建相机界面
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            // 设置文件存储路径
            File photoFile = imgProcess.createImgFile(photoPath);
            photoUri = Uri.fromFile(photoFile);
            intent.putExtra(MediaStore.EXTRA_OUTPUT,photoUri);
            // 启动后续动作
            startActivityForResult(intent,TAKE_PHOTO);
        });

        //从相册获取照片
        albumButton.setOnClickListener(view -> {
            // 新建相册页面
            Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
            // 找到 image 类型的文件，设置展示它们
            intent.setType("image/*");
            // 启动后续动作
            startActivityForResult(intent, PICK_PHOTO);
        });
    }

    @SuppressLint("Range")
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);
        // 结果正确，同意操作
        if(resultCode == RESULT_OK)
        {
            // 切换操作码
            switch (requestCode)
            {
                // 拍照
                case TAKE_PHOTO:
                    imgProcess.zipPicture(photoImageView, photoPath);
                    imgProcess.albumAddPicture(photoUri);
                    break;
                // 相册选择
                case PICK_PHOTO:
                    // data 中自带返回的 uri
                    photoUri = data.getData();
                    //获取照片路径, 游标读取
                    String[] filePathColumn = {MediaStore.Audio.Media.DATA};
                    Cursor cursor = getContentResolver().query(photoUri,filePathColumn,null,null,null);
                    cursor.moveToFirst();
                    photoPath = cursor.getString(cursor.getColumnIndex(filePathColumn[0]));
                    cursor.close();
                    //根据照片路径找到相应的照片后压缩
                    imgProcess.zipPicture(photoImageView, photoPath);
                    break;
            }
        }
    }
}
