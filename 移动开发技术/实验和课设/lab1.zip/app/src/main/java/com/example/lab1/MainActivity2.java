package com.example.lab1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        // 获得 intent 的引用
        Intent intent = getIntent();
        // 根据 key 取出 value
        String message = intent.getStringExtra(MainActivity.MSG_TYPE);
        // 获得文本框引用，设置文字
        TextView textView = findViewById(R.id.output_text);
        textView.setText(message);
    }
}