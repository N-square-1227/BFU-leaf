package com.example.lab1;

public class Checker {
    private static final String nameDefault = "kiana";
    private static final String passwordDefault = "1207";
    private final String name;
    private final String password;

    public Checker(String name, String password) {
        this.name = name;
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public String getPassword() {
        return password;
    }
    public String getMessage(boolean isTruE){
        // 选了选框
        if (isTruE){
            return (getName() + " / " + getPassword() + "  CHECKED!");
        }else {
            return (getName() + " / " + getPassword());
        }
    }
    public static boolean isTruE(String name, String password){
        return nameDefault.equals(name) && passwordDefault.equals(password);
    }
}
