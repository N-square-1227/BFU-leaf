package com.example.lab1;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity
{
    public static final String MSG_TYPE = "jumpTo2";

    // private EditText r;
    // 为什么？加上了 private 限定符之后，这些量即使在后面的 findViewById()
    // 中被使用了，但是却还是会提示未使用
    /**
     * 用户名，密码
     */
     EditText nm, password;
    /**
     * 复选框
     */
     CheckBox checkBox;
    /**
     * 提交按钮
     */
     Button button;
       /**
     * 标题文字
     */
     TextView textView;
    /**
     * 错误提示
     */
     TextView wrongText;
    /**
     * 复选框是否被选中
     */
     boolean isTruE = false;

    //private TextView text;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //text = findViewById(R.id.name_text);
        //r = findViewById(R.id.name_text);
        // 获得引用
        textView = findViewById(R.id.bar_text);
        wrongText = findViewById(R.id.wrong_text);
        nm = findViewById(R.id.name_text);
        password = findViewById(R.id.pwd_text);
        button = findViewById(R.id.sub_button);
        checkBox = findViewById(R.id.check_box);

        // 初始化
        isTruE = false;
        // 选中了复选框
        checkBox.setOnCheckedChangeListener((compoundButton, b) -> isTruE = !isTruE);
        // 点按按钮时做的事
        button.setOnClickListener(view ->
        {
            // 获得编辑框中的文字
            // 噢，原来是这样，是通过上面的引用取得，没办法从这里直接取出来
            String name = nm.getText().toString();
            String pwd = password.getText().toString();
            Checker checker = new Checker(name, pwd);

            // 获取 intent
            Intent intent = new Intent(MainActivity.this, MainActivity2.class);

            // 没选复选框, 直接发过去
            if (!isTruE){
                intent.putExtra(MSG_TYPE, checker.getMessage(false));
                // 传输消息
                startActivity(intent);
            }
            // 选了复选框
            else
            {
                boolean state = Checker.isTruE(name, pwd);
                // 检测失败！不能登录！
                if (!state)
                {
                    // 显示错误提示
                    wrongText.setVisibility(View.VISIBLE);
                    // 清空所有信息
                    password.setText("");
                    nm.setText("");
                }
                // 检测成功！
                else
                {
                    // 向 intent 中附加消息
                    intent.putExtra(MSG_TYPE, checker.getMessage(true));
                    // 传输消息
                    startActivity(intent);
                }
            }
        });
    }
}
