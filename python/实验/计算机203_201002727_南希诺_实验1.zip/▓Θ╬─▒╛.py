from docx import Document
from docx.shared import RGBColor


def gettext(doc):
    for p in doc.paragraphs:
        for r in p.runs:
            if r.bold:
                bold.append(r.text)
            if r.font.color.rgb == RGBColor(255, 0, 0):
                red.append(r.text)


bold = []
red = []
doc = Document('test.docx')
gettext(doc)
result = {'红色字体': red,
          '粗体': bold,
          '又红又粗': set(red) & set(bold)}

for txt in result.keys():
    print(txt.center(30, '■'))
    for text in result[txt]:
        print(text, end='\n')
