import random
hole = [0, 0, 0, 0, 0]
direction = [0, 1]
i = 1


def move(fox):
    mv = random.sample(direction, 1)

    if mv == 1:
        if fox < 5:
            fox += 1
        else:
            fox -= 1
    else:
        if fox > 1:  # 左移
            fox -= 1
        else:
            fox += 1

    return fox


fox = random.randint(1, 5)
for i in range(5):
    fox = move(fox)
    try:
        catch = int(input("选择你的洞口吧ovo(1~5):"))
        if 5 < catch or catch < 1:
            print("输入的数字不合法！请重新输入！")
            print("你还有%d次机会" % 6-i)
            continue
    except Exception:
        print("要输入整数才行哦~你还可以试%d次" % (5-i))
        continue
    if fox == catch:
        print("抓到你了~别~想~逃~开~哦~(wink)！")
        break
    else:
        print("你总共试了%d次，暂时还没有抓住" % (i+1))
        print("提示：粉毛狐狸刚才在第%d个洞里" % fox)

else:
    print("你没有抓到粉毛狐狸。\n你气得又哭又闹，满地打滚，呜呜呜呜，好可怜呀~")
