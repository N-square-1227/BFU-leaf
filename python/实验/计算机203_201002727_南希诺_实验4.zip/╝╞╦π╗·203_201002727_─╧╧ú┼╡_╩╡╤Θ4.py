from urllib.request import urlopen
import urllib.request
import re
import requests
import os

myURL = "https://www.cae.cn/cae/html/main/col48/column_48_1.html"
# 通过requests.get来向网页发出请求并得到返回结果,返回结果respond变量里的text就是Html页面
respond = requests.get(myURL)
respond.encoding = 'utf-8'
# \d+表示匹配后面所有数字
HOF = re.findall('<a href="/cae/html/main/colys/(\d+).html" target="_blank">', respond.text)

for person in HOF:
    # 每个人专属的链接
    personURL = "https://www.cae.cn/cae/html/main/colys/{}.html".format(person)
    personRes = requests.get(personURL)
    personRes.encoding = "utf-8"

    file_name = re.findall('<div class="right_md_name">(.*?)</div>', personRes.text)[0]
    # (.*?)表示匹配任意字符到下一组符合条件的字符， text是正文
    # re.S:    https://blog.csdn.net/weixin_42781180/article/details/81302806
    intro_list = re.findall('<p>&ensp;&ensp;&ensp;&ensp;(.*?)</p>', personRes.text, re.S)
    # join: https://www.w3school.com.cn/python/ref_string_join.asp
    introduce = '\n'.join(intro_list)
    with open(file_name + '.txt', mode='a+', encoding="utf-8") as f:
        f.write(introduce)

    picRes = re.findall(r'<img src="/cae/admin/upload/img/(.+)" style=', personRes.text, re.I)
    if picRes:
        # 图片的http地址
        picURL = r'http://www.cae.cn/cae/admin/upload/img/{0}'.format(picRes[0].replace(' ', r'%20'))
        with open(file_name + '.jpg', mode='wb') as jpgf:
            # 把链接上的图片先读取出来,然后写入本地
            jpgf.write(urlopen(picURL).read())
