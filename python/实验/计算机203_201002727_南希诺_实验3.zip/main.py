import socket
from os.path import commonprefix

# 聊天回复字典
words = {'岩者': '六合引之为骨',
         '石者': '八荒韫玉而明',
         '珪璋': '暝仍不移其晖',
         '黄琮': '破而不夺其坚',
         '苍璧': '驱之长昭天理',
         '金玉': '礼予天地四方'}
# 服务端主机IP地址和端口号
HOST = "127.0.0.1"
PORT = 8000
# 使用IPV4，tcp协议传输数据创建服务器socket（IPv4、TCP套接字）
serversocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
# 绑定端口和端口号
serversocket.bind((HOST, PORT))
# 开始监听，规定最多支持1个客户端连接
serversocket.listen(1)
print('监听的端口号是：', PORT)
clientsocket, clientaddress = serversocket.accept()  # 使用阻塞方法accept以等待客户机连接请求
print("和", clientaddress, "连接！")  # 成功接收请求后输出客户机的信息

# 开始聊天
while True:
    # 最多可以接收1024比特大小的内容
    data = clientsocket.recv(1024).decode('utf-8')
    # 如果是空，退出
    if not data:
        break
    print('接收到的内容：', repr(data))
    # 模糊匹配
    # os.path.commonprefix()用于获取路径列表中最长的公共路径前缀
    m = 0
    ans = ''
    for k in words.keys():
        if k == data:
            ans = k
            break
        elif not set(k).isdisjoint(data):
            ans = k
    # 回送数据到客户机
    clientsocket.sendall(words.get(ans, "找不到你所问问题的答案…").encode('utf-8'))
# 关客户机
clientsocket.close()
# 关服务器
serversocket.close()
