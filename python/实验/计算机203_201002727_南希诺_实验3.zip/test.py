import socket
import sys

# 服务端主机IP地址和端口号
HOST = "127.0.0.1"
PORT = 8000
# 使用IPV4，tcp协议传输数据
clientsocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
try:
    # 连接服务器
    clientsocket.connect((HOST, PORT))
except Exception as e:
    print('找不到服务器，请重试！')
    sys.exit()
while True:
    data = input('请输入你想发送的消息：')
    if not data:
        break
    # 发送数据
    clientsocket.send(data.encode('utf-8'))
    # 从服务端接收数据
    newdata = clientsocket.recv(1024)
    zhdata = str(newdata, 'utf-8')
    print('回复：', repr(zhdata))

# 关闭连接
clientsocket.close()