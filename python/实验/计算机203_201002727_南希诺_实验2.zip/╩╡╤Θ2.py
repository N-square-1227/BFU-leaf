import tkinter as tk
import tkinter.ttk
from docx import Document
import random
import os


def generate(grade=3):
    biggestNum = 100
    if grade < 3:
        operators = "+-"
        biggestNum = 20
    elif grade <= 4:
        operators = "＋－×÷"
    else:
        operators = "＋－×÷()"

    # 创建Word文档
    doc = Document()
    table = doc.add_table(rows=50, cols=4)
    # 把生成的题目通过遍历放进表格里
    for row in range(50):
        for col in range(4):
            operator = random.choice(operators)
            # 5年级以下不用考虑括号,两个数一个运算符足够
            if grade < 5:
                firstNum = random.randint(1, biggestNum)
                secondNum = random.randint(1, biggestNum)
                # 小学还没有学负数
                if operator == '-' and firstNum < secondNum:
                    firstNum, secondNum = secondNum, firstNum
                cal = str(firstNum).ljust(2, ' ') + ' ' + operator + ' ' + str(secondNum).ljust(2, ' ') + '='
            # (a + b) x c =
            else:
                firstNum = random.randint(1, biggestNum)
                secondNum = random.randint(1, biggestNum)
                thirdNum = random.randint(1, biggestNum)
                optr1 = random.choice("＋－×÷")
                optr2 = random.choice("＋－×÷")
                # (a + b) x c = or a x ( b - c ) =
                RanNum = random.randint(0, 1)
                if RanNum == 0:
                    #  方案一
                    # 小学还没有学负数
                    if optr1 == '-' and firstNum < secondNum:
                        firstNum, secondNum = secondNum, firstNum
                    cal = '(' + str(firstNum).ljust(2, ' ') + optr1 + str(secondNum).ljust(2, ' ') + ')' \
                          + optr2 + str(thirdNum).ljust(2, ' ') + '='
                else:
                    #  方案2
                    # 小学还没有学负数
                    if optr2 == '-' and secondNum < thirdNum:
                        secondNum, thirdNum = thirdNum, secondNum
                    cal = str(firstNum).ljust(2, ' ') + optr1 + ' ( ' + str(secondNum).ljust(2, ' ') \
                          + optr2 + str(thirdNum).ljust(2, ' ') + ')='

            cell = table.cell(row, col)
            cell.text = cal

    doc.save('口算题.docx')
    # 双击打开文件
    os.startfile('口算题.docx')


# 象征着程序主入口
if __name__ == '__main__':
    window = tk.Tk()
    # 设置窗口title
    window.title('小学口算题生成器')
    # 设置窗口大小:宽x高,注,此处不能为 "*",必须使用 "x"
    window.geometry('450x300')
    # 设置主窗口的背景颜色,颜色值可以是英文单词,或者颜色值的16进制数,还可以使用Tk内置的颜色常量
    window["background"] = "#87CEFA"
    # 添加文本内,设置字体的前景色和背景色，和字体类型、大小
    # 年级文本块
    grade = tk.Label(window, text="请选择年级：", bg="#E1FFFF", fg="black", justify=tk.RIGHT, width=50,
                     font=('Times', 15))
    grade.place(x=30, y=40, width=150, height=35)
    # 选择六个年级
    gradeChoose = tk.ttk.Combobox(window, values=(1, 2, 3, 4, 5, 6), width=50)
    gradeChoose.place(x=160, y=40, width=50, height=36)
    # 数量文本块
    number = tk.Label(window, text="请选择数量：", bg="#E1FFFF", fg="black", justify=tk.RIGHT, width=50,
                     font=('Times', 15))
    # 选择数量
    number.place(x=240, y=40, width=150, height=35)
    numberChoose = tk.ttk.Combobox(window, values=(50, 100, 150, 200, 250, 300), width=50)
    numberChoose.place(x=370, y=40, width=50, height=36)


    def go():
        grade = int(gradeChoose.get())
        generate(grade)

    # 添加按钮，以及按钮的文本，Button 控件的作用就是“执行一个函数”
    button = tk.Button(window, text="点我生成！", bg="#E1FFFF", fg="black", justify=tk.RIGHT,
                    width=50, font=('Times', 15), command=go)
    # 将按钮放置在主窗口内
    button.place(x=155, y=200, width=150, height=36)
    # 进入主循环，显示主窗口
    window.mainloop()
