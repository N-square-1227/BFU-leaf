
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

@WebServlet("/GetResume")
public class GetResume extends HttpServlet
{
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException
    {
        req.setCharacterEncoding("gbk");
        resp.setCharacterEncoding("gbk");

        PrintWriter out = resp.getWriter();
        String formHead= """
                <HTML>
                <HEAD><TITLE>个人简历</TITLE></HEAD>
                <BODY BGCOLOR="#FDF5E6">
                <H1 ALIGN=CENTER>个人简历</H1>
                <TABLE BORDER=1 ALIGN=CENTER>
                <TR BGCOLOR="#FFAD00">
                <TH>条目<TH>内容""";

        String formEnd="</TABLE>\n</body></html>";

        out.print(formHead);

        Map<String, String> listMap = new HashMap<>();
        listMap.put("name", "姓名");
        listMap.put("sex", "性别");
        listMap.put("add", "应聘地点");
        listMap.put("address", "籍贯");
        listMap.put("intro", "自我介绍");

        Enumeration<String> paramNames = req.getParameterNames();
        while(paramNames.hasMoreElements())
        {
            String paramName = paramNames.nextElement();
            out.print("<TR><TD>" + listMap.get(paramName) + "\n<TD>");
            String[] paramValues = req.getParameterValues(paramName);
            if (paramValues.length == 1)
            {
                String paramValue = paramValues[0];
                if (paramValue.length() == 0)
                    out.println("<I>No Value</I>");
                else
                    out.println(GetReg.filter(paramValue));
            }
            else
            {
                out.println("<UL>");
                for (String paramValue : paramValues) {
                    out.println("<LI>" + GetReg.filter(paramValue));
                }
                out.println("</UL>");
            }
        }
        out.print(formEnd);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        doGet(req, resp);
    }
}
