
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/GetReg")
public class GetReg extends HttpServlet
{
    RequestDispatcher requestDispatcher;
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
    {
        resp.setContentType("text/html;charset=gbk");
        req.setCharacterEncoding("gbk");
        // 不能在PrintWriter out = response.getWriter();后面设置编码方式，
        // 否则就会中文乱码.因为在out对象初始化之后再设置就编码方式就没意义了
        String user = filter(req.getParameter("username"));
        String password = filter(req.getParameter("password"));

//        out.println("用户"+user+" 你好，你的密码是："+password);
        if (isParameterNull(user) || isParameterNull(password)) {
            System.out.println("用户名和密码都不能为空！请重新输入！\n");
            requestDispatcher = req.getRequestDispatcher("register.html");
            requestDispatcher.forward(req, resp);
        }
        else if("aaa".equals(user)){
            System.out.println("用户名不能为aaa！请重新输入！\n");
            requestDispatcher = req.getRequestDispatcher("register.html");
            requestDispatcher.forward(req, resp);
        }else {
            requestDispatcher = req.getRequestDispatcher("resume.html");
            requestDispatcher.forward(req, resp);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
    {
        doGet(req, resp);
    }

    public boolean isParameterNull(String str){
        return "".equals(str);
    }

    public static String filter(String input)
    {
        if (!hasSpecialChars(input)) {
            return(input);
        }
        StringBuffer filtered = new StringBuffer(input.length());
        char c;
        for(int i = 0; i < input.length(); i++)
        {
            c = input.charAt(i);
            switch (c)
            {
                case '<' -> filtered.append("&lt;");
                case '>' -> filtered.append("&gt;");
                case '"' -> filtered.append("&quot;");
                case '&' -> filtered.append("&amp;");
                default -> filtered.append(c);
            }
        }
        return(filtered.toString());
    }

    private static boolean hasSpecialChars(String input)
    {
        boolean flag = false;
        if ((input != null) && (input.length() > 0))
        {
            for(int i = 0; i < input.length(); i++)
            {
                switch (input.charAt(i)) {
                    case '<', '"', '&', '>' -> flag = true;
                }
            }
        }
        return(flag);
    }
}
