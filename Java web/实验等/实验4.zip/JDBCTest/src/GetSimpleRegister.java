import beans.DBConnection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

@WebServlet("/GetSimpleRegister")
public class GetSimpleRegister extends HttpServlet
{
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {
        // �����ļ�����
        request.setCharacterEncoding("utf-8");
        response.setCharacterEncoding("utf-8");

        // ��ȡ�����������
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // ִ�е�¼��֤
        try {
            String forwardURL = verify(username, password);
            request.getRequestDispatcher(forwardURL).forward(request, response);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public String verify(String username, String password) throws Exception
    {
        Statement statement;
        Connection connection = DBConnection.getConnection();
        statement = connection.createStatement();
        // ���üӷֺ�
        String searchSql = "SELECT COUNT(*) FROM detailedinfo WHERE username = " +
                "\'" +username+"\'";
        // System.out.println(searchSql);
        ResultSet count = statement.executeQuery(searchSql);
        String forwardURL;
        // �������û�
        if (count.next()) {
            // ע��
            String insertSql = "INSERT INTO user VALUE(" + "\'" + username + "\'"+
                    "," + "\'" + password + "\')";
            statement.executeUpdate(insertSql);
            forwardURL = "detailedregister.jsp";
        }
        // �������û�������ע��
        else {
            forwardURL = "simpleregister.jsp";
        }
        count.close();
        // System.out.println(count);
        connection.close();
        statement.close();
        return forwardURL;
    }
}
