import beans.DBConnection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Statement;

@WebServlet("/GetDelete")
public class GetDelete extends HttpServlet
{
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {
        // �����ļ�����
        request.setCharacterEncoding("utf-8");
        response.setCharacterEncoding("utf-8");

        String username = request.getParameter("username");

        // System.out.println(username);// ok

        try {
            delete(username);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // ���˵�����Աҳ��
        request.getRequestDispatcher("adminPage.jsp").forward(request, response);
    }
    public void delete(String usr) throws Exception
    {
        Statement statement;
        Connection connection = DBConnection.getConnection();

        statement = connection.createStatement();
        // ���üӷֺ�
        String deleteSql = "DELETE FROM user WHERE username = '" + usr + "'";
        //System.out.println(deleteSql);
        statement.executeUpdate(deleteSql);

        deleteSql = "DELETE FROM detailedinfo WHERE username = '" + usr + "'";
       // System.out.println(deleteSql);
        statement.executeUpdate(deleteSql);
        // System.out.println(count);
        connection.close();
        statement.close();
        //return forwardURL;
    }
}
