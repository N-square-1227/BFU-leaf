import beans.DBConnection;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.io.IOException;
import java.io.Serial;
import java.sql.Statement;

@WebServlet("/GetModify")
public class GetModify extends HttpServlet
{
    @Serial
    private static final long serialVersionUID = 1L;

    /**
     * ��һ��Ҫ�ĵ��û���
     */
    private static String preUsername;

    public static void setPreUsername(String preUsername) {
        GetModify.preUsername = preUsername;
    }

    public static String getPreUsername() {
        return preUsername;
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {
        // �����ļ�����
        request.setCharacterEncoding("utf-8");
        response.setCharacterEncoding("utf-8");

        // ��ȡ�����������
        String username = request.getParameter("username");
        int age = Integer.parseInt(request.getParameter("age"));
        String sexy = request.getParameter("sexy");
        String location = "D:\\\\";
        request.setAttribute("location", location);

        // �޸����ݿ��ڶ�Ӧ��������
        try {
            changeToDB(username, age, sexy, location);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // ת������ʾ���棬չʾ�û���Ϣ
        String forwardURL = "showregisteredinfo.jsp";
        request.getRequestDispatcher(forwardURL).forward(request, response);

    }
    public void changeToDB(String username, int age, String sexy, String location) throws Exception
    {
        Statement statement;
        Connection connection = DBConnection.getConnection();
        statement = connection.createStatement();
        // ���üӷֺţ���
        String changeSql = "UPDATE detailedinfo SET username = "+
                "\'" +username+"\'"+", age = " + age+", sexy = "+
                "\'" +sexy+"\'"+", picturelocation = "+
                "\'" +location+"\'"+
                "WHERE username = \'" + GetModify.getPreUsername() + "\'";
        // System.out.println(changeSql);
        statement.executeUpdate(changeSql);
        statement.close();
        // �����ܵ�Ӱ�������
        // int result = preparedStatement.executeUpdate();
        DBConnection.dbClose(connection, null, null);
    }
}
