package beans;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class DBConnection {

	/**
	 * �������ݿ�
	 * @return ���Ӻ�ľ�� conn
	 * @throws Exception ����ʧ��
	 */
	   public static Connection getConnection() throws Exception{
	    	Connection conn;

	    	Class.forName("com.mysql.jdbc.Driver");
	    	String url="jdbc:mysql://localhost:3306/Javaweb";
	    	conn=DriverManager.getConnection(url,"root","root");
	    	return conn;
	    }

		/**
		*�ر�����
		 */
	    public static void dbClose(Connection conn,PreparedStatement ps,ResultSet rs)
	    throws SQLException
	    {
			if (rs != null){
				rs.close();
			}
	          if (ps != null){
				  ps.close();
			  }
	        if (conn != null){
				conn.close();
			}
		}
}
