package beans;

import java.io.IOException;
import java.io.Serial;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.concurrent.ScheduledExecutorService;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class GetDetailInfo
 */
@WebServlet("/GetDetailedRegister")
public class GetDetailedRegister extends HttpServlet {
	@Serial
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		
		String username=request.getParameter("username");
 		int age=Integer.parseInt(request.getParameter("age"));
 		String sexy=request.getParameter("sexy");
 		String location="E:\\\\";
 		request.setAttribute("location",location);

		Check(request, response, username);
 		insertBeantoDB(username, age, sexy, location);

		 // ת������ʾҳ�棬չʾ�û���Ϣ
 		String forwardUrl="showregisteredinfo.jsp";
 		RequestDispatcher dispatcher =
 				request.getRequestDispatcher(forwardUrl);
 				dispatcher.forward(request, response);	
	}
	public void Check(HttpServletRequest request, HttpServletResponse response, String name)
	{
		Statement statement;
		Connection connection;
		try {
			connection = DBConnection.getConnection();
			statement = connection.createStatement();
			// ���üӷֺ�
			String searchSql = "SELECT username FROM detailedinfo";
			// System.out.println(searchSql);
			// ResultSet count = statement.executeQuery(countSql);
			ResultSet search = statement.executeQuery(searchSql);
			while (search.next()) {
				// ����
				if (search.getString(1).equals(name)){
					connection.close();
					statement.close();
					String forwardUrl="detailedregister.jsp";
					RequestDispatcher dispatcher =
							request.getRequestDispatcher(forwardUrl);
					dispatcher.forward(request, response);
				}
			}
			// count.close();
			connection.close();
			statement.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void insertBeantoDB(String username, int age, String sexy, String picturelocation){
		Connection conn=null;

		Statement st=null;				
		try{
		  conn=DBConnection.getConnection();
		  st=conn.createStatement();
		  //��bean����ƴ�ӳ�Insert���
		  String sql1 = "insert into detailedinfo(username,age,sexy,picturelocation) values("+
		  				"\'"+username+"\'"+","+
		  				age+","+
		  				"\'"+sexy+"\'"+","+
		  				"\'"+picturelocation+"\'"+")";
		st.executeUpdate(sql1);
		}catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try{
				conn.close();
				st.close();
			}catch(Exception e){
				e.printStackTrace();
			}
		}
	}
}
