import jsp.test.LiuyanBean;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.Serial;

@WebServlet("/DoLiuyanInput")
public class DoLiuyanInput extends HttpServlet
{
    @Serial
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {
        // 转码
        request.setCharacterEncoding("utf-8");

        // 读取表单中的内容
        String userName = request.getParameter("userName");
        String content = request.getParameter("Liuyan");

        // 创建留言 bean 实例，并设置 bean 属性
        LiuyanBean resultInfo = new LiuyanBean();
        resultInfo.setUserName(userName);
        resultInfo.setContent(content);

        // 存储 bean，目的是和其他文件共享 bean
        request.setAttribute("resultInfo", resultInfo);

        // 流程判断，以确定不同的转发结果地址
        String forwardURL;
        if (!isParameterBlank(userName) && !isParameterBlank(content) && content.length() > 5){
//            学习写法，比你的思路好在哪里？相同的语句不用写很多次，而且判断流程更合理
//            request.getRequestDispatcher("/inputOk.jsp");
            forwardURL = "/inputOk.jsp";
        }
        else if (isParameterBlank(userName) || isParameterBlank(content)){
            forwardURL = "/inputAgain.jsp";
        }else {
            forwardURL = "/inputError.jsp";
        }
        // 实现转发
        request.getRequestDispatcher(forwardURL).forward(request, response);
    }
    public boolean isParameterBlank(String p){
        return "".equals(p);
    }
}
