package jsp.test;

public class resumeBean
{
    /**
     * 用户名
     */
    private String username;
    /**
     * 性别
     */
    private String sex;
    /**
     * 应聘地点
     */
    private String wantAddress;
    /**
     * 文件名
     */
    private String file;
    /**
     * 地址
     */
    private String address;

    public String getUsername()
    {
        return username;
    }

    public void setUsername(String username)
    {
        this.username = username;
    }

    public String getSex()
    {
        return sex;
    }

    public void setSex(String sex)
    {
        this.sex = sex;
    }

    public String getWantAddress()
    {
        return wantAddress;
    }

    public void setWantAddress(String wantAddress)
    {
        this.wantAddress = wantAddress;
    }

    public String getFile()
    {
        return file;
    }

    public void setFile(String file)
    {
        this.file = file;
    }

    public String getAddress()
    {
        return address;
    }

    public void setAddress(String address)
    {
        this.address = address;
    }

    @Override
    public String toString()
    {
        return "resumeBean{" +
                "username='" + username + '\'' +
                ", sex='" + sex + '\'' +
                ", wantAddress='" + wantAddress + '\'' +
                ", file='" + file + '\'' +
                ", address='" + address + '\'' +
                '}';
    }
}
