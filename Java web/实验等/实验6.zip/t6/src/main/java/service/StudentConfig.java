package service;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import pojo.Course;
import pojo.Student;

@Configuration
@Import(value = {Student.class, Course.class})
public class StudentConfig
{
    @Bean("zs")
    public Student zhangSan()
    {
        return new Student("张三", new Course("数学", 95));
    }
    @Bean("ls")
    public Student liSi()
    {
        return new Student("李四", new Course("语文", 90));
    }
    @Bean("we")
    public Student wangEr()
    {
        return new Student("王二", new Course("计算机", 85));
    }
}
