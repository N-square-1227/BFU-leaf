package utils;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import pojo.Student;
import pojo.StudentCon;
import pojo.StudentVal;
import service.StudentConfig;

public class Main
{
    /**
     * 基于 xml 文件，构造注入和值注入
     */
    public void test1()
    {
        System.out.println("下面是构造注入：");
        // 构造注入
        AbstractApplicationContext classPathXmlApplicationContext = new ClassPathXmlApplicationContext
                ("constructInsert.xml");
        StudentCon studentCon = (StudentCon) classPathXmlApplicationContext.getBean("nxn");
        System.out.println(studentCon.getSname() + " " + studentCon.getSage());
        StudentCon studentConZS = (StudentCon) classPathXmlApplicationContext.getBean("zs");
        System.out.println(studentConZS.getSname() + " " +  studentConZS.getSage());

        System.out.println("下面是值注入：");
        // 值注入
        classPathXmlApplicationContext = new ClassPathXmlApplicationContext("valueInsert.xml");
        StudentVal studentVal = (StudentVal) classPathXmlApplicationContext.getBean("nxn");
        System.out.println(studentVal.getSname() + " " +  studentVal.getSage());
        StudentVal studentValZS = (StudentVal) classPathXmlApplicationContext.getBean("zs");
        System.out.println(studentValZS.getSname() + " " +  studentValZS.getSage());
    }

    /**
     * 基于注解
     */
    public void test2()
    {
        ApplicationContext applicationContext = new
                AnnotationConfigApplicationContext(StudentConfig.class);

        Student zs = (Student) applicationContext.getBean("zs");
        System.out.println(zs);
        Student ls = (Student) applicationContext.getBean("ls");
        System.out.println(ls);
        Student we = (Student) applicationContext.getBean("we");
        System.out.println(we);
    }

    /**
     * 基于自动装配
     */
    public void test3()
    {
        AbstractApplicationContext classPathXmlApplicationContext = new ClassPathXmlApplicationContext
                ("autoWire.xml");
        Student stuzs = (Student) classPathXmlApplicationContext.getBean("zs");
        System.out.println("姓名：" + stuzs.getSname() + " 课程名：" + stuzs.getScourse().getCname() +
                " 分数：" + stuzs.getScourse().getCscore());
        Student stuls = (Student) classPathXmlApplicationContext.getBean("ls");
        System.out.println("姓名：" + stuls.getSname() + " 课程名：" +  stuls.getScourse().getCname() +
                " 分数：" + stuls.getScourse().getCscore());
        Student stuwe = (Student) classPathXmlApplicationContext.getBean("we");
        System.out.println("姓名：" + stuwe.getSname() + " 课程名：" +  stuwe.getScourse().getCname() +
                " 分数：" + stuwe.getScourse().getCscore());
    }
    public static void main(String[] args)
    {
        Main main = new Main();
        // 任务 1
        main.test1();
        // 任务 2
        main.test2();
        // 任务 2：自动装配
        main.test3();
    }
}
