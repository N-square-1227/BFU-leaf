package pojo;

public class Course
{
    /**
     * 课程名
     */
    String Cname;
    /**
     * 分数
     */
    float Cscore;

    public Course() {}

    public Course(String cname, float cscore)
    {
        Cname = cname;
        Cscore = cscore;
    }

    public float getCscore()
    {
        return Cscore;
    }

    public void setCscore(float cscore)
    {
        Cscore = cscore;
    }

    public String getCname()
    {
        return Cname;
    }

    public void setCname(String cname)
    {
        Cname = cname;
    }
}
