package pojo;

import org.springframework.stereotype.Component;

@Component
public class Student
{
    /**
     * 姓名
     */
    private String Sname;
    /**
     * 年龄
     */
    private String Sage;
    /**
     * 课程
     */
    private Course Scourse;

    public Student(String sname, Course scourse)
    {
        Sname = sname;
        Scourse = scourse;
    }
    // 顺序？
    public Student() {}

    public String getSname()
    {
        return Sname;
    }

    public void setSname(String sname)
    {
        Sname = sname;
    }

    public String getSage()
    {
        return Sage;
    }

    public void setSage(String sage)
    {
        Sage = sage;
    }

    public void setScourse(Course scourse)
    {
        Scourse = scourse;
    }

    public Course getScourse()
    {
        return Scourse;
    }

    public void takeExam()
    {
        System.out.println("——攀高危险——");
    }

    @Override
    public String toString()
    {
        return "姓名：" + Sname + " " +
                "课程名：" + Scourse.getCname() + " " +
                "分数：" + Scourse.getCscore() + " ";
    }
}
