package pojo;

public class StudentVal
{
    /**
     * 姓名
     */
    private String Sname;
    /**
     * 年龄
     */
    private String Sage;
    /**
     * 课程
     */
    private String Scourse;

    public String getSname()
    {
        return Sname;
    }

    public void setSname(String sname)
    {
        Sname = sname;
    }

    public String getSage()
    {
        return Sage;
    }

    public void setSage(String sage)
    {
        Sage = sage;
    }

    public String getScourse()
    {
        return Scourse;
    }

    public void setScourse(String scourse)
    {
        Scourse = scourse;
    }

    public void takeExam()
    {
        System.out.println("——攀高危险——");
    }
}
