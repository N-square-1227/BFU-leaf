package pojo;

public class StudentCon
{
    /**
     * 姓名
     */
    private String Sname;
    /**
     * 年龄
     */
    private String Sage;
    /**
     * 课程
     */
    private String Scourse;

    // 如果是构造注入就需要构造函数
    // 如果是值注入就不能写构造函数，只能写 getter setter 方法
    public StudentCon(String sname, String sage)
    {
        Sname = sname;
        Sage = sage;
    }

    public String getSname()
    {
        return Sname;
    }

    public void setSname(String sname)
    {
        Sname = sname;
    }

    public String getSage()
    {
        return Sage;
    }

    public void setSage(String sage)
    {
        Sage = sage;
    }

    public String getScourse()
    {
        return Scourse;
    }

    public void setScourse(String scourse)
    {
        Scourse = scourse;
    }

    public void takeExam()
    {
        System.out.println("——攀高危险——");
    }
}
