import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.HashSet;

@WebServlet("/PrintCookie")
public class PrintCookie extends HttpServlet
{
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException
    {
        req.setCharacterEncoding("gbk");
        resp.setCharacterEncoding("gbk");

        //看之前有没有登录过
        Cookie[] cookies = req.getCookies();
        boolean hasCookies = false;
        if (cookies != null)
        {
            for (Cookie c : cookies)
            {
                if ("login".equals(c.getName()))
                {
                    hasCookies = true;
                    break;
                }
            }
        }

        if (hasCookies)
        {
            System.out.println("Welcome!");

            PrintWriter out = resp.getWriter();
            String formHead= """
                <HTML>
                <HEAD><TITLE>个人简历</TITLE></HEAD>
                <BODY BGCOLOR="#FDF5E6">
                <H1 ALIGN=CENTER>个人简历</H1>
                <TABLE BORDER=1 ALIGN=CENTER>
                <TR BGCOLOR="#FFAD00">
                <TH>条目<TH>内容""";
            String formEnd="</TABLE>\n</body></html>";
            out.print(formHead);

//             建立 cookies 的 name 的 set
            HashSet<String> set = new HashSet<>();
            set.add("姓名");
            set.add("性别");
            set.add("地址");
            set.add("籍贯");
            set.add("介绍");

            for (Cookie c : cookies)
            {
                if (set.contains(URLDecoder.decode(c.getName(), StandardCharsets.UTF_8)))
                {
                    out.print("<TR><TD>" + URLDecoder.decode(c.getName(), StandardCharsets.UTF_8) + "\n<TD>");
                    out.print( URLDecoder.decode(c.getValue(), StandardCharsets.UTF_8) );
                }
            }
            out.print(formEnd);
        }
        //第一次登录，先去注册！
        else {
            System.out.println("login first!");
            resp.sendRedirect("register.html");
        }

    }
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }
}
