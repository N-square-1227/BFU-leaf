
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Enumeration;

@WebServlet("/GetResume")
public class GetResume extends HttpServlet
{
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException
    {
        req.setCharacterEncoding("gbk");
        resp.setCharacterEncoding("gbk");

        PrintWriter out = resp.getWriter();
        String formHead= """
                <HTML>
                <HEAD><TITLE>个人简历</TITLE></HEAD>
                <BODY BGCOLOR="#FDF5E6">
                <H1 ALIGN=CENTER>个人简历</H1>
                <TABLE BORDER=1 ALIGN=CENTER>
                <TR BGCOLOR="#FFAD00">
                <TH>条目<TH>内容""";

        String formEnd="</TABLE>\n</body></html>";

        out.print(formHead);

        Enumeration<String> paramNames = req.getParameterNames();

        while(paramNames.hasMoreElements())
        {
            String paramName = paramNames.nextElement();
            out.print("<TR><TD>" + paramName + "\n<TD>");
            String[] paramValues = req.getParameterValues(paramName);
            if (paramValues.length == 1)
            {
                String paramValue = paramValues[0];

                if (paramValue.length() == 0)
                    out.println("<I>No Value</I>");
                else
                    out.println(paramValue);
                Cookie cookie = new Cookie(URLEncoder.encode(paramName, StandardCharsets.UTF_8),
                        URLEncoder.encode(paramValue, StandardCharsets.UTF_8));
                cookie.setMaxAge(80);
                resp.addCookie(cookie);
            }
            else
            {
                StringBuilder value = new StringBuilder();
                out.println("<UL>");
                for (String paramValue : paramValues)
                {
                    out.println("<LI>" + paramValue);
                    value.append(paramValue);
                    value.append("-");
                }
                out.println("</UL>");

                Cookie cookie = new Cookie(URLEncoder.encode(paramName, StandardCharsets.UTF_8),
                        URLEncoder.encode(value.toString(), StandardCharsets.UTF_8));
                cookie.setMaxAge(80);
                resp.addCookie(cookie);
            }
        }
        out.print(formEnd);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException
    {
        doGet(req, resp);
    }
}
