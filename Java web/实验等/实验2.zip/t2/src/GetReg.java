
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/GetReg")
public class GetReg extends HttpServlet
{
    RequestDispatcher requestDispatcher;
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
    {
        resp.setContentType("text/html;charset=gbk");
        req.setCharacterEncoding("gbk");
        // 不能在PrintWriter out = response.getWriter();后面设置编码方式，
        // 否则就会中文乱码.因为在out对象初始化之后再设置就编码方式就没意义了
        String user = req.getParameter("username");
        String password = req.getParameter("password");

//        out.println("用户"+user+" 你好，你的密码是："+password);
        //检测用户名和密码是否有至少一个是空值
        if (isParameterNull(user) || isParameterNull(password))
        {
            System.out.println("用户名和密码都不能为空！请重新输入！\n");
            requestDispatcher = req.getRequestDispatcher("register.html");
            requestDispatcher.forward(req, resp);
        }
        else
        {
            //第一次登录
            Cookie c = new Cookie("login","true");
            c.setMaxAge(60);
            resp.addCookie(c);

            requestDispatcher = req.getRequestDispatcher("resume.html");
            requestDispatcher.forward(req, resp);
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
    {
        doPost(req, resp);
    }

    public boolean isParameterNull(String str){
        return str.equals("");
    }
}
