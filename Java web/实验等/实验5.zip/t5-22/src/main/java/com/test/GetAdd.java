package com.test;

import com.pojo.Product;
import com.pojo.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Date;

@WebServlet("/GetAdd")
public class GetAdd extends HttpServlet
{
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
    {
        // 设置文件编码
        req.setCharacterEncoding("utf-8");
        resp.setCharacterEncoding("utf-8");

        // 获取插入的用户和物品
        String productId = req.getParameter("productId");
        String userId = req.getParameter("userId");

        // 将信息插入到数据库中
        OrderTest orderTest = new OrderTest();
        orderTest.InsertOrder(Integer.parseInt(productId), new Date(), Integer.parseInt(userId), 2);

        // 回去
        req.getRequestDispatcher("IWillHaveOrder.jsp").forward(req, resp);
    }
}
