package com.pojo;

import java.util.Date;

public class Order
{
    private int userId;
    private int orderId;
    private int productId;
    private Date time;
    private int orderState;

    public Order() {}

    public int getUserId()
    {
        return userId;
    }

    public void setUserId(int userId)
    {
        this.userId = userId;
    }

    public int getOrderId()
    {
        return orderId;
    }

    public void setOrderId(int orderId)
    {
        this.orderId = orderId;
    }

    public int getProductId()
    {
        return productId;
    }

    public void setProductId(int productId)
    {
        this.productId = productId;
    }

    public Date getTime()
    {
        return time;
    }

    public void setTime(Date time)
    {
        this.time = time;
    }

    public int getOrderState()
    {
        return orderState;
    }

    public void setOrderState(int orderState)
    {
        this.orderState = orderState;
    }

    public Order(int userId, int orderId, int productId, Date time, int orderState)
    {
        this.userId = userId;
        this.orderId = orderId;
        this.productId = productId;
        this.time = time;
        this.orderState = orderState;
    }
}
