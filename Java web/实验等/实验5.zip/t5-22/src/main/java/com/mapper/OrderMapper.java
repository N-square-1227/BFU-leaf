package com.mapper;

import com.pojo.Order;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.List;

public interface OrderMapper
{
    /**
     * 获取用户订单
     * @param id 用户的 id
     * @return 订单列表
     */
    List<Order> getOrderList(int id);

    /**
     * 根据订单号获取某个订单
     * @param orderId 订单号
     * @return 订单实体
     */
    Order getOrderByOrderId(int orderId);

    /**
     * 插入一个订单
     * @param productId 产品 id
     * @param time 插入时间
     * @param userId 用户 id
     * @param orderState 订单状态
     */
    void insertIntoOrder(@Param("productId") int productId, @Param("time") Date time, @Param("userId") int userId, @Param("orderState") int orderState);

    /**
     * 删除 已经完成的（state = 2） 某个（id）订单
     * @param orderId 该订单的 id
     */
    void deleteOrder(int orderId);
}
