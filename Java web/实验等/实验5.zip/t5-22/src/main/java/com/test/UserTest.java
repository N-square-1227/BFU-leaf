package com.test;

import com.mapper.UserMapper;
import com.pojo.User;
import com.utils.MybatisUtil;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.SqlSession;

public class UserTest
{
    private SqlSession sqlSession ;
    private UserMapper userDao;
    /**
     * 测试用户名是否存在
     * 若存在，返回其对应的密码
     * @param userName 用户输入的用户名
     */
    public String testIsExists(String userName)
    {
        sqlSession = MybatisUtil.getSqlSession();
        userDao = sqlSession.getMapper(UserMapper.class);

        String password = userDao.isExists(userName);

        sqlSession.close();
        return password;
    }

    /**
     * 看用户名和密码是否匹配
     * @param userName 用户名
     * @param password 密码
     * @return 找得到的话返回该用户对象，找不到就是 null 呗
     */
    public User testIsIllegal(@Param("userName") String userName, @Param("password") String password)
    {
        sqlSession = MybatisUtil.getSqlSession();
        userDao = sqlSession.getMapper(UserMapper.class);

        // 可以正确获取对应的 user
        User user = userDao.login(userName, password);

        sqlSession.close();
        return user;
    }

    /**
     * 向 user 表中新插入一条数据
     * @param userName 用户名
     * @param password 密码
     */
    public void InsertUser(@Param("userName") String userName, @Param("password") String password)
    {
        sqlSession = MybatisUtil.getSqlSession();
        userDao = sqlSession.getMapper(UserMapper.class);

        userDao.register(userName, password);

        sqlSession.close();
    }
}
