package com.test;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;


@WebServlet("/GetLogin")
public class GetLogin extends HttpServlet
{
    RequestDispatcher requestDispatcher;
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
    {
        resp.setContentType("text/html;charset=gbk");
        req.setCharacterEncoding("gbk");
        // 不能在PrintWriter out = response.getWriter();后面设置编码方式，
        // 否则就会中文乱码.因为在out对象初始化之后再设置就编码方式就没意义了

        // 获取用户名和密码,以及用户的操作意图
        String userName = req.getParameter("userName");
        String password = req.getParameter("password");
        String option = req.getParameter("option");

        //检测用户名和密码是否有至少一个是空值
        String forwardURL = verify(userName, password, option);

        // 转发至对应的页面
        requestDispatcher = req.getRequestDispatcher(forwardURL);
        requestDispatcher.forward(req, resp);
    }

    /**
     * 根据用户输入数据的不同设置不同的转发地址
     * @param userName 用户名
     * @param password 密码
     * @param option 用户的选择
     * @return 正确的 URL
     */
    public String verify(String userName, String password, String option)
    {
        if (isParameterNull(userName) || isParameterNull(password)) {
            return "login".equals(option)?"login.html":"loginBuy.html";
        }
        // 两个都非空
        else
        {
            // 得到该用户对应的密码
            UserTest userTest = new UserTest();
            String pwd = userTest.testIsExists(userName);
            // 用户不存在，注册去
            if (pwd == null) {
                return  "register.html";
            }
            // 用户存在，看密码是否匹配得上
            else
            {
                // 密码对的上
                if (pwd.equals(password)){
                    return "login".equals(option)?"ThisIsOrder.jsp":"IWillHaveOrder.jsp";
                }else {// 密码对不上，给我重新登录！
                    return "login".equals(option)?"login.html":"loginBuy.html";
                }
            }
        }
    }
    public boolean isParameterNull(String str){
        return "".equals(str);
    }
}
