package com.test;

import com.pojo.Order;
import com.pojo.Product;
import com.pojo.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Date;

@WebServlet("/GetDelete")
public class GetDelete extends HttpServlet
{
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
    {
        // 设置文件编码
        req.setCharacterEncoding("utf-8");
        resp.setCharacterEncoding("utf-8");

        // 获取要删除的订单的 id
        int orderId = Integer.parseInt(req.getParameter("orderId"));

        // 删除订单号对应的订单
        OrderTest orderTest = new OrderTest();
        orderTest.deleteOrder(orderId);

        // 回去
        req.getRequestDispatcher("ThisIsOrder.jsp").forward(req, resp);
    }
}
