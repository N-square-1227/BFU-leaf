package com.mapper;

import com.pojo.Product;

import java.util.List;

public interface ProductMapper
{
    /**
     * 获取所有物品
     *  @return 物品信息
     */
    List<Product> getProductList();
}
