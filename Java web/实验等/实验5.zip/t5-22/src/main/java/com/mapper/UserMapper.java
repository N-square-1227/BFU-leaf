package com.mapper;

import com.pojo.User;
import org.apache.ibatis.annotations.Param;

public interface UserMapper
{
    /**
     * 判断用户是否存在
     * @param userName 用户输入的用户名
     * @return true 是，false 否
     */
    String isExists(String userName);
    /**
     *  登录
     */
    User login(@Param("userName") String userName, @Param("password") String password);
    /**
     * 注册
     * @param userName 用户输入的用户名
     * @param password 用户输入的密码
     */
    void register(@Param("userName") String userName, @Param("password") String password);
}
