package com.test;

import com.mapper.ProductMapper;
import com.pojo.Product;
import com.utils.MybatisUtil;
import org.apache.ibatis.session.SqlSession;

import java.util.List;

public class ProductTest
{
    private SqlSession sqlSession ;
    private ProductMapper productDao;

    public SqlSession getSqlSession() {
        return sqlSession;
    }

    /**
     * 获取所有的货物
     */
    public List<Product> getProductList()
    {
        sqlSession = MybatisUtil.getSqlSession();
        productDao = sqlSession.getMapper(ProductMapper.class);

        return productDao.getProductList();
    }

}
