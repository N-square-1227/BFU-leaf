package com.test;

import com.mapper.OrderMapper;
import com.pojo.Order;
import com.utils.MybatisUtil;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.SqlSession;

import java.util.Date;
import java.util.List;

public class OrderTest
{
    private SqlSession sqlSession ;
    private OrderMapper orderDao;

    public SqlSession getSqlSession() {
        return sqlSession;
    }

    /**
     * 向订单库中插入一条数据
     * @param productId 物品 id
     * @param time 时间
     * @param id 用户 id
     * @param orderState 订单状态
     */
    public void InsertOrder(@Param("productId") int productId, @Param("time") Date time, @Param("id") int id, @Param("orderState") int orderState)
    {
        sqlSession = MybatisUtil.getSqlSession();
        orderDao = sqlSession.getMapper(OrderMapper.class);

        orderDao.insertIntoOrder(productId, time, id, orderState);

        sqlSession.close();
    }

    /**
     * 根据订单 id 获取订单
     * @param id 订单 id
     * @return id 对应的订单
     */
    public List<Order> getOrder(int id)
    {
        sqlSession = MybatisUtil.getSqlSession();
        orderDao = sqlSession.getMapper(OrderMapper.class);

        return orderDao.getOrderList(id);
    }

    /**
     * 删除指定的订单号对应的订单
     * @param orderId 订单号
     */
    public void deleteOrder(int orderId)
    {
        sqlSession = MybatisUtil.getSqlSession();
        orderDao = sqlSession.getMapper(OrderMapper.class);

        orderDao.deleteOrder(orderId);
    }
}
