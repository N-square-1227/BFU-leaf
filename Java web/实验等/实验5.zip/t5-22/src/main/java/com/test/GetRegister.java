package com.test;

import com.pojo.User;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/GetRegister")
public class GetRegister extends HttpServlet
{
    RequestDispatcher requestDispatcher;
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
    {
        resp.setContentType("text/html;charset=gbk");
        req.setCharacterEncoding("gbk");
        // 不能在PrintWriter out = response.getWriter();后面设置编码方式，
        // 否则就会中文乱码.因为在out对象初始化之后再设置就编码方式就没意义了

        // 获取用户名和密码
        String userName = req.getParameter("userName");
        String password = req.getParameter("password");

        //检测用户名和密码是否有至少一个是空值
        String forwardURL = verify(userName, password, req);

        // 转发至对应的页面
        requestDispatcher = req.getRequestDispatcher(forwardURL);
        requestDispatcher.forward(req, resp);
    }

    /**
     * 验证，并转发至正确的地址
     * @param userName 用户名
     * @param password 密码
     * @param request 请求
     * @return 转发到的 URL
     */
    public String verify(String userName, String password, HttpServletRequest request)
    {
        if (isParameterNull(userName) || isParameterNull(password)) {
            return  "register.html";
        }
        // 两个都非空
        else
        {
            // 判断是否重名了
            // 如果重名，那么 pwd 不可能是 null
            // 如果重名，就重新回到注册页面
            UserTest userTest = new UserTest();
            String pwd = userTest.testIsExists(userName);
            // 用户不存在，向数据库中插入该用户的信息
            if (pwd == null) {
                userTest.InsertUser(userName, password);
                //获取该用户对应的对象，直接走到全部货物的那个界面，使用当前用户的信息搞数据库
                User user = userTest.testIsIllegal(userName, password);
                request.setAttribute("user", user);
                return  "IWillHaveOrder.jsp";
            }
            // 用户存在，重新返回注册页面
            else {
                return  "register.html";
            }
        }
    }

    public boolean isParameterNull(String str){
        return str.equals("");
    }
}
