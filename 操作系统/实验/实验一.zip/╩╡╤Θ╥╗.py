"""
os实验一 201002727南希诺
"""
import tkinter as tk
import tkinter.ttk
import random
from tkinter import messagebox
# import os


class PCB:
    """
    作业块结构体
    """
    def __init__(self, name, priority, arr_time, all_time, state):
        self.name = name
        self.priority = priority
        self.arr_time = arr_time
        self.all_time = all_time
        self.state = state

    def running(self, timeslice):      # 进程运行时状态变化
        """
        计算还有没有剩下的时间
        :param timeslice: 系统分配给该进程的可用时间片
        """
        self.all_time -= timeslice


if __name__ == '__main__':
    window = tk.Tk()
    # 设置窗口大小:宽x高,注,此处不能为 "*",必须使用 "x"
    window.geometry('450x300')
    # 设置主窗口的背景颜色,颜色值可以是英文单词,或者颜色值的16进制数,还可以使用Tk内置的颜色常量
    window["background"] = "#87CEFA"
    window.title("os实验一")

    def SJF():
        """
        短作业优先
        """
        sjf_window = tk.Tk()
        # 设置窗口大小:宽x高,注,此处不能为 "*",必须使用 "x"
        sjf_window.geometry('450x300')
        # 设置主窗口的背景颜色,颜色值可以是英文单词,或者颜色值的16进制数,还可以使用Tk内置的颜色常量
        sjf_window["background"] = "#87CEFA"
        window.destroy()

        ready = []  # 就绪队列,1
        wait = []  # 等待队列,0
        
        def click():
            temp = PCB(txt.get(), random.randint(1, 10), random.randint(1, 10),
                       random.randint(1, 1000), random.randint(0, 1))
            ans = ""
            if temp.state == 0:
                ans = "加入到就绪队列中"
            else:
                ans = "加入到准备队列中"
            messagebox.showinfo("提示消息", "已成功添加进程%s!状态是%s,执行时间是%d\n%s\n若结束请手动点右上×退出大窗口"
                                % (txt.get(), temp.state, temp.all_time, ans))
            if temp.state == 0:
                ready.append(temp)
            else:
                wait.append(temp)

        name = tk.Label(sjf_window, text="请输入进程名：", bg="#E1FFFF", fg="black", justify=tk.RIGHT, width=50,
                        font=('Times', 15))
        name.place(x=30, y=40, width=150, height=35)
        txt = tkinter.Entry(sjf_window, width=150)
        txt.place(x=180, y=40, width=150, height=35)
        btn = tk.Button(sjf_window, text="输入好点我", bg="#E1FFFF", fg="black", justify=tk.RIGHT, width=50,
                        font=('Times', 15), command=click)
        btn.place(x=150, y=150, width=150, height=35)

        sjf_window.mainloop()

        while 1:
            if not ready and not wait:
                break
            if wait:  # 等待队列里还有值
                st = random.randint(0, 1)  # 生成状态随机数
                if st == 1:  # 等待队列第一个元素转就绪队列
                    ready.append(wait[0])
                    wait.remove(wait[0])

            if ready:

                # 排序ready，耗时最短的往前走
                for i in range(len(ready) - 1):
                    for j in range(i + 1, len(ready)):
                        if ready[i].all_time > ready[j].all_time:
                            ready[i], ready[j] = ready[j], ready[i]
                        elif ready[i].all_time == ready[j].all_time:
                            if ready[i].arr_time > ready[j].arr_time:
                                ready[i], ready[j] = ready[j], ready[i]

                # 产生一个随机数作为CPU执行时间片大小
                timeslice = random.randint(0, 1000)
                ready[0].running(timeslice)

                if ready[0].all_time <= 0:  # 进程结束
                    show_window = tk.Tk()
                    # 设置窗口大小:宽x高,注,此处不能为 "*",必须使用 "x"
                    show_window.geometry('1920x1080')
                    # 设置主窗口的背景颜色,颜色值可以是英文单词,或者颜色值的16进制数,还可以使用Tk内置的颜色常量
                    show_window["background"] = "#87CEFA"

                    out_txt = tk.Label(show_window, text=ready[0].name + "执行完", bg="#E1FFFF", fg="black",
                                       justify=tk.RIGHT,
                                       width=50,
                                       font=('Times', 15))
                    out_txt.place(x=100, y=40, width=200, height=70)
                    ready.remove(ready[0])  # 执行完就移除该任务

                    # 记录就绪队列
                    readystr = ""
                    for i in range(len(ready)):
                        readystr = readystr + ready[i].name + ","
                    # 记录等待队列
                    waitstr = ""
                    for i in range(len(wait)):
                        waitstr = waitstr + wait[i].name + ","

                    out_txt = tk.Label(show_window, text="就绪队列是：%s\n等待队列是：%s"
                                       % (readystr, waitstr), bg="#E1FFFF", fg="black",
                                       justify=tk.RIGHT, width=50,
                                       font=('Times', 15))
                    out_txt.place(x=90, y=120, width=800, height=600)
                    show_window.mainloop()
                else:  # 时间片用完了，当前进程仍未结束
                    show_window = tk.Tk()
                    # 设置窗口大小:宽x高,注,此处不能为 "*",必须使用 "x"
                    show_window.geometry('1920x1080')
                    # 设置主窗口的背景颜色,颜色值可以是英文单词,或者颜色值的16进制数,还可以使用Tk内置的颜色常量
                    show_window["background"] = "#87CEFA"

                    # 保存这个值，并且移除出就绪队列
                    temp = ready[0]
                    ready.remove(ready[0])

                    # 进程未执行完成，产生随机数0或1
                    randnum = random.randint(0, 1)
                    if randnum == 0:  # 当该随机数为0时，将该进程加入就绪队列队尾
                        ready.append(temp)
                    else:  # 否则，将执行进程加入等待队列队尾
                        wait.append(temp)

                    ans = ""
                    if randnum == 0:
                        ans = "随机数是0，加入就绪队列尾"
                    else:
                        ans = "随机数是1，加入等待队列尾"

                    out_txt = tk.Label(show_window,
                                       text=temp.name + "未执行完，剩余%d ms," % temp.all_time + ans,
                                       bg="#E1FFFF", fg="black",
                                       justify=tk.RIGHT,
                                       width=50,
                                       font=('Times', 15))
                    out_txt.place(x=90, y=40, width=800, height=80)

                    # 记录就绪队列
                    readystr = ""
                    for i in range(len(ready)):
                        readystr = readystr + ready[i].name + ","
                    # 记录等待队列
                    waitstr = ""
                    for i in range(len(wait)):
                        waitstr = waitstr + wait[i].name + ","

                    out_txt = tk.Label(show_window, text="就绪队列是：%s\n等待队列是：%s"
                                       % (readystr, waitstr), bg="#E1FFFF", fg="black",
                                       justify=tk.RIGHT, width=50,
                                       font=('Times', 15))
                    out_txt.place(x=90, y=120, width=800, height=600)
                    show_window.mainloop()


    def FCFS():
        """
        先来先处理
        """
        fcfs_window = tk.Tk()
        # 设置窗口大小:宽x高,注,此处不能为 "*",必须使用 "x"
        fcfs_window.geometry('450x300')
        # 设置主窗口的背景颜色,颜色值可以是英文单词,或者颜色值的16进制数,还可以使用Tk内置的颜色常量
        fcfs_window["background"] = "#87CEFA"
        window.destroy()

        ready = []  # 就绪队列,1
        wait = []  # 等待队列,0

        def click():
            temp = PCB(txt.get(), random.randint(1, 10), random.randint(1, 10),
                       random.randint(1, 1000), random.randint(0, 1))
            ans = ""
            if temp.state == 0:
                ans = "加入到就绪队列中"
            else:
                ans = "加入到准备队列中"
            messagebox.showinfo("提示消息", "已成功添加进程%s!状态是%s，到达时间是%d,\n%s\n若结束请手动点右上×退出大窗口"
                                % (txt.get(), temp.state, temp.arr_time, ans))
            if temp.state == 0:
                ready.append(temp)
            else:
                wait.append(temp)

        name = tk.Label(fcfs_window, text="请输入进程名：", bg="#E1FFFF", fg="black", justify=tk.RIGHT, width=50,
                        font=('Times', 15))
        name.place(x=30, y=40, width=150, height=35)
        txt = tkinter.Entry(fcfs_window, width=150)
        txt.place(x=180, y=40, width=150, height=35)
        btn = tk.Button(fcfs_window, text="输入好点我", bg="#E1FFFF", fg="black", justify=tk.RIGHT, width=50,
                        font=('Times', 15), command=click)
        btn.place(x=150, y=150, width=150, height=35)

        fcfs_window.mainloop()

        while 1:
            if not ready and not wait:
                break
            if wait:  # 等待队列里还有值
                st = random.randint(0, 1)  # 生成状态随机数
                if st == 1:  # 等待队列第一个元素转就绪队列
                    ready.append(wait[0])
                    wait.remove(wait[0])

            if ready:
                # 排序ready，到达时间最短的往前走 # ■ ■ ■ thinter
                for i in range(len(ready) - 1):
                    for j in range(i + 1, len(ready)):
                        if ready[i].arr_time > ready[j].arr_time:
                            ready[i], ready[j] = ready[j], ready[i]
                        elif ready[i].arr_time == ready[j].arr_time:
                            if ready[i].all_time > ready[j].all_time:
                                ready[i], ready[j] = ready[j], ready[i]

                # 产生一个随机数作为CPU执行时间片大小
                timeslice = random.randint(0, 1000)
                ready[0].running(timeslice)

                if ready[0].all_time <= 0:  # 进程结束
                    show_window = tk.Tk()
                    # 设置窗口大小:宽x高,注,此处不能为 "*",必须使用 "x"
                    show_window.geometry('1920x1080')
                    # 设置主窗口的背景颜色,颜色值可以是英文单词,或者颜色值的16进制数,还可以使用Tk内置的颜色常量
                    show_window["background"] = "#87CEFA"
                    out_txt = tk.Label(show_window, text=ready[0].name + "执行完", bg="#E1FFFF", fg="black",
                                       justify=tk.RIGHT,
                                       width=50,
                                       font=('Times', 15))
                    out_txt.place(x=100, y=40, width=200, height=70)
                    ready.remove(ready[0])  # 执行完就移除该任务

                    # 记录就绪队列,range!!!
                    readystr = ""
                    for i in range(len(ready)):
                        readystr = readystr + ready[i].name + ","
                    # print(readystr)  # test
                    # 记录等待队列
                    waitstr = ""
                    for i in range(len(wait)):
                        waitstr = waitstr + wait[i].name + ","
                    # print(waitstr)  # test
                    out_txt = tk.Label(show_window, text="就绪队列是：%s\n等待队列是：%s"
                                       % (readystr, waitstr), bg="#E1FFFF", fg="black",
                                       justify=tk.RIGHT, width=50,
                                       font=('Times', 15))
                    out_txt.place(x=90, y=120, width=800, height=600)
                    show_window.mainloop()
                else:  # 时间片用完了，当前进程仍未结束
                    show_window = tk.Tk()
                    # 设置窗口大小:宽x高,注,此处不能为 "*",必须使用 "x"
                    show_window.geometry('1920x1080')
                    # 设置主窗口的背景颜色,颜色值可以是英文单词,或者颜色值的16进制数,还可以使用Tk内置的颜色常量
                    show_window["background"] = "#87CEFA"

                    # 保存这个值，并且移除出就绪队列
                    temp = ready[0]
                    ready.remove(ready[0])

                    # 进程未执行完成，产生随机数0或1
                    randnum = random.randint(0, 1)
                    ans = ""
                    if randnum == 0:  # 当该随机数为0时，将该进程加入就绪队列队尾
                        ready.append(temp)
                        ans = "随机数是0，加入就绪队列尾"
                    else:  # 否则，将执行进程加入等待队列队尾
                        wait.append(temp)
                        ans = "随机数是1，加入等待队列尾"

                    out_txt = tk.Label(show_window,
                                       text=temp.name + "未执行完，剩余%d ms," % temp.all_time + ans,
                                       bg="#E1FFFF", fg="black",
                                       justify=tk.RIGHT,
                                       width=50,
                                       font=('Times', 15))
                    out_txt.place(x=90, y=40, width=800, height=80)

                    # 记录就绪队列
                    readystr = ""
                    for i in range(len(ready)):
                        readystr = readystr + ready[i].name + ","
                    # 记录等待队列
                    waitstr = ""
                    for i in range(len(wait)):
                        waitstr = waitstr + wait[i].name + ","

                    out_txt = tk.Label(show_window, text="就绪队列是：%s\n等待队列是：%s"
                                       % (readystr, waitstr), bg="#E1FFFF", fg="black",
                                       justify=tk.RIGHT, width=50,
                                       font=('Times', 15))
                    out_txt.place(x=90, y=120, width=800, height=600)
                    show_window.mainloop()
                    
                    
    def PRIO():
        """
        优先数调度算法
        """
        prio_window = tk.Tk()
        # 设置窗口大小:宽x高,注,此处不能为 "*",必须使用 "x"
        prio_window.geometry('450x300')
        # 设置主窗口的背景颜色,颜色值可以是英文单词,或者颜色值的16进制数,还可以使用Tk内置的颜色常量
        prio_window["background"] = "#87CEFA"
        window.destroy()

        ready = []  # 就绪队列,1
        wait = []  # 等待队列,0

        def click():
            temp = PCB(txt.get(), random.randint(1, 10), random.randint(1, 10),
                       random.randint(1, 1000), random.randint(0, 1))
            ans = ""
            if temp.state == 0:
                ans = "加入到就绪队列中"
            else:
                ans = "加入到准备队列中"
            messagebox.showinfo("提示消息", "已成功添加进程%s!状态是%s，优先数是%d,\n%s\n若结束请手动点右上×退出大窗口"
                                % (txt.get(), temp.state, temp.priority, ans))
            if temp.state == 0:
                ready.append(temp)
            else:
                wait.append(temp)

        name = tk.Label(prio_window, text="请输入进程名：", bg="#E1FFFF", fg="black", justify=tk.RIGHT, width=50,
                        font=('Times', 15))
        name.place(x=30, y=40, width=150, height=35)
        txt = tkinter.Entry(prio_window, width=150)
        txt.place(x=180, y=40, width=150, height=35)
        btn = tk.Button(prio_window, text="输入好点我", bg="#E1FFFF", fg="black", justify=tk.RIGHT, width=50,
                        font=('Times', 15), command=click)
        btn.place(x=150, y=150, width=150, height=35)

        prio_window.mainloop()

        while 1:
            if not ready and not wait:
                break
            if wait:  # 等待队列里还有值
                st = random.randint(0, 1)  # 生成状态随机数
                if st == 1:  # 等待队列第一个元素转就绪队列
                    ready.append(wait[0])
                    wait.remove(wait[0])

            if ready:

                # 排序ready，优先级小的往前走 # ■ ■ ■ tkinter
                for i in range(len(ready) - 1):
                    for j in range(i + 1, len(ready)):
                        if ready[i].priority > ready[j].priority:
                            ready[i], ready[j] = ready[j], ready[i]
                        elif ready[i].priority == ready[j].priority:
                            if ready[i].all_time > ready[j].all_time:
                                ready[i], ready[j] = ready[j], ready[i]

                # 产生一个随机数作为CPU执行时间片大小
                timeslice = random.randint(0, 1000)
                ready[0].running(timeslice)

                if ready[0].all_time <= 0:  # 进程结束
                    show_window = tk.Tk()
                    # 设置窗口大小:宽x高,注,此处不能为 "*",必须使用 "x"
                    show_window.geometry('1920x1080')
                    # 设置主窗口的背景颜色,颜色值可以是英文单词,或者颜色值的16进制数,还可以使用Tk内置的颜色常量
                    show_window["background"] = "#87CEFA"
                    out_txt = tk.Label(show_window, text=ready[0].name + "执行完", bg="#E1FFFF", fg="black",
                                       justify=tk.RIGHT,
                                       width=50,
                                       font=('Times', 15))
                    out_txt.place(x=100, y=40, width=200, height=70)
                    ready.remove(ready[0])  # 执行完就移除该任务

                    # 记录就绪队列,range!!!
                    readystr = ""
                    for i in range(len(ready)):
                        readystr = readystr + ready[i].name + ","
                    # 记录等待队列
                    waitstr = ""
                    for i in range(len(wait)):
                        waitstr = waitstr + wait[i].name + ","

                    out_txt = tk.Label(show_window, text="就绪队列是：%s\n等待队列是：%s"
                                       % (readystr, waitstr), bg="#E1FFFF", fg="black",
                                       justify=tk.RIGHT, width=50,
                                       font=('Times', 15))
                    out_txt.place(x=90, y=120, width=800, height=600)
                    show_window.mainloop()
                else:  # 时间片用完了，当前进程仍未结束
                    show_window = tk.Tk()
                    # 设置窗口大小:宽x高,注,此处不能为 "*",必须使用 "x"
                    show_window.geometry('1920x1080')
                    # 设置主窗口的背景颜色,颜色值可以是英文单词,或者颜色值的16进制数,还可以使用Tk内置的颜色常量
                    show_window["background"] = "#87CEFA"

                    # 保存这个值，并且移除出就绪队列
                    temp = ready[0]
                    ready.remove(ready[0])

                    # 进程未执行完成，产生随机数0或1
                    randnum = random.randint(0, 1)
                    ans = ""
                    if randnum == 0:  # 当该随机数为0时，将该进程加入就绪队列队尾
                        ready.append(temp)
                        ans = "随机数是0，加入就绪队列尾"
                    else:  # 否则，将执行进程加入等待队列队尾
                        wait.append(temp)
                        ans = "随机数是1，加入等待队列尾"

                    out_txt = tk.Label(show_window,
                                       text=temp.name + "未执行完，剩余 %d ms," % temp.all_time + ans,
                                       bg="#E1FFFF", fg="black",
                                       justify=tk.RIGHT,
                                       width=50,
                                       font=('Times', 15))
                    out_txt.place(x=90, y=40, width=800, height=80)

                    # 记录就绪队列
                    readystr = ""
                    for i in range(len(ready)):
                        readystr = readystr + ready[i].name + ","
                    # print(readystr)  # test
                    # 记录等待队列
                    waitstr = ""
                    for i in range(len(wait)):
                        waitstr = waitstr + wait[i].name + ","
                    # print(waitstr)  # test

                    out_txt = tk.Label(show_window, text="就绪队列是：%s\n等待队列是：%s"
                                       % (readystr, waitstr), bg="#E1FFFF", fg="black",
                                       justify=tk.RIGHT, width=50,
                                       font=('Times', 15))
                    out_txt.place(x=90, y=120, width=800, height=600)
                    show_window.mainloop()
    # 添加按钮，以及按钮的文本，Button 控件的作用就是“执行一个函数”
    button = tk.Button(window, text="先进先出", bg="#E1FFFF", fg="black", justify=tk.RIGHT,
                       width=50, font=('Times', 15), command=FCFS)
    # 将按钮放置在主窗口内
    button.place(x=155, y=100, width=150, height=36)
    # 添加按钮，以及按钮的文本，Button 控件的作用就是“执行一个函数”
    button = tk.Button(window, text="短作业优先", bg="#E1FFFF", fg="black", justify=tk.RIGHT,
                       width=50, font=('Times', 15), command=SJF)
    # 将按钮放置在主窗口内
    button.place(x=155, y=150, width=150, height=36)
    # 添加按钮，以及按钮的文本，Button 控件的作用就是“执行一个函数”
    button = tk.Button(window, text="优先数", bg="#E1FFFF", fg="black", justify=tk.RIGHT,
                       width=50, font=('Times', 15), command=PRIO)
    # 将按钮放置在主窗口内
    button.place(x=155, y=200, width=150, height=36)
    window.mainloop()
