# pintos

[![GitHub license](https://img.shields.io/github/license/CCXXXI/pintos)](LICENSE)
[![GitHub last commit](https://img.shields.io/github/last-commit/CCXXXI/pintos)](../../commits)

duplicated from git://pintos-os.org/pintos-anon

[Wiki](../../wiki)
